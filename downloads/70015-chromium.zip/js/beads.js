/**
 * 70015 — Bead Pattern
 * Image -> bead grid (pixel art / AI pixel art / any image) -> bead colors -> edit -> chart.
 * The algorithms live in beads-core.js; this file is the page.
 */
(function () {
  'use strict';

  var C = window.BeadsCore;
  var MAX_SIDE = 200; // beads per side; also keeps the exported chart within canvas limits
  var MM = 72 / 25.4; // PDF points per mm
  var PRINT_DPI = 300;
  var PAPERS = [[210, 297], [297, 210], [297, 420], [420, 297]]; // A4, A4 landscape, A3, A3 landscape (mm)

  function t(key, fallback) {
    var v = typeof window.t === 'function' ? window.t(key) : key;
    return v && v !== key ? v : fallback;
  }
  function tpl(key, fallback, vars) {
    return t(key, fallback).replace(/\{(\w+)\}/g, function (m, k) { return k in vars ? vars[k] : m; });
  }
  function $(id) { return document.getElementById(id); }

  // Browser storage is a convenience: private windows or blocked storage just start empty.
  function readStore(key, fallback) {
    try { var v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch (e) { return fallback; }
  }
  function writeStore(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* not saved */ }
  }

  var toast = $('toast');
  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('is-visible');
    setTimeout(function () { toast.classList.remove('is-visible'); }, 2200);
  }

  var el = {
    drop: $('bdDrop'), input: $('bdInput'),
    mode: $('bdMode'), modeNote: $('bdModeNote'),
    cellField: $('bdCellField'), cell: $('bdCell'), redetectWrap: $('bdRedetectWrap'), redetect: $('bdRedetect'),
    w: $('bdW'), h: $('bdH'), cmW: $('bdCmW'), cmH: $('bdCmH'),
    pitch: $('bdPitch'), pitchPreset: $('bdPitchPreset'), sizeNote: $('bdSizeNote'),
    palette: $('bdPalette'), paletteInput: $('bdPaletteInput'), paletteNote: $('bdPaletteNote'),
    ownedOnly: $('bdOwnedOnly'), ownedNote: $('bdOwnedNote'),
    pickMode: $('bdPickMode'), ownAll: $('bdOwnAll'), ownNone: $('bdOwnNone'), paletteGrid: $('bdPaletteGrid'),
    max: $('bdMax'), maxValue: $('bdMaxValue'), bg: $('bdBg'),
    result: $('bdResult'), status: $('bdStatus'), stats: $('bdStats'), progress: $('bdProgress'),
    tool: $('bdTool'), selBar: $('bdSelBar'), selCopy: $('bdSelCopy'), selFlipH: $('bdSelFlipH'),
    selFlipV: $('bdSelFlipV'), selClear: $('bdSelClear'), selDone: $('bdSelDone'), brushSwatch: $('bdBrushSwatch'), brushCode: $('bdBrushCode'),
    undo: $('bdUndo'), codes: $('bdCodes'), focus: $('bdFocus'), strays: $('bdStrays'),
    stage: $('bdStage'), canvas: $('bdCanvas'),
    usedNote: $('bdUsedNote'), legend: $('bdLegend'),
    board: $('bdBoard'), boardPdf: $('bdBoardPdf'),
    actions: $('bdActions'),
    settings: document.querySelector('.bd-settings'),
    newW: $('bdNewW'), newH: $('bdNewH'), newBtn: $('bdNewBtn'),
    works: $('bdWorks'), worksList: $('bdWorksList'),
    strip: $('bdStrip'), zoomIn: $('bdZoomIn'), zoomOut: $('bdZoomOut'), zoomFit: $('bdZoomFit'),
    groups: $('bdGroups'), sym: $('bdSym'), round: $('bdRound'), center: $('bdCenter'),
    copyList: $('bdCopyList'), csv: $('bdCsv'),
    exGrid: $('bdExGrid'), exCodes: $('bdExCodes'), exAxes: $('bdExAxes'), exRound: $('bdExRound'),
    name: $('bdName'), outline: $('bdOutline'), waste: $('bdWaste'), pack: $('bdPack'), buyNote: $('bdBuyNote'),
    importWork: $('bdImportWork'), workInput: $('bdWorkInput'), exportWork: $('bdExportWork')
  };

  var builtIn = {};
  Object.keys(window.BEAD_PALETTES).forEach(function (id) { builtIn[id] = C.parsePalette(window.BEAD_PALETTES[id]); });

  var state = {
    src: null,        // { data, w, h, img, name }
    mode: 'pixel',
    cell: 1,          // pixel / AI modes: source pixels per bead
    grid: null,       // AI mode: detected grid
    paletteId: 'mard',
    custom: null,     // { name, colors }
    palette: builtIn.mard,
    owned: new Set(), // codes the user has, per palette family
    pickMode: 'brush',
    w: 0, h: 0,
    pattern: null,    // Int16Array of palette indexes, -1 = no bead
    tool: 'brush',
    brush: 0,
    cs: 16,           // preview cell size in px
    undo: [],
    focus: false,     // one-color-at-a-time view
    focusColor: -1,
    done: new Set(),  // palette indexes placed already (one-color mode)
    progressKey: '',
    name: 'beads',    // used for file names and chart titles
    workId: '',       // the saved work this pattern belongs to
    zoom: 0,          // preview cell size the user zoomed to; 0 = fit the screen
    sel: null,        // Select tool box { x, y, w, h } in cells
    sym: 'off',       // mirror drawing: off | h (left-right) | v (top-bottom) | both
    group: 'used',    // which colors the phone strip shows: used | recent | a family like "A"
    recent: [],       // codes picked lately, newest first, per palette family
    edited: false     // hand edits since the pattern was last generated from the image
  };

  // ---------- Small UI helpers ----------

  function setSegmented(group, value) {
    [].forEach.call(group.querySelectorAll('.segmented__btn'), function (b) { b.classList.toggle('is-active', b.dataset.value === value); });
  }

  function onSegmented(group, fn) {
    group.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-value]');
      if (btn) fn(btn.dataset.value);
    });
  }

  function setStatus(text) {
    el.status.hidden = !text;
    el.status.textContent = text || '';
  }

  function textColor(c) { return c.lab[0] > 60 ? '#000000' : '#ffffff'; }

  function numberIn(input, min, max, fallback) {
    var v = parseFloat(input.value);
    return v >= min && v <= max ? v : fallback;
  }

  // ---------- Source image ----------

  function loadFile(file) {
    if (!file || !/^image\//.test(file.type)) return;
    var url = URL.createObjectURL(file);
    var img = new Image();
    img.onload = function () {
      URL.revokeObjectURL(url);
      flushSave();
      var c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      var ctx = c.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(img, 0, 0);
      var name = file.name && file.name !== 'image.png' ? file.name.replace(/\.[^.]+$/, '') : 'beads';
      state.src = { data: ctx.getImageData(0, 0, c.width, c.height).data, w: c.width, h: c.height, img: img, name: name, jpeg: /jpe?g/.test(file.type) };
      state.name = name;
      state.workId = newWorkId();
      state.zoom = 0;
      state.pattern = null; // a new image: nothing of the previous work to keep
      state.edited = false;
      syncName();
      el.w.value = el.h.value = ''; // a new image starts at its own size
      document.body.classList.add('is-working');
      el.settings.classList.remove('is-blank');
      autoMode();
      build();
    };
    img.onerror = function () { URL.revokeObjectURL(url); showToast(t('aip_load_fail', 'Could not read this image.')); };
    img.src = url;
  }

  // Small or cleanly upscaled images are pixel art; a strong regular edge grid means AI pixel art.
  function autoMode() {
    var s = state.src;
    var scale = C.detectScale(s.data, s.w, s.h);
    if (scale > 1 || (s.w <= MAX_SIDE && s.h <= MAX_SIDE)) {
      setMode('pixel', scale);
      return;
    }
    state.grid = C.detectGrid(s.data, s.w, s.h);
    // ponytail: strength threshold picked from test images; tune if photos get misread as AI art.
    if (state.grid && state.grid.x.strength > 2 && state.grid.x.p >= 4 && s.w / state.grid.x.p <= MAX_SIDE) {
      setMode('ai', state.grid.x.p);
    } else {
      setMode('photo');
    }
  }

  function setMode(mode, cell) {
    state.mode = mode;
    setSegmented(el.mode, mode);
    if (cell) state.cell = cell;
    el.cellField.hidden = mode === 'photo';
    el.redetectWrap.hidden = mode !== 'ai';
    el.cell.step = mode === 'ai' ? '0.1' : '1';
    el.cell.value = state.cell;
    renderModeNote();
  }

  function renderModeNote() {
    var notes = {
      pixel: t('bd_note_pixel', '1 pixel = 1 bead. Images exported at 2×, 3×… are scaled back automatically.'),
      ai: t('bd_note_ai', 'Finds the hidden pixel grid in AI-made pixel art and takes each cell\'s main color. If the grid looks off, change the cell size.'),
      photo: t('bd_note_photo', 'Shrinks the picture to the bead size you set. Leave height empty to keep the proportions.')
    };
    el.modeNote.textContent = notes[state.mode];
  }

  function pitch() { return numberIn(el.pitch, 1, 20, 2.6); }

  // Bead count from the width/height fields; an empty one follows the other's proportions.
  // Both empty: the natural size (nw x nh), or fallbackW wide for photos.
  // When the side that follows would pass MAX_SIDE, both shrink together to fit (never stretch);
  // capped: true tells the size note to say so. Two typed sides are used as typed.
  function targetSize(nw, nh, fallbackW) {
    var w = parseInt(el.w.value, 10) || 0, h = parseInt(el.h.value, 10) || 0;
    if (!w && !h) {
      if (!fallbackW) return { w: nw, h: nh };
      w = fallbackW;
    }
    var follows = !w || !h;
    if (!h) h = Math.max(1, Math.round(w * nh / nw));
    if (!w) w = Math.max(1, Math.round(h * nw / nh));
    if (follows && Math.max(w, h) > MAX_SIDE) {
      var k = MAX_SIDE / Math.max(w, h);
      return { w: Math.max(1, Math.round(w * k)), h: Math.max(1, Math.round(h * k)), capped: true };
    }
    return { w: w, h: h };
  }

  // Source -> one RGBA cell per bead.
  function sampleCells() {
    var s = state.src, size;
    if (state.mode === 'photo') {
      state.natural = null;
      size = targetSize(s.w, s.h, Math.min(50, s.w));
      state.capped = !!size.capped;
      if (size.w > MAX_SIDE || size.h > MAX_SIDE) return { w: size.w, h: size.h };
      var c = document.createElement('canvas');
      c.width = size.w;
      c.height = size.h;
      var ctx = c.getContext('2d', { willReadFrequently: true });
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(s.img, 0, 0, size.w, size.h);
      return { w: size.w, h: size.h, data: ctx.getImageData(0, 0, size.w, size.h).data };
    }
    var g;
    if (state.mode === 'ai') {
      if (!state.grid || state.grid.x.p !== state.cell) state.grid = C.detectGrid(s.data, s.w, s.h, state.cell);
      g = state.grid;
    } else {
      g = { x: { p: state.cell, o: 0 }, y: { p: state.cell, o: 0 } };
    }
    var cells = C.sampleGrid(s.data, s.w, s.h, g.x, g.y);
    state.natural = { w: cells.w, h: cells.h };
    // A different bead count resamples the art's own grid, one median per new cell.
    size = targetSize(cells.w, cells.h);
    state.capped = !!size.capped;
    if (size.w === cells.w && size.h === cells.h) return cells;
    if (size.w > MAX_SIDE || size.h > MAX_SIDE) return { w: size.w, h: size.h };
    return C.sampleGrid(cells.data, cells.w, cells.h, { p: cells.w / size.w, o: 0 }, { p: cells.h / size.h, o: 0 }, true);
  }

  // Size fields after a build: bead counts as placeholders, centimetres from the bead size.
  function renderSize() {
    if (!state.pattern) return;
    var mm = pitch();
    el.w.placeholder = String(state.w);
    el.h.placeholder = String(state.h);
    if (document.activeElement !== el.cmW) el.cmW.value = (state.w * mm / 10).toFixed(1);
    if (document.activeElement !== el.cmH) el.cmH.value = (state.h * mm / 10).toFixed(1);
    var note = tpl('bd_size_note', '{w} × {h} beads of {mm} mm ≈ {cw} × {ch} cm. Type a size in cm to get the bead count; leave a bead field empty to keep the proportions.', {
      w: state.w, h: state.h, mm: mm, cw: (state.w * mm / 10).toFixed(1), ch: (state.h * mm / 10).toFixed(1)
    });
    var n = state.natural;
    if (n && (state.w !== n.w || state.h !== n.h)) {
      note += ' ' + tpl(state.w < n.w ? 'bd_size_down' : 'bd_size_up', state.w < n.w
        ? 'Shrunk from the art\'s {w} × {h}: thin lines and 1-pixel details may disappear.'
        : 'Enlarged from the art\'s {w} × {h}: each pixel becomes a block of beads.', { w: n.w, h: n.h });
    }
    if (state.capped) {
      note += ' ' + tpl('bd_size_capped', 'Kept within {max} beads per side, so both sides were scaled down together.', { max: MAX_SIDE });
    }
    el.sizeNote.textContent = note;
  }

  // FNV-1a over the generated pattern: the same image and settings give the same key,
  // so one-color progress comes back after a reload.
  function patternKey() {
    var h = 2166136261;
    function mix(v) { h = Math.imul(h ^ (v & 0xffff), 16777619) >>> 0; }
    mix(state.w); mix(state.h);
    for (var i = 0; i < state.pattern.length; i++) mix(state.pattern[i] + 1);
    state.palette.forEach(function (c) { for (var k = 0; k < c.code.length; k++) mix(c.code.charCodeAt(k)); });
    return '70015-beads-progress:' + h.toString(36);
  }

  // Rebuilding from settings starts over, so manual edits are dropped.
  // Without a source image (blank canvas, reopened work) there is nothing to rebuild from.
  function build() {
    if (!state.src) return;
    // Hand edits would be lost: keep the edited version as its own saved work first.
    var keptEdits = false;
    if (state.pattern && state.edited && state.workId) {
      clearTimeout(saveTimer);
      var name = state.name;
      state.name = tpl('bd_edited_name', '{name} (edited)', { name: name });
      saveWork();
      state.name = name;
      state.workId = newWorkId();
      keptEdits = true;
    }
    state.edited = false;
    var cells = sampleCells();
    el.result.hidden = false;
    if (cells.w > MAX_SIDE || cells.h > MAX_SIDE) {
      state.pattern = null;
      setStatus(tpl('bd_too_big', 'That makes {w} × {h} beads, more than {max} per side. Set a smaller width or height under "Finished size" (beads or cm), or raise the pixels per bead.', { w: cells.w, h: cells.h, max: MAX_SIDE }));
      render();
      return;
    }
    // AI art and JPGs carry noise that would split one color across neighbouring bead shades.
    // Photos keep their gradients (and stay fast), so "Any image" is left alone.
    if (state.mode === 'ai' || (state.src.jpeg && state.mode === 'pixel')) C.mergeSimilar(cells.data, 5);
    var pattern = C.mapColors(cells.data, state.palette, allowedColors());
    pattern = C.limitColors(pattern, state.palette, parseInt(el.max.value, 10));
    // Tolerance 6 takes a JPG white's near-white shades along, but not skin or cream tones.
    if (el.bg.checked) C.removeBackground(pattern, cells.w, cells.h, state.palette, 6);
    state.w = cells.w;
    state.h = cells.h;
    state.pattern = pattern;
    state.undo = [];
    state.progressKey = patternKey();
    state.done = new Set();
    var doneCodes = readStore(state.progressKey, []);
    state.palette.forEach(function (c, i) { if (doneCodes.indexOf(c.code) >= 0) state.done.add(i); });
    var weak = state.mode === 'ai' && state.grid && state.grid.x.strength < 1.5;
    setStatus(weak ? t('bd_weak_grid', 'No clear pixel grid found. Check the result, change the cell size, or use "Any image".') : '');
    var counts = C.countColors(pattern, state.palette.length);
    if (state.brush >= 0 && !counts[state.brush]) state.brush = counts.indexOf(Math.max.apply(null, counts));
    if (state.focus) pickNextFocus();
    render();
    if (keptEdits) showToast(t('bd_edits_kept', 'Your hand edits were saved as a separate work under "Recent work".'));
  }

  // ---------- Drawing ----------

  function wholeGrid() { return { x0: 0, y0: 0, x1: state.w, y1: state.h }; }

  // Draw the beads of `region` (default: all) with its top-left at (ox, oy), cells cs px.
  // opts.codes: write color codes; opts.dim: fade every color except state.focusColor.
  function drawGrid(ctx, ox, oy, cs, opts) {
    var r = opts.region || wholeGrid();
    for (var y = r.y0; y < r.y1; y++) {
      for (var x = r.x0; x < r.x1; x++) drawCell(ctx, ox - r.x0 * cs, oy - r.y0 * cs, cs, y * state.w + x, opts);
    }
    drawMajorLines(ctx, ox, oy, cs, r, opts.grid !== false);
  }

  // (ox, oy) is where bead (0, 0) would be drawn.
  // opts.round: beads as circles with a hole, like the real thing; opts.grid === false: no cell lines.
  function drawCell(ctx, ox, oy, cs, i, opts) {
    var x = i % state.w, y = (i - x) / state.w, v = state.pattern[i];
    var px = ox + x * cs, py = oy + y * cs;
    var c = v >= 0 ? state.palette[v] : null;
    var faded = opts.dim && v !== state.focusColor;
    var labelled = c && !faded && opts.codes && cs >= 14;
    if (opts.round) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(px, py, cs, cs);
      if (c) {
        ctx.fillStyle = c.hex;
        ctx.beginPath();
        ctx.arc(px + cs / 2, py + cs / 2, cs * 0.47, 0, Math.PI * 2);
        ctx.fill();
        if (!labelled) {
          ctx.fillStyle = 'rgba(255,255,255,0.6)';
          ctx.beginPath();
          ctx.arc(px + cs / 2, py + cs / 2, cs * 0.15, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    } else {
      ctx.fillStyle = c ? c.hex : '#ffffff';
      ctx.fillRect(px, py, cs, cs);
    }
    if (faded && c) {
      ctx.fillStyle = 'rgba(255,255,255,0.82)';
      ctx.fillRect(px, py, cs, cs);
    }
    if (opts.grid !== false) {
      ctx.strokeStyle = 'rgba(0,0,0,0.18)';
      ctx.lineWidth = 1;
      ctx.strokeRect(px + 0.5, py + 0.5, cs - 1, cs - 1);
    }
    if (labelled) {
      ctx.fillStyle = textColor(c);
      ctx.font = '600 ' + Math.floor(Math.min(cs * 0.42, cs * 1.5 / c.code.length)) + 'px Inter, system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(c.code, px + cs / 2, py + cs / 2 + 0.5);
    }
  }

  // Thick lines every 10 beads (counted from the pattern's corner) plus the region outline;
  // with grid off, only the outline.
  function drawMajorLines(ctx, ox, oy, cs, r, grid) {
    var right = ox + (r.x1 - r.x0) * cs, bottom = oy + (r.y1 - r.y0) * cs;
    ctx.strokeStyle = 'rgba(0,0,0,0.65)';
    ctx.lineWidth = Math.max(1.5, cs / 12);
    ctx.beginPath();
    if (grid !== false) {
      for (var x = Math.ceil(r.x0 / 10) * 10; x <= r.x1; x += 10) { var lx = ox + (x - r.x0) * cs; ctx.moveTo(lx, oy); ctx.lineTo(lx, bottom); }
      for (var y = Math.ceil(r.y0 / 10) * 10; y <= r.y1; y += 10) { var ly = oy + (y - r.y0) * cs; ctx.moveTo(ox, ly); ctx.lineTo(right, ly); }
    }
    ctx.rect(ox, oy, right - ox, bottom - oy);
    ctx.stroke();
  }

  // Preview only: dashed center lines, shown for the mirror axes in use or with "Center lines".
  function drawGuides(ctx) {
    var cs = state.cs, vertical = el.center.checked || state.sym === 'h' || state.sym === 'both';
    var horizontal = el.center.checked || state.sym === 'v' || state.sym === 'both';
    if (!vertical && !horizontal) return;
    ctx.save();
    ctx.strokeStyle = '#e11d48';
    ctx.lineWidth = Math.max(1.5, cs / 10);
    ctx.setLineDash([Math.max(4, cs / 2), Math.max(3, cs / 3)]);
    ctx.beginPath();
    if (vertical) { ctx.moveTo(state.w * cs / 2, 0); ctx.lineTo(state.w * cs / 2, state.h * cs); }
    if (horizontal) { ctx.moveTo(0, state.h * cs / 2); ctx.lineTo(state.w * cs, state.h * cs / 2); }
    ctx.stroke();
    ctx.restore();
  }

  function previewOpts() { return { codes: el.codes.checked, round: el.round.checked, dim: state.focus && state.focusColor >= 0 }; }

  // Largest cell size whose canvas stays within ~16 M pixels, iOS Safari's canvas limit.
  function maxCs() { return Math.max(4, Math.floor(Math.sqrt(16e6 / (state.w * state.h)))); }

  // Cell size that fits the stage (its width, and its max-height from the CSS), so the
  // whole pattern is visible without scrolling.
  function fitCs() {
    var availW = el.stage.clientWidth - 20;
    var mh = parseFloat(getComputedStyle(el.stage).maxHeight);
    var availH = (mh > 0 ? mh : window.innerHeight - 190) - 20;
    return Math.max(4, Math.min(32, Math.floor(Math.min(availW / state.w, availH / state.h))));
  }

  function renderCanvas() {
    state.cs = Math.max(4, Math.min(maxCs(), state.zoom || fitCs()));
    el.canvas.width = state.w * state.cs;
    el.canvas.height = state.h * state.cs;
    el.canvas.style.width = el.canvas.width + 'px';
    el.canvas.style.height = el.canvas.height + 'px';
    var ctx = el.canvas.getContext('2d');
    drawGrid(ctx, 0, 0, state.cs, previewOpts());
    drawGuides(ctx);
    drawSelection(ctx);
  }

  // Zoom to cell size cs, keeping the pattern point under (cx, cy) on screen where it was.
  function setZoom(cs, cx, cy) {
    var r = el.canvas.getBoundingClientRect();
    if (cx === undefined) {
      var s = el.stage.getBoundingClientRect();
      cx = Math.max(r.left, Math.min(r.right, s.left + s.width / 2));
      cy = Math.max(r.top, Math.min(r.bottom, s.top + s.height / 2));
    }
    var fx = (cx - r.left) / r.width, fy = (cy - r.top) / r.height;
    state.zoom = Math.max(4, Math.min(maxCs(), Math.round(cs)));
    renderCanvas();
    keepPoint(fx, fy, cx, cy);
  }

  // Scroll the stage so the canvas fraction (fx, fy) sits at screen point (cx, cy).
  function keepPoint(fx, fy, cx, cy) {
    var r = el.canvas.getBoundingClientRect();
    el.stage.scrollLeft += r.left + fx * r.width - cx;
    el.stage.scrollTop += r.top + fy * r.height - cy;
  }

  el.zoomIn.addEventListener('click', function () { if (state.pattern) setZoom(Math.max(state.cs + 1, state.cs * 1.25)); });
  el.zoomOut.addEventListener('click', function () { if (state.pattern) setZoom(Math.min(state.cs - 1, state.cs / 1.25)); });
  el.zoomFit.addEventListener('click', function () { if (state.pattern) { state.zoom = 0; renderCanvas(); } });
  // Ctrl/⌘ + wheel (and trackpad pinch, which browsers report the same way) zooms.
  el.stage.addEventListener('wheel', function (e) {
    if (!state.pattern || !(e.ctrlKey || e.metaKey)) return;
    e.preventDefault();
    setZoom(state.cs * (e.deltaY < 0 ? 1.15 : 1 / 1.15), e.clientX, e.clientY);
  }, { passive: false });

  function usedColors() {
    var counts = C.countColors(state.pattern, state.palette.length), used = [];
    counts.forEach(function (n, i) { if (n) used.push({ i: i, n: n }); });
    used.sort(function (a, b) { return b.n - a.n || a.i - b.i; });
    return used;
  }

  function statsText(used) {
    var total = used.reduce(function (s, u) { return s + u.n; }, 0);
    var mm = pitch();
    return tpl('bd_stats', '{w} × {h} beads · {colors} colors · {total} beads in total', { w: state.w, h: state.h, colors: used.length, total: total }) +
      ' · ' + tpl('bd_size_cm', '≈ {w} × {h} cm', { w: (state.w * mm / 10).toFixed(1), h: (state.h * mm / 10).toFixed(1) });
  }

  function renderInfo() {
    var used = usedColors();
    el.stats.textContent = statsText(used);
    el.usedNote.textContent = state.focus
      ? t('bd_used_note_focus', 'Click a color to show only that color. Tick ✓ when its beads are placed; progress is saved in this browser.')
      : t('bd_used_note', 'Click a color to paint with it; "Empty" erases, and with Fill clears a whole area. ⇄ replaces every bead of that color with the brush color (with "Empty" as the brush, it removes them).');
    renderProgress(used);
    el.legend.innerHTML = '';
    // "Empty" (no bead) comes first: as the brush it erases, with Fill it clears an area,
    // and its ⇄ fills every empty cell with the brush color.
    var entries = used.slice();
    if (!state.focus) {
      var placed = used.reduce(function (s, u) { return s + u.n; }, 0);
      entries.unshift({ i: -1, n: state.pattern.length - placed });
    }
    entries.forEach(function (u) {
      var c = state.palette[u.i];
      var row = document.createElement('div');
      row.className = 'bd-color' + (u.i === (state.focus ? state.focusColor : state.brush) ? ' is-active' : '') + (state.focus && state.done.has(u.i) ? ' is-done' : '');
      var pick = document.createElement('button');
      pick.type = 'button';
      pick.className = 'bd-color__pick';
      pick.innerHTML = '<span class="bd-swatch"></span><span class="bd-color__code"></span><span class="bd-color__count"></span>';
      if (c) pick.firstChild.style.background = c.hex;
      else pick.firstChild.classList.add('bd-swatch--empty');
      pick.children[1].textContent = c ? c.code : t('bd_empty_row', 'Empty (no bead)');
      pick.children[2].textContent = '× ' + u.n;
      pick.addEventListener('click', function () {
        if (state.focus) { state.focusColor = u.i; renderCanvas(); }
        setBrush(u.i);
        setTool('brush');
      });
      var side = document.createElement('button');
      side.type = 'button';
      side.className = 'bd-color__swap';
      if (state.focus) {
        side.textContent = '✓';
        side.title = t('bd_mark_done', 'Placed');
        side.setAttribute('aria-pressed', String(state.done.has(u.i)));
        side.addEventListener('click', function () { toggleDone(u.i); });
      } else {
        side.textContent = '⇄';
        side.title = tpl('bd_replace', 'Replace all {code} with {brush}', { code: codeOf(u.i), brush: codeOf(state.brush) });
        side.disabled = u.i === state.brush || !u.n;
        side.addEventListener('click', function () { replaceAll(u.i, state.brush); });
      }
      side.setAttribute('aria-label', side.title);
      row.appendChild(pick);
      row.appendChild(side);
      el.legend.appendChild(row);
    });
    var b = state.palette[state.brush];
    el.brushSwatch.style.background = b ? b.hex : '';
    el.brushSwatch.classList.toggle('bd-swatch--empty', !b);
    el.brushCode.textContent = codeOf(state.brush);
    renderPaletteMarks();
    renderStrip(used);
    renderBuy(used);
    el.undo.disabled = !state.undo.length;
    scheduleSave();
  }

  // Color strip for the phone dock: "empty", the colors in use (most used first), then the
  // rest of the palette, so every color is one swipe away from the canvas.
  // Color family from the code's letters: MARD "A12" -> "A", "ZG3" -> "ZG". Numeric codes
  // (many imported palettes) have none.
  function familyOf(code) { var m = /^[A-Za-z]+/.exec(code); return m ? m[0].toUpperCase() : ''; }

  function families() {
    var list = [];
    state.palette.forEach(function (c) { var f = familyOf(c.code); if (f && list.indexOf(f) < 0) list.push(f); });
    return list.length > 1 ? list : [];
  }

  function recentIndexes() {
    var at = {};
    state.palette.forEach(function (c, i) { at[c.code] = i; });
    return state.recent.filter(function (code) { return code in at; }).map(function (code) { return at[code]; });
  }

  // Phone strip tabs: colors in use, recently picked, then one tab per family.
  function renderGroups() {
    var tabs = ['used', 'recent'].concat(families());
    if (tabs.indexOf(state.group) < 0) state.group = 'used';
    el.groups.innerHTML = '';
    tabs.forEach(function (g) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'bd-groups__tab' + (g === state.group ? ' is-active' : '');
      btn.setAttribute('role', 'tab');
      btn.setAttribute('aria-selected', String(g === state.group));
      btn.textContent = g === 'used' ? t('bd_group_used', 'In use') : g === 'recent' ? t('bd_group_recent', 'Recent') : g;
      btn.addEventListener('click', function () {
        state.group = g;
        renderStrip(usedColors());
        el.strip.scrollLeft = 0;
      });
      el.groups.appendChild(btn);
    });
  }

  function renderStrip(used) {
    renderGroups();
    var order;
    if (state.group === 'used') order = [-1].concat(used.map(function (u) { return u.i; }));
    else if (state.group === 'recent') order = [-1].concat(recentIndexes());
    else {
      order = [];
      state.palette.forEach(function (c, i) { if (familyOf(c.code) === state.group) order.push(i); });
    }
    el.strip.innerHTML = '';
    order.forEach(function (i) {
      var c = state.palette[i];
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'bd-strip__item' + (i === state.brush ? ' is-active' : '');
      btn.setAttribute('role', 'option');
      btn.setAttribute('aria-selected', String(i === state.brush));
      btn.innerHTML = '<span class="bd-swatch"></span><span class="bd-strip__code"></span>';
      if (c) btn.firstChild.style.background = c.hex;
      else btn.firstChild.classList.add('bd-swatch--empty');
      btn.lastChild.textContent = codeOf(i);
      btn.addEventListener('click', function () {
        if (state.focus && i >= 0) { state.focusColor = i; renderCanvas(); }
        setBrush(i);
        if (state.tool !== 'fill') setTool('brush');
      });
      el.strip.appendChild(btn);
    });
  }

  function renderProgress(used) {
    el.progress.hidden = !state.focus;
    if (!state.focus) return;
    var doneColors = 0, doneBeads = 0, total = 0;
    used.forEach(function (u) {
      total += u.n;
      if (state.done.has(u.i)) { doneColors++; doneBeads += u.n; }
    });
    el.progress.textContent = tpl('bd_progress', 'Placed: {dc} / {c} colors · {db} / {b} beads', { dc: doneColors, c: used.length, db: doneBeads, b: total });
  }

  // ---------- Bead colors and owned colors ----------

  function ownedKey() {
    return '70015-beads-owned:' + (state.paletteId === 'custom' ? 'custom:' + state.custom.name : 'mard');
  }

  // Owned colors and recently picked colors, both kept per palette family.
  function loadOwned() {
    state.owned = new Set(readStore(ownedKey(), []));
    state.recent = readStore(ownedKey().replace('-owned:', '-recent:'), []);
  }

  // Palette indexes the user marked as owned, or null to use every color.
  function allowedColors() {
    if (!el.ownedOnly.checked) return null;
    var list = [];
    state.palette.forEach(function (c, i) { if (state.owned.has(c.code)) list.push(i); });
    return list.length ? list : null;
  }

  function renderOwnedNote() {
    var n = state.palette.filter(function (c) { return state.owned.has(c.code); }).length;
    el.ownedNote.textContent = el.ownedOnly.checked && !n
      ? t('bd_owned_none', 'No colors marked yet, so all colors are used. Open "All bead colors" below and choose "Click to mark owned".')
      : tpl('bd_owned_note', '{n} colors marked as owned. Mark them under "All bead colors" with "Click to mark owned"; the list is saved in this browser.', { n: n });
  }

  // All colors, with recently picked ones first and a heading per family (A, B, C… for MARD).
  function renderPaletteGrid() {
    el.paletteGrid.innerHTML = '';
    function heading(text) {
      var h = document.createElement('div');
      h.className = 'bd-palette__head';
      h.textContent = text;
      el.paletteGrid.appendChild(h);
    }
    function swatch(i) {
      var c = state.palette[i];
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.dataset.i = i;
      btn.style.background = c.hex;
      btn.style.color = textColor(c);
      btn.title = c.code + ' ' + c.hex;
      btn.setAttribute('aria-label', c.code);
      btn.addEventListener('click', function () { onPaletteClick(i); });
      el.paletteGrid.appendChild(btn);
    }
    var recent = recentIndexes(), fams = families();
    if (recent.length) {
      heading(t('bd_group_recent_long', 'Recently used'));
      recent.forEach(swatch);
    }
    if (fams.length) {
      fams.forEach(function (f) {
        heading(f);
        state.palette.forEach(function (c, i) { if (familyOf(c.code) === f) swatch(i); });
      });
    } else {
      if (recent.length) heading(t('bd_group_all', 'All'));
      state.palette.forEach(function (c, i) { swatch(i); });
    }
    renderPaletteMarks();
  }

  function renderPaletteMarks() {
    el.paletteGrid.classList.toggle('is-owned-only', el.ownedOnly.checked);
    [].forEach.call(el.paletteGrid.querySelectorAll('button[data-i]'), function (btn) {
      var i = +btn.dataset.i, owned = state.owned.has(state.palette[i].code);
      btn.classList.toggle('is-active', state.pickMode === 'brush' && i === state.brush);
      btn.classList.toggle('is-owned', owned);
      if (state.pickMode === 'owned') btn.setAttribute('aria-pressed', String(owned));
      else btn.removeAttribute('aria-pressed');
    });
  }

  function onPaletteClick(i) {
    if (state.pickMode === 'brush') {
      setBrush(i);
      setTool('brush');
      return;
    }
    var code = state.palette[i].code;
    if (state.owned.has(code)) state.owned.delete(code); else state.owned.add(code);
    ownedChanged();
  }

  function ownedChanged() {
    writeStore(ownedKey(), Array.from(state.owned));
    renderPaletteMarks();
    renderOwnedNote();
    if (el.ownedOnly.checked) build();
  }

  onSegmented(el.pickMode, function (mode) {
    state.pickMode = mode;
    setSegmented(el.pickMode, mode);
    el.paletteGrid.classList.toggle('is-marking', mode === 'owned');
    renderPaletteMarks();
  });
  el.ownAll.addEventListener('click', function () {
    state.palette.forEach(function (c) { state.owned.add(c.code); });
    ownedChanged();
  });
  el.ownNone.addEventListener('click', function () {
    state.palette.forEach(function (c) { state.owned.delete(c.code); });
    ownedChanged();
  });
  el.ownedOnly.addEventListener('change', function () {
    writeStore('70015-beads-owned-only', el.ownedOnly.checked);
    renderPaletteMarks();
    renderOwnedNote();
    build();
  });

  function render() {
    if (lifted && lifted.p !== state.pattern) lifted = null;
    if (state.sel && !lifted && (!state.pattern || state.sel.x + state.sel.w > state.w || state.sel.y + state.sel.h > state.h)) state.sel = null;
    if (!state.pattern) {
      el.stats.textContent = '';
      el.progress.hidden = true;
      el.legend.innerHTML = '';
      el.canvas.width = el.canvas.height = 0;
      return;
    }
    renderCanvas();
    renderInfo();
    renderSize();
  }

  // ---------- Editing ----------

  // Brush -1 is "empty": painting or filling with it removes beads.
  // Picking a color also puts it at the front of the recent list (16 kept, saved per palette).
  function setBrush(i) {
    state.brush = i;
    var c = state.palette[i];
    if (c && state.recent[0] !== c.code) {
      state.recent = [c.code].concat(state.recent.filter(function (code) { return code !== c.code; })).slice(0, 16);
      writeStore(ownedKey().replace('-owned:', '-recent:'), state.recent);
      renderPaletteGrid();
    }
    renderInfo();
  }

  function codeOf(i) { return i >= 0 && state.palette[i] ? state.palette[i].code : t('bd_empty', 'Empty'); }

  function setTool(tool) {
    if (tool !== state.tool && state.sel) dropSel();
    state.tool = tool;
    setSegmented(el.tool, tool);
    updateSelBar();
  }

  // Snapshots carry the size too: resizing a canvas is undoable like any edit.
  // Every hand edit goes through here, so this is also where edits are noticed.
  function pushUndo() {
    lifted = null;
    state.undo.push({ p: state.pattern.slice(), w: state.w, h: state.h });
    if (state.undo.length > 50) state.undo.shift();
    state.edited = true;
  }

  function restore(snap) {
    state.pattern = snap.p;
    state.w = snap.w;
    state.h = snap.h;
  }

  function replaceAll(from, to) {
    if (from === to || (to >= 0 && !state.palette[to])) return;
    pushUndo();
    for (var i = 0; i < state.pattern.length; i++) if (state.pattern[i] === from) state.pattern[i] = to;
    render();
  }

  // Grid column/row under the pointer; may lie outside the pattern.
  function gridPos(e) {
    var r = el.canvas.getBoundingClientRect();
    return { x: Math.floor((e.clientX - r.left) / r.width * state.w), y: Math.floor((e.clientY - r.top) / r.height * state.h) };
  }

  function cellAt(e) {
    var p = gridPos(e);
    return p.x >= 0 && p.y >= 0 && p.x < state.w && p.y < state.h ? p.y * state.w + p.x : -1;
  }

  var painting = false;
  var lastPos = null; // where the stroke was at the previous pointer sample

  // Pointer samples arrive tens of pixels apart on a fast swipe, so paint every cell on the
  // straight line between two samples (Bresenham), skipping the parts outside the pattern.
  function paintLine(a, b) {
    var list = [];
    inside(C.lineCells(a, b)).forEach(function (i) { list = list.concat(mirrors(i)); });
    paintCells(list, state.tool === 'eraser' ? -1 : state.brush);
  }

  // Pattern indexes of the points that fall inside the pattern.
  function inside(points) {
    var out = [];
    points.forEach(function (p) { if (p.x >= 0 && p.y >= 0 && p.x < state.w && p.y < state.h) out.push(p.y * state.w + p.x); });
    return out;
  }

  // Cell i plus its mirror images for the symmetry mode in use.
  function mirrors(i) {
    var x = i % state.w, y = (i - x) / state.w, list = [i];
    function add(mx, my) { var k = my * state.w + mx; if (list.indexOf(k) < 0) list.push(k); }
    if (state.sym === 'h' || state.sym === 'both') add(state.w - 1 - x, y);
    if (state.sym === 'v' || state.sym === 'both') add(x, state.h - 1 - y);
    if (state.sym === 'both') add(state.w - 1 - x, state.h - 1 - y);
    return list;
  }

  function paint(i) {
    paintCells(mirrors(i), state.tool === 'eraser' ? -1 : state.brush);
  }

  // Set cells to v (a number, or a function of the index) and redraw only those cells.
  function paintCells(list, v) {
    var ctx = el.canvas.getContext('2d'), opts = previewOpts(), changed = false;
    list.forEach(function (k) {
      var to = typeof v === 'function' ? v(k) : v;
      if (state.pattern[k] === to) return;
      state.pattern[k] = to;
      drawCell(ctx, 0, 0, state.cs, k, opts);
      changed = true;
    });
    if (!changed) return;
    drawMajorLines(ctx, 0, 0, state.cs, wholeGrid());
    drawGuides(ctx);
  }

  // ---------- Line, rectangle, circle ----------
  // The shape is redrawn on every move over the pattern as it was when the drag started
  // (mirrored like the brush). Shift keeps rectangles square and circles round.
  var shape = null; // { a: start cell, base: pattern copy, cells: indexes the shape covers now }
  var SHAPES = { line: true, rect: true, ellipse: true };

  function drawShape(b, square) {
    var a = shape.a;
    if (square && state.tool !== 'line') {
      var d = Math.max(Math.abs(b.x - a.x), Math.abs(b.y - a.y));
      b = { x: a.x + (b.x < a.x ? -d : d), y: a.y + (b.y < a.y ? -d : d) };
    }
    var pts = state.tool === 'line' ? C.lineCells(a, b) : C.shapeCells(state.tool, a, b), list = [];
    inside(pts).forEach(function (i) { list = list.concat(mirrors(i)); });
    var base = shape.base, now = new Set(list);
    paintCells(shape.cells.filter(function (k) { return !now.has(k); }), function (k) { return base[k]; });
    paintCells(list, state.brush);
    shape.cells = list;
  }

  // ---------- Selection ----------
  // Drag a box with the Select tool; drag inside it to move what it holds (Alt-drag moves a
  // copy). A moved selection floats: `lifted` keeps its beads and the pattern under it, and
  // every move stamps the beads (empty cells see through) onto a copy of that pattern. It is
  // dropped where it is by the next edit, a tool change or "Done". The lift is one undo step.
  var lifted = null;  // { p: the pattern array it belongs to, cells: Int16Array, base: Int16Array }
  var selDrag = null; // { from, x, y } while moving; { a, moved } while drawing a new box

  function clampPos(p) { return { x: Math.max(0, Math.min(state.w - 1, p.x)), y: Math.max(0, Math.min(state.h - 1, p.y)) }; }

  function inSel(p) {
    var s = state.sel;
    return s && p.x >= s.x && p.y >= s.y && p.x < s.x + s.w && p.y < s.y + s.h;
  }

  function selIndexes(fn) {
    var s = state.sel;
    for (var y = 0; y < s.h; y++) {
      for (var x = 0; x < s.w; x++) {
        var px = s.x + x, py = s.y + y;
        if (px >= 0 && py >= 0 && px < state.w && py < state.h) fn(py * state.w + px, y * s.w + x);
      }
    }
  }

  function lift(clear) {
    pushUndo(); // also drops any earlier floating selection
    var s = state.sel, cells = new Int16Array(s.w * s.h).fill(-1), base = state.pattern.slice();
    selIndexes(function (i, j) { cells[j] = state.pattern[i]; if (clear) base[i] = -1; });
    lifted = { p: state.pattern, cells: cells, base: base };
  }

  function stamp() {
    state.pattern.set(lifted.base);
    selIndexes(function (i, j) { if (lifted.cells[j] >= 0) state.pattern[i] = lifted.cells[j]; });
    renderCanvas();
  }

  function dropSel() {
    lifted = null;
    selDrag = null;
    state.sel = null;
    if (state.pattern) renderCanvas();
    updateSelBar();
  }

  function drawSelection(ctx) {
    var s = state.sel, cs = state.cs;
    if (!s || state.tool !== 'select') return;
    ctx.save();
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.strokeStyle = '#ffffff';
    ctx.strokeRect(s.x * cs + 1, s.y * cs + 1, s.w * cs - 2, s.h * cs - 2);
    ctx.strokeStyle = '#2563eb';
    ctx.lineDashOffset = 5;
    ctx.strokeRect(s.x * cs + 1, s.y * cs + 1, s.w * cs - 2, s.h * cs - 2);
    ctx.restore();
  }

  function updateSelBar() {
    el.selBar.hidden = state.tool !== 'select';
    [el.selCopy, el.selFlipH, el.selFlipV, el.selClear, el.selDone].forEach(function (b) { b.disabled = !state.sel; });
  }

  function selDown(e) {
    var p = gridPos(e);
    if (inSel(p)) {
      if (!lifted || e.altKey) lift(!e.altKey);
      selDrag = { from: p, x: state.sel.x, y: state.sel.y };
      return;
    }
    lifted = null;
    var a = clampPos(p);
    selDrag = { a: a, moved: false };
    state.sel = { x: a.x, y: a.y, w: 1, h: 1 };
    renderCanvas();
  }

  function selMove(e) {
    var p = gridPos(e), s = state.sel;
    if (selDrag.from) {
      var x = selDrag.x + p.x - selDrag.from.x, y = selDrag.y + p.y - selDrag.from.y;
      if (x === s.x && y === s.y) return;
      s.x = x;
      s.y = y;
      stamp();
      return;
    }
    var b = clampPos(p), a = selDrag.a;
    var next = { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(b.x - a.x) + 1, h: Math.abs(b.y - a.y) + 1 };
    if (next.x === s.x && next.y === s.y && next.w === s.w && next.h === s.h) return;
    selDrag.moved = true;
    state.sel = next;
    renderCanvas();
  }

  function selUp() {
    if (selDrag && selDrag.a && !selDrag.moved) state.sel = null; // a click outside clears it
    selDrag = null;
    renderCanvas();
    renderInfo();
    updateSelBar();
  }

  function flipSel(horizontal) {
    if (!state.sel) return;
    if (!lifted) lift(true);
    var s = state.sel, src = lifted.cells.slice();
    for (var y = 0; y < s.h; y++) {
      for (var x = 0; x < s.w; x++) lifted.cells[y * s.w + x] = src[horizontal ? y * s.w + s.w - 1 - x : (s.h - 1 - y) * s.w + x];
    }
    stamp();
    renderInfo();
  }

  function clearSel() {
    if (!state.sel) return;
    if (lifted) {
      state.pattern.set(lifted.base);
      lifted = null;
    } else {
      pushUndo();
      selIndexes(function (i) { state.pattern[i] = -1; });
    }
    render();
  }

  el.selCopy.addEventListener('click', function () {
    if (!state.sel) return;
    lift(false);
    stamp();
    renderInfo();
    showToast(t('bd_sel_copied', 'Copied. Drag inside the box to move the copy.'));
  });
  el.selFlipH.addEventListener('click', function () { flipSel(true); });
  el.selFlipV.addEventListener('click', function () { flipSel(false); });
  el.selClear.addEventListener('click', clearSel);
  el.selDone.addEventListener('click', dropSel);

  var SYMS = ['off', 'h', 'v', 'both'];
  function renderSym() {
    var labels = {
      off: t('bd_sym_off', 'Mirror: off'), h: t('bd_sym_h', 'Mirror: left-right'),
      v: t('bd_sym_v', 'Mirror: top-bottom'), both: t('bd_sym_both', 'Mirror: 4-way')
    };
    el.sym.textContent = labels[state.sym];
    el.sym.classList.toggle('is-on', state.sym !== 'off');
    el.sym.setAttribute('aria-pressed', String(state.sym !== 'off'));
  }
  el.sym.addEventListener('click', function () {
    state.sym = SYMS[(SYMS.indexOf(state.sym) + 1) % SYMS.length];
    writeStore('70015-beads-sym', state.sym);
    renderSym();
    if (state.pattern) renderCanvas();
  });

  // One finger (or the mouse) draws, or drags the view with the Move tool. Two fingers pinch
  // to zoom and drag to pan; if the second finger lands mid-stroke, that stroke is undone so a
  // pinch never leaves stray beads.
  var pointers = new Map(); // pointerId -> { x, y }
  var stroke = false;       // an edit started by the current touch, undone if it turns into a pinch
  var panning = null;       // Move tool: { x, y, left, top }
  var pinch = null;         // { dist, fx, fy, w, h, scale, mid }

  function pinchInfo() {
    var p = Array.from(pointers.values());
    return { dist: Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y) || 1, mid: { x: (p[0].x + p[1].x) / 2, y: (p[0].y + p[1].y) / 2 } };
  }

  el.canvas.addEventListener('pointerdown', function (e) {
    if (!state.pattern || (e.pointerType === 'mouse' && e.button > 0)) return;
    try { el.canvas.setPointerCapture(e.pointerId); } catch (err) { /* pointer already gone */ }
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.size === 2) {
      if (stroke) { restore(state.undo.pop()); stroke = false; render(); }
      painting = false;
      shape = null;
      selDrag = null;
      panning = null;
      var info = pinchInfo(), r = el.canvas.getBoundingClientRect();
      pinch = { dist: info.dist, fx: (info.mid.x - r.left) / r.width, fy: (info.mid.y - r.top) / r.height, w: r.width, h: r.height, scale: 1, mid: info.mid };
      return;
    }
    if (pointers.size > 2 || pinch) return;
    if (state.tool === 'pan') {
      panning = { x: e.clientX, y: e.clientY, left: el.stage.scrollLeft, top: el.stage.scrollTop };
      return;
    }
    if (state.tool === 'select') {
      selDown(e);
      return;
    }
    var i = cellAt(e);
    if (i < 0) return;
    if (state.tool === 'pick') {
      setBrush(state.pattern[i]); // an empty cell picks the "empty" brush
      setTool('brush');
      return;
    }
    pushUndo();
    stroke = true;
    if (state.tool === 'fill') {
      mirrors(i).forEach(function (k) { C.floodFill(state.pattern, state.w, state.h, k % state.w, Math.floor(k / state.w), state.brush); });
      render();
      return;
    }
    if (SHAPES[state.tool]) {
      shape = { a: gridPos(e), base: state.pattern.slice(), cells: [] };
      drawShape(shape.a, e.shiftKey);
      return;
    }
    painting = true;
    lastPos = gridPos(e);
    paint(i);
  });

  el.canvas.addEventListener('pointermove', function (e) {
    if (!pointers.has(e.pointerId)) return;
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch && pointers.size >= 2) {
      // Scale the canvas with CSS while the fingers move; it is redrawn sharp on release.
      var info = pinchInfo();
      var scale = info.dist / pinch.dist;
      var cs = state.cs * scale;
      scale = Math.max(4, Math.min(maxCs(), cs)) / state.cs;
      el.canvas.style.width = pinch.w * scale + 'px';
      el.canvas.style.height = pinch.h * scale + 'px';
      keepPoint(pinch.fx, pinch.fy, info.mid.x, info.mid.y);
      pinch.scale = scale;
      pinch.mid = info.mid;
      return;
    }
    if (panning) {
      el.stage.scrollLeft = panning.left - (e.clientX - panning.x);
      el.stage.scrollTop = panning.top - (e.clientY - panning.y);
      return;
    }
    if (selDrag) { selMove(e); return; }
    if (shape) { drawShape(gridPos(e), e.shiftKey); return; }
    if (!painting) return;
    var p = gridPos(e);
    paintLine(lastPos, p);
    lastPos = p;
  });

  function endPointer(e) {
    if (!pointers.delete(e.pointerId)) return;
    if (pinch && pointers.size < 2) {
      var done = pinch;
      pinch = null;
      // Redraw at the new cell size; the point between the fingers stays put.
      var r = el.canvas.getBoundingClientRect();
      setZoom(state.cs * done.scale, r.left + done.fx * r.width, r.top + done.fy * r.height);
    }
    if (pointers.size) return;
    panning = null;
    stroke = false;
    if (selDrag) selUp();
    if (shape) {
      shape = null;
      renderInfo();
    }
    if (painting) {
      painting = false;
      renderInfo();
    }
  }
  el.canvas.addEventListener('pointerup', endPointer);
  el.canvas.addEventListener('pointercancel', endPointer);

  function undo() {
    if (!state.undo.length) return;
    restore(state.undo.pop());
    render();
  }
  el.undo.addEventListener('click', undo);
  document.addEventListener('keydown', function (e) {
    if (state.tool === 'select' && state.sel && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) {
      if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); clearSel(); return; }
      if (e.key === 'Escape' || e.key === 'Enter') { dropSel(); return; }
    }
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === 'z' && !/^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName)) {
      e.preventDefault();
      undo();
    }
  });

  el.strays.addEventListener('click', function () {
    if (!state.pattern) return;
    pushUndo();
    var n = C.removeStrays(state.pattern, state.w, state.h);
    if (!n) state.undo.pop(); // nothing changed, so drop the snapshot
    showToast(n ? tpl('bd_strays_done', 'Cleaned up {n} stray beads. Undo brings them back.', { n: n }) : t('bd_strays_none', 'No stray beads found.'));
    render();
  });

  // One-bead outline in the brush color (black when the brush is "empty"), e.g. for keychains.
  el.outline.addEventListener('click', function () {
    if (!state.pattern) return;
    var v = state.brush;
    if (v < 0) {
      v = state.palette.findIndex(function (c) { return c.hex === '#000000'; });
      if (v < 0) v = 0;
    }
    var grows = false;
    pushUndo();
    var r = C.addOutline(state.pattern, state.w, state.h, v);
    if (!r.added) {
      state.undo.pop();
      showToast(t('bd_outline_none', 'Nothing to outline yet.'));
      return;
    }
    if (r.w > MAX_SIDE || r.h > MAX_SIDE) {
      state.undo.pop();
      showToast(tpl('bd_outline_too_big', 'An outline would make the pattern bigger than {max} beads per side.', { max: MAX_SIDE }));
      return;
    }
    grows = r.w !== state.w;
    state.pattern = r.pattern;
    state.w = r.w;
    state.h = r.h;
    if (grows) state.zoom = 0;
    showToast(tpl(grows ? 'bd_outline_grew' : 'bd_outline_done', grows
      ? 'Added {n} {code} beads around the art; the canvas grew by one bead on each side. Undo removes it.'
      : 'Added {n} {code} beads around the art. Undo removes it.', { n: r.added, code: state.palette[v].code }));
    render();
  });

  // ---------- One color at a time ----------

  function pickNextFocus() {
    if (!state.pattern) return;
    var used = usedColors();
    if (used.some(function (u) { return u.i === state.focusColor; })) return;
    var next = used.filter(function (u) { return !state.done.has(u.i); })[0] || used[0];
    state.focusColor = next ? next.i : -1;
  }

  function toggleDone(i) {
    if (state.done.has(i)) state.done.delete(i);
    else {
      state.done.add(i);
      // Move on to the next color still to place.
      if (state.focusColor === i) {
        var next = usedColors().filter(function (u) { return !state.done.has(u.i); })[0];
        if (next) state.focusColor = next.i;
      }
    }
    writeStore(state.progressKey, Array.from(state.done).map(function (k) { return state.palette[k].code; }));
    renderCanvas();
    renderInfo();
  }

  el.focus.addEventListener('change', function () {
    state.focus = el.focus.checked;
    if (state.focus) { state.focusColor = -1; pickNextFocus(); }
    if (state.pattern) render();
  });

  // ---------- Export ----------

  // Printable chart: title line, column/row numbers, grid with codes, color list with counts.
  // With `board`, red outlines and numbers show how the pattern splits onto pegboards.
  function chartCanvas(board) {
    if (!state.pattern) return null;
    var cs = Math.max(12, Math.min(32, Math.floor(4000 / Math.max(state.w, state.h))));
    var axis = Math.round(cs * 1.4), pad = cs, head = cs * 2;
    var used = usedColors();
    var gridW = state.w * cs, width = Math.max(pad * 2 + axis + gridW, 480);
    var itemW = cs * 5.5, perRow = Math.max(1, Math.floor((width - pad * 2) / itemW));
    var legendH = Math.ceil(used.length / perRow) * (cs * 1.5) + cs;
    var height = head + axis + state.h * cs + pad + legendH + pad;

    var c = document.createElement('canvas');
    c.width = width;
    c.height = height;
    var ctx = c.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);
    var font = 'Inter, system-ui, sans-serif';

    ctx.fillStyle = '#111827';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.font = '700 ' + Math.round(cs * 0.6) + 'px ' + font;
    ctx.fillText(state.name + ' · ' + statsText(used), pad, head / 2 + pad / 2);

    var ox = pad + axis, oy = head + axis;
    // Export options (the pegboard pages always keep codes and grid, since they are for placing).
    if (el.exAxes.checked) drawAxes(ctx, ox, oy, cs, axis, wholeGrid(), font);
    drawGrid(ctx, ox, oy, cs, { codes: el.exCodes.checked, grid: el.exGrid.checked, round: el.exRound.checked });

    if (board) {
      var cols = Math.ceil(state.w / board), rows = Math.ceil(state.h / board);
      ctx.strokeStyle = '#e11d48';
      ctx.lineWidth = Math.max(2, cs / 6);
      ctx.font = '800 ' + Math.round(cs * 1.2) + 'px ' + font;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      for (var r = 0; r < rows; r++) {
        for (var k = 0; k < cols; k++) {
          var bx = ox + k * board * cs, by = oy + r * board * cs;
          ctx.strokeRect(bx, by, Math.min(board, state.w - k * board) * cs, Math.min(board, state.h - r * board) * cs);
          var label = String(r * cols + k + 1);
          ctx.lineWidth = Math.max(3, cs / 5);
          ctx.strokeStyle = '#ffffff';
          ctx.strokeText(label, bx + cs * 0.3, by + cs * 0.3);
          ctx.fillStyle = '#e11d48';
          ctx.fillText(label, bx + cs * 0.3, by + cs * 0.3);
          ctx.strokeStyle = '#e11d48';
          ctx.lineWidth = Math.max(2, cs / 6);
        }
      }
    }

    var ly = oy + state.h * cs + pad + cs / 2;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.font = '600 ' + Math.round(cs * 0.5) + 'px ' + font;
    used.forEach(function (u, k) {
      var col = state.palette[u.i];
      var lx = pad + (k % perRow) * itemW, yy = ly + Math.floor(k / perRow) * cs * 1.5;
      ctx.fillStyle = col.hex;
      ctx.fillRect(lx, yy, cs, cs);
      ctx.strokeStyle = 'rgba(0,0,0,0.3)';
      ctx.lineWidth = 1;
      ctx.strokeRect(lx + 0.5, yy + 0.5, cs - 1, cs - 1);
      ctx.fillStyle = '#111827';
      ctx.fillText(col.code + ' × ' + u.n, lx + cs * 1.3, yy + cs / 2);
    });
    return c;
  }

  // Column numbers above and row numbers left of the grid, counted across the whole pattern.
  function drawAxes(ctx, ox, oy, cs, axis, r, font) {
    ctx.font = '500 ' + Math.round(cs * 0.4) + 'px ' + font;
    ctx.fillStyle = '#4b5563';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    var step = cs >= 16 ? 1 : 5;
    for (var x = r.x0 + 1; x <= r.x1; x++) if (x % step === 0 || x === r.x0 + 1) ctx.fillText(String(x), ox + (x - r.x0 - 0.5) * cs, oy - axis / 2);
    ctx.textAlign = 'right';
    for (var y = r.y0 + 1; y <= r.y1; y++) if (y % step === 0 || y === r.y0 + 1) ctx.fillText(String(y), ox - cs * 0.3, oy + (y - r.y0 - 0.5) * cs);
  }

  // One pegboard at PRINT_DPI with a title line and pattern-wide coordinates.
  function boardCanvas(region, cs, title) {
    var pxmm = PRINT_DPI / 25.4;
    var head = 9 * pxmm, axis = 6 * pxmm;
    var c = document.createElement('canvas');
    c.width = Math.ceil(axis + (region.x1 - region.x0) * cs + 4);
    c.height = Math.ceil(head + axis + (region.y1 - region.y0) * cs + 4);
    var ctx = c.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, c.width, c.height);
    var font = 'Inter, system-ui, sans-serif';
    ctx.fillStyle = '#111827';
    ctx.font = '700 ' + Math.round(3.2 * pxmm) + 'px ' + font;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(title, 0, head / 2);
    drawAxes(ctx, axis, head + axis, cs, axis, region, font);
    drawGrid(ctx, axis, head + axis, cs, { codes: true, region: region });
    return c;
  }

  // Overview page, then one page per pegboard with the grid at real size (bead size in mm).
  function boardPdf() {
    if (!state.pattern) return Promise.resolve();
    var board = Math.round(numberIn(el.board, 5, 200, 29));
    var pitch = numberIn(el.pitch, 1, 20, 2.6);
    var margin = 10, pxmm = PRINT_DPI / 25.4, cs = pitch * pxmm;
    var bw = Math.min(board, state.w), bh = Math.min(board, state.h);
    var needW = 6 + bw * pitch + margin * 2, needH = 15 + bh * pitch + margin * 2;
    var paper = PAPERS.filter(function (p) { return p[0] >= needW && p[1] >= needH; })[0];
    if (!paper) {
      showToast(tpl('bd_board_too_big', 'A {n}-bead pegboard of {mm} mm beads is bigger than A3. Use a smaller pegboard size.', { n: board, mm: pitch }));
      return Promise.resolve();
    }
    var cols = Math.ceil(state.w / board), rows = Math.ceil(state.h / board), total = cols * rows;

    var ov = chartCanvas(board);
    var s = Math.min((210 - margin * 2) / ov.width, (297 - margin * 2) / ov.height); // mm per px
    var pages = [{ canvas: ov, pageW: 210 * MM, pageH: 297 * MM, x: margin * MM, y: (297 - margin - ov.height * s) * MM, w: ov.width * s * MM, h: ov.height * s * MM }];

    for (var r = 0; r < rows; r++) {
      for (var k = 0; k < cols; k++) {
        var region = { x0: k * board, y0: r * board, x1: Math.min(state.w, (k + 1) * board), y1: Math.min(state.h, (r + 1) * board) };
        var title = tpl('bd_board_title', '{name} · Board {n} of {total} (row {r}, column {c}) · columns {x0}–{x1}, rows {y0}–{y1} · {mm} mm beads', {
          name: state.name, n: r * cols + k + 1, total: total, r: r + 1, c: k + 1,
          x0: region.x0 + 1, x1: region.x1, y0: region.y0 + 1, y1: region.y1, mm: pitch
        });
        var bc = boardCanvas(region, cs, title);
        var wmm = bc.width / pxmm, hmm = bc.height / pxmm;
        pages.push({ canvas: bc, pageW: paper[0] * MM, pageH: paper[1] * MM, x: margin * MM, y: (paper[1] - margin - hmm) * MM, w: wmm * MM, h: hmm * MM });
      }
    }
    return window.pagesToPdf(pages, 0.88).then(function (blob) {
      ImageExport.download(blob, ImageExport.fileName(state.name + '-boards', 'pdf'));
    });
  }

  el.boardPdf.addEventListener('click', function () {
    var btn = el.boardPdf, label = btn.textContent;
    btn.disabled = true;
    btn.textContent = t('exp_working', '…');
    // Let the button repaint before the heavy drawing starts.
    setTimeout(function () {
      boardPdf().catch(function (err) {
        console.error(err);
        showToast(t('exp_failed', 'Failed'));
      }).then(function () {
        btn.disabled = false;
        btn.textContent = label;
      });
    }, 30);
  });
  el.board.addEventListener('change', function () { writeStore('70015-beads-board', el.board.value); });

  // One pixel per bead, for opening the result back in Aseprite or another pixel editor.
  function pixelCanvas() {
    var c = document.createElement('canvas');
    c.width = state.w;
    c.height = state.h;
    var ctx = c.getContext('2d');
    var img = ctx.createImageData(state.w, state.h);
    for (var i = 0; i < state.pattern.length; i++) {
      var v = state.pattern[i];
      if (v < 0) continue;
      var rgb = state.palette[v].rgb;
      img.data[i * 4] = rgb[0]; img.data[i * 4 + 1] = rgb[1]; img.data[i * 4 + 2] = rgb[2]; img.data[i * 4 + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
    return c;
  }

  ImageExport.mountActions(el.actions, function () { return chartCanvas(0); }, {
    name: function () { return state.name + '-beads'; },
    skip: ['annotate']
  });
  var pixelBtn = document.createElement('button');
  pixelBtn.type = 'button';
  pixelBtn.className = 'btn btn--sm btn--secondary';
  pixelBtn.setAttribute('data-i18n', 'bd_export_pixel');
  pixelBtn.textContent = t('bd_export_pixel', 'Pixel PNG (1 bead = 1 px)');
  pixelBtn.addEventListener('click', function () {
    if (!state.pattern) return;
    ImageExport.toBlob(pixelCanvas(), 'image/png').then(function (b) {
      ImageExport.download(b, ImageExport.fileName(state.name + '-pixels', 'png'));
    });
  });
  el.actions.appendChild(pixelBtn);

  // ---------- Color list as text / CSV ----------

  // Plain text to paste into a shopping note: one "code × count" line per color, most used first.
  // How many to buy: the count plus the loss allowance (rounded up), and whole bags when a bag
  // size is set. Every color needs at least one bag of its own.
  function toBuy(n) {
    var need = Math.ceil(n * (1 + numberIn(el.waste, 0, 100, 0) / 100));
    var pack = parseInt(el.pack.value, 10) || 0;
    return { need: need, bags: pack > 0 ? Math.ceil(need / pack) : 0 };
  }

  function renderBuy(used) {
    var need = 0, bags = 0;
    used.forEach(function (u) { var b = toBuy(u.n); need += b.need; bags += b.bags; });
    var waste = numberIn(el.waste, 0, 100, 0);
    el.buyNote.textContent = tpl('bd_buy_note', 'With {w} % extra: about {need} beads to buy.', { w: waste, need: need }) +
      (bags ? ' ' + tpl('bd_buy_bags', '{bags} bags of {pack} (at least one per color).', { bags: bags, pack: parseInt(el.pack.value, 10) }) : '');
  }

  function listText() {
    var used = usedColors(), waste = numberIn(el.waste, 0, 100, 0);
    return [state.name + ' · ' + statsText(used)].concat(used.map(function (u) {
      var b = toBuy(u.n);
      return state.palette[u.i].code + ' × ' + u.n +
        (waste ? ' → ' + b.need : '') +
        (b.bags ? ' · ' + tpl('bd_bags_n', '{n} bag(s)', { n: b.bags }) : '');
    })).join('\n');
  }

  [el.waste, el.pack].forEach(function (input) {
    input.addEventListener('change', function () {
      writeStore('70015-beads-buy', { waste: el.waste.value, pack: el.pack.value });
      if (state.pattern) renderInfo();
    });
  });

  el.copyList.addEventListener('click', function () {
    if (!state.pattern) return;
    navigator.clipboard.writeText(listText()).then(function () {
      showToast(t('bd_copied_list', 'Color list copied.'));
    }, function () {
      showToast(t('exp_failed', 'Failed'));
    });
  });

  el.csv.addEventListener('click', function () {
    if (!state.pattern) return;
    var rows = ['code,hex,count,to_buy,bags'].concat(usedColors().map(function (u) {
      var c = state.palette[u.i], b = toBuy(u.n);
      return '"' + c.code.replace(/"/g, '""') + '",' + c.hex + ',' + u.n + ',' + b.need + ',' + (b.bags || '');
    }));
    // BOM so Excel opens it as UTF-8 (imported palettes can have non-ASCII codes).
    var blob = new Blob(['﻿' + rows.join('\r\n') + '\r\n'], { type: 'text/csv' });
    ImageExport.download(blob, ImageExport.fileName(state.name + '-colors', 'csv'));
  });

  // ---------- Saved work ----------
  // Each pattern is saved in localStorage a moment after every change; the newest
  // MAX_WORKS stay. The source image is not kept, so a reopened work edits like a blank canvas.
  // ponytail: localStorage (~5 MB); a 200 × 200 work is ~110 KB, move to IndexedDB if people keep many big ones.

  var WORKS_KEY = '70015-beads-works', MAX_WORKS = 12;

  function newWorkId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

  function encodePattern(p) {
    var bytes = new Uint8Array(p.buffer, p.byteOffset, p.byteLength), s = '';
    for (var i = 0; i < bytes.length; i += 8192) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
    return btoa(s);
  }

  function decodePattern(b64) {
    var s = atob(b64), bytes = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) bytes[i] = s.charCodeAt(i);
    return new Int16Array(bytes.buffer);
  }

  function thumbnail() {
    var px = pixelCanvas(), k = Math.max(1, Math.floor(72 / Math.max(state.w, state.h)));
    var c = document.createElement('canvas');
    c.width = state.w * k;
    c.height = state.h * k;
    var ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(px, 0, 0, c.width, c.height);
    return c.toDataURL('image/png');
  }

  function readWorks() {
    var works = readStore(WORKS_KEY, []);
    return Array.isArray(works) ? works : [];
  }

  function saveWork() {
    if (!state.pattern || !state.workId) return;
    var works = readWorks().filter(function (w) { return w.id !== state.workId; });
    works.unshift({
      id: state.workId,
      name: state.name,
      w: state.w,
      h: state.h,
      paletteId: state.paletteId,
      custom: state.paletteId === 'custom'
        ? { name: state.custom.name, text: state.custom.colors.map(function (c) { return c.code + ',' + c.hex; }).join('\n') }
        : null,
      pattern: encodePattern(state.pattern),
      done: Array.from(state.done).map(function (k) { return state.palette[k] ? state.palette[k].code : ''; }),
      updated: Date.now(),
      thumb: thumbnail()
    });
    works = works.slice(0, MAX_WORKS);
    // When storage is full, keep dropping the oldest until it fits (the current one always stays).
    while (works.length) {
      try { localStorage.setItem(WORKS_KEY, JSON.stringify(works)); break; } catch (e) {
        if (works.length === 1) break;
        works.pop();
      }
    }
    renderWorks();
  }

  var saveTimer = null;
  function scheduleSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () { saveTimer = null; saveWork(); }, 800);
  }

  // Before switching to another work, save the one being left if a save is still pending.
  function flushSave() {
    if (saveTimer === null) return;
    clearTimeout(saveTimer);
    saveTimer = null;
    saveWork();
  }

  // Switch palettes without remapping (the pattern being loaded already matches it).
  function applyPalette(id, custom) {
    if (id === 'custom' && custom) {
      state.custom = custom;
      state.paletteId = 'custom';
      state.palette = custom.colors;
    } else {
      state.paletteId = builtIn[id] ? id : 'mard';
      state.palette = builtIn[state.paletteId];
    }
    setSegmented(el.palette, state.paletteId);
    loadOwned();
    renderPaletteNote();
    renderOwnedNote();
    renderPaletteGrid();
  }

  // Show a saved or imported pattern for editing (no source image).
  function showWork(w) {
    state.src = null;
    state.natural = null;
    state.capped = false;
    state.name = w.name || 'beads';
    state.workId = w.id;
    state.w = w.w;
    state.h = w.h;
    state.pattern = w.pattern;
    state.undo = [];
    state.edited = false;
    state.zoom = 0;
    state.progressKey = '70015-beads-progress:work-' + w.id;
    state.done = new Set();
    state.palette.forEach(function (c, i) { if ((w.done || []).indexOf(c.code) >= 0) state.done.add(i); });
    if (!state.palette[state.brush]) state.brush = 0;
    el.w.value = el.h.value = '';
    syncName();
    setStatus('');
    enterEditor();
    render();
    el.result.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }

  function openWork(id) {
    flushSave();
    var w = readWorks().filter(function (x) { return x.id === id; })[0];
    if (!w) return;
    applyPalette(w.paletteId, w.paletteId === 'custom' && w.custom
      ? { name: w.custom.name, colors: C.parsePaletteText(w.custom.text) } : null);
    showWork({ id: w.id, name: w.name, w: w.w, h: w.h, pattern: decodePattern(w.pattern), done: w.done });
  }

  // ---------- Work file (export / import) ----------
  // A small JSON file holding only the colors in use (code + hex) and each cell's index into
  // that list, so it opens the same way on another device or with another palette loaded.

  var WORK_FILE_APP = '70015-beads';

  function syncName() { el.name.value = state.name === 'beads' ? '' : state.name; }

  el.name.addEventListener('input', function () {
    state.name = el.name.value.trim() || 'beads';
    if (state.pattern) scheduleSave();
  });

  // Save now, then open the Isometric Studio, which reads the work from the same site storage.
  $('bdToIso').addEventListener('click', function () {
    if (!state.pattern) return;
    if (!state.workId) state.workId = newWorkId();
    clearTimeout(saveTimer);
    saveTimer = null;
    saveWork();
    var page = /-extension:$/.test(location.protocol) ? 'isometric.html' : 'isometric';
    window.open(page + '#beads=' + state.workId, '_blank');
  });

  el.exportWork.addEventListener('click', function () {
    if (!state.pattern) return;
    var used = usedColors(), slot = {};
    used.forEach(function (u, k) { slot[u.i] = k; });
    var cells = new Int16Array(state.pattern.length);
    for (var i = 0; i < cells.length; i++) cells[i] = state.pattern[i] < 0 ? -1 : slot[state.pattern[i]];
    var file = {
      app: WORK_FILE_APP,
      version: 1,
      name: state.name,
      w: state.w,
      h: state.h,
      palette: state.paletteId,
      colors: used.map(function (u) { return [state.palette[u.i].code, state.palette[u.i].hex]; }),
      cells: encodePattern(cells),
      done: Array.from(state.done).map(function (k) { return state.palette[k] ? state.palette[k].code : ''; })
    };
    var blob = new Blob([JSON.stringify(file)], { type: 'application/json' });
    ImageExport.download(blob, ImageExport.fileName(state.name + '-work', 'json'));
  });

  // Untrusted input: check every field before using it.
  function readWorkFile(text) {
    var f = JSON.parse(text);
    var okSize = function (n) { return Number.isInteger(n) && n >= 1 && n <= MAX_SIDE; };
    if (!f || f.app !== WORK_FILE_APP || !okSize(f.w) || !okSize(f.h) || !Array.isArray(f.colors) || typeof f.cells !== 'string') throw new Error('format');
    var colors = f.colors.filter(function (c) {
      return Array.isArray(c) && typeof c[0] === 'string' && c[0].length && c[0].length <= 12 && /^#[0-9a-f]{6}$/i.test(c[1]);
    });
    if (colors.length !== f.colors.length || colors.length > 1000) throw new Error('colors');
    var cells = decodePattern(f.cells);
    if (cells.length !== f.w * f.h) throw new Error('cells');
    for (var i = 0; i < cells.length; i++) if (cells[i] < -1 || cells[i] >= colors.length) throw new Error('cells');
    return { name: typeof f.name === 'string' ? f.name.slice(0, 60) : 'beads', w: f.w, h: f.h, palette: f.palette, colors: colors, cells: cells, done: Array.isArray(f.done) ? f.done.filter(function (c) { return typeof c === 'string'; }) : [] };
  }

  function importWork(f) {
    flushSave();
    // The file's own palette when every code exists there with the same color; otherwise
    // the file's colors become an imported palette, so nothing changes color.
    var pal = builtIn[f.palette], at = {}, map = null;
    if (pal) {
      pal.forEach(function (c, i) { at[c.code] = i; });
      map = f.colors.map(function (c) { var i = at[c[0]]; return i !== undefined && pal[i].hex === c[1].toUpperCase() ? i : -2; });
      if (map.indexOf(-2) >= 0) map = null;
    }
    if (map) applyPalette(f.palette, null);
    else {
      var colors = C.parsePaletteText(f.colors.map(function (c) { return c[0] + ',' + c[1]; }).join('\n'));
      applyPalette('custom', { name: f.name, colors: colors });
      map = colors.map(function (c, i) { return i; });
    }
    var pattern = new Int16Array(f.cells.length);
    for (var i = 0; i < pattern.length; i++) pattern[i] = f.cells[i] < 0 ? -1 : map[f.cells[i]];
    showWork({ id: newWorkId(), name: f.name, w: f.w, h: f.h, pattern: pattern, done: f.done });
    scheduleSave();
  }

  el.importWork.addEventListener('click', function () { el.workInput.click(); });
  el.workInput.addEventListener('change', function () {
    var file = el.workInput.files[0];
    el.workInput.value = '';
    if (!file) return;
    file.text().then(function (text) { importWork(readWorkFile(text)); }).catch(function () {
      showToast(t('bd_work_file_bad', 'This is not a bead work file, or it is damaged.'));
    });
  });

  function deleteWork(id) {
    if (!window.confirm(t('bd_work_delete_confirm', 'Delete this saved work? This cannot be undone.'))) return;
    writeStore(WORKS_KEY, readWorks().filter(function (w) { return w.id !== id; }));
    if (state.workId === id) state.workId = ''; // keep editing, but stop saving it back
    renderWorks();
  }

  function renderWorks() {
    var works = readWorks();
    el.works.hidden = !works.length;
    el.worksList.innerHTML = '';
    works.forEach(function (w) {
      var item = document.createElement('div');
      item.className = 'bd-work' + (w.id === state.workId ? ' is-active' : '');
      var open = document.createElement('button');
      open.type = 'button';
      open.className = 'bd-work__open';
      open.innerHTML = '<img alt=""><span class="bd-work__name"></span><span class="bd-work__meta"></span>';
      open.firstChild.src = w.thumb || '';
      var name = w.name && w.name !== 'beads' ? w.name : t('bd_untitled', 'Untitled');
      open.children[1].textContent = name;
      open.children[2].textContent = w.w + ' × ' + w.h + ' · ' + new Date(w.updated).toLocaleDateString();
      open.setAttribute('aria-label', tpl('bd_work_open', 'Open {name}', { name: name }));
      open.addEventListener('click', function () { openWork(w.id); });
      var del = document.createElement('button');
      del.type = 'button';
      del.className = 'bd-work__delete';
      del.textContent = '×';
      del.title = t('bd_work_delete', 'Delete');
      del.setAttribute('aria-label', del.title + ' ' + name);
      del.addEventListener('click', function () { deleteWork(w.id); });
      item.appendChild(open);
      item.appendChild(del);
      el.worksList.appendChild(item);
    });
  }

  // ---------- Settings ----------

  onSegmented(el.mode, function (mode) {
    if (!state.src) { setMode(mode); return; }
    if (mode === 'pixel') setMode(mode, C.detectScale(state.src.data, state.src.w, state.src.h));
    else if (mode === 'ai') {
      state.grid = C.detectGrid(state.src.data, state.src.w, state.src.h);
      setMode(mode, state.grid ? state.grid.x.p : 8);
    } else setMode(mode);
    build();
  });

  el.cell.addEventListener('change', function () {
    var v = parseFloat(el.cell.value);
    if (!(v >= 1)) { el.cell.value = state.cell; return; }
    state.cell = state.mode === 'ai' ? Math.round(v * 10) / 10 : Math.round(v);
    el.cell.value = state.cell;
    build();
  });

  el.redetect.addEventListener('click', function () {
    if (!state.src) return;
    state.grid = C.detectGrid(state.src.data, state.src.w, state.src.h);
    if (state.grid) setMode('ai', state.grid.x.p);
    build();
  });

  // ---------- Blank canvas ----------

  // Show the editor; image-only settings hide when there is no source image.
  function enterEditor() {
    document.body.classList.add('is-working');
    el.settings.classList.toggle('is-blank', !state.src);
    el.result.hidden = false;
  }

  function newCanvas(w, h) {
    w = Math.max(1, Math.min(MAX_SIDE, parseInt(w, 10) || 29));
    h = Math.max(1, Math.min(MAX_SIDE, parseInt(h, 10) || 29));
    flushSave();
    state.src = null;
    state.natural = null;
    state.capped = false;
    state.name = 'beads';
    state.workId = newWorkId();
    state.zoom = 0;
    state.edited = false;
    syncName();
    state.w = w;
    state.h = h;
    state.pattern = new Int16Array(w * h).fill(-1);
    state.undo = [];
    state.done = new Set();
    state.progressKey = '70015-beads-progress:work-' + state.workId;
    el.w.value = el.h.value = '';
    // Start with black, the usual first outline color, when the palette has it.
    var black = state.palette.findIndex(function (c) { return c.hex === '#000000'; });
    state.brush = black >= 0 ? black : 0;
    setTool('brush');
    setStatus('');
    enterEditor();
    render();
  }
  el.newBtn.addEventListener('click', function () { newCanvas(el.newW.value, el.newH.value); });

  // Without a source image, new width/height resize the canvas itself; beads keep their
  // place from the top-left corner. Undoable.
  function resizeCanvas() {
    var size = targetSize(state.w, state.h);
    if (size.w === state.w && size.h === state.h) return;
    if (size.w > MAX_SIDE || size.h > MAX_SIDE) {
      setStatus(tpl('bd_too_big', 'That makes {w} × {h} beads, more than {max} per side.', { w: size.w, h: size.h, max: MAX_SIDE }));
      return;
    }
    pushUndo();
    var next = new Int16Array(size.w * size.h).fill(-1);
    for (var y = 0; y < Math.min(state.h, size.h); y++) {
      for (var x = 0; x < Math.min(state.w, size.w); x++) next[y * size.w + x] = state.pattern[y * state.w + x];
    }
    state.w = size.w;
    state.h = size.h;
    state.pattern = next;
    state.zoom = 0;
    setStatus('');
    render();
  }

  function sizeChanged() {
    if (state.src) build();
    else if (state.pattern) resizeCanvas();
  }
  el.w.addEventListener('change', sizeChanged);
  el.h.addEventListener('change', sizeChanged);

  // Without a source image, switching palettes moves each bead to its closest new color.
  function remapPattern(from, to) {
    var map = new Map();
    for (var i = 0; i < state.pattern.length; i++) {
      var v = state.pattern[i];
      if (v < 0) continue;
      if (!map.has(v)) map.set(v, from[v] ? C.nearest(from[v].lab, to) : 0);
      state.pattern[i] = map.get(v);
    }
  }

  // Bead size only changes the centimetres, not the pattern. Remembered for next time.
  function setPitch(mm) {
    el.pitch.value = mm;
    setSegmented(el.pitchPreset, String(numberIn(el.pitch, 1, 20, 2.6)));
    writeStore('70015-beads-pitch', el.pitch.value);
    if (state.pattern) { renderInfo(); renderSize(); }
  }
  el.pitch.addEventListener('change', function () { setPitch(el.pitch.value); });
  onSegmented(el.pitchPreset, setPitch);

  // Centimetres -> bead count for that side; the other side follows the proportions.
  function fromCm(input, beadField, otherField) {
    var cm = parseFloat(input.value);
    if (!(cm > 0)) return;
    beadField.value = Math.max(1, Math.round(cm * 10 / pitch()));
    otherField.value = '';
    sizeChanged();
  }
  el.cmW.addEventListener('change', function () { fromCm(el.cmW, el.w, el.h); });
  el.cmH.addEventListener('change', function () { fromCm(el.cmH, el.h, el.w); });

  function usePalette(id) {
    var before = state.palette;
    state.paletteId = id;
    state.palette = id === 'custom' ? state.custom.colors : builtIn[id];
    state.brush = 0;
    setSegmented(el.palette, id);
    loadOwned();
    renderPaletteNote();
    renderOwnedNote();
    renderPaletteGrid();
    if (state.src) build();
    else if (state.pattern) {
      remapPattern(before, state.palette);
      state.undo = []; // older snapshots hold the old palette's indexes
      render();
    }
  }

  function renderPaletteNote() {
    el.paletteNote.textContent = state.paletteId === 'custom'
      ? tpl('bd_pal_loaded', 'Using {name}: {n} colors.', { name: state.custom.name, n: state.custom.colors.length })
      : t('bd_pal_note', 'Import a .gpl or .hex palette (Aseprite, Lospec), or a text file with one "code,#RRGGBB" per line.');
  }

  onSegmented(el.palette, function (id) {
    if (id === 'custom') { el.paletteInput.click(); return; }
    usePalette(id);
  });

  el.paletteInput.addEventListener('change', function () {
    var file = el.paletteInput.files[0];
    el.paletteInput.value = '';
    if (!file) return;
    file.text().then(function (text) {
      var colors = C.parsePaletteText(text);
      if (colors.length < 2) { showToast(t('bd_pal_bad', 'No colors found in this file.')); return; }
      state.custom = { name: file.name, colors: colors };
      usePalette('custom');
    });
  });

  function renderMax() {
    var v = parseInt(el.max.value, 10);
    el.maxValue.textContent = v ? String(v) : t('bd_no_limit', 'No limit');
  }
  el.max.addEventListener('input', renderMax);
  el.max.addEventListener('change', build);
  el.bg.addEventListener('change', build);

  onSegmented(el.tool, setTool);
  updateSelBar();
  [el.codes, el.round, el.center].forEach(function (box) {
    box.addEventListener('change', function () { if (state.pattern) renderCanvas(); });
  });

  var resizeTimer;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () { if (state.pattern) renderCanvas(); }, 150);
  });

  // ---------- Input ----------

  el.input.addEventListener('change', function () { loadFile(el.input.files[0]); el.input.value = ''; });
  ['dragenter', 'dragover'].forEach(function (evt) {
    el.drop.addEventListener(evt, function (e) { e.preventDefault(); el.drop.classList.add('is-dragover'); });
  });
  ['dragleave', 'drop'].forEach(function (evt) {
    el.drop.addEventListener(evt, function (e) { e.preventDefault(); el.drop.classList.remove('is-dragover'); });
  });
  el.drop.addEventListener('drop', function (e) { loadFile(e.dataTransfer.files[0]); });
  window.addEventListener('paste', function (e) {
    var items = (e.clipboardData && e.clipboardData.items) || [];
    for (var i = 0; i < items.length; i++) {
      if (/^image\//.test(items[i].type)) { e.preventDefault(); loadFile(items[i].getAsFile()); return; }
    }
  });

  window.onLangChange = function () {
    renderModeNote();
    renderMax();
    renderPaletteNote();
    renderOwnedNote();
    renderWorks();
    renderSym();
    renderPaletteGrid();
    if (state.pattern) renderInfo();
  };

  el.pitch.value = readStore('70015-beads-pitch', '2.6');
  setSegmented(el.pitchPreset, String(numberIn(el.pitch, 1, 20, 2.6)));
  el.board.value = readStore('70015-beads-board', '29');
  var buy = readStore('70015-beads-buy', {});
  if (buy && buy.waste !== undefined) el.waste.value = buy.waste;
  if (buy && buy.pack !== undefined) el.pack.value = buy.pack;
  state.sym = SYMS.indexOf(readStore('70015-beads-sym', 'off')) >= 0 ? readStore('70015-beads-sym', 'off') : 'off';
  renderSym();
  el.ownedOnly.checked = readStore('70015-beads-owned-only', false) === true;
  loadOwned();
  setMode('pixel', 1);
  renderMax();
  renderPaletteGrid();
  renderOwnedNote();
  renderWorks();

  // Opened from another tool's "Bead pattern" button (js/export.js).
  ImageExport.receiveHandoff('beads', function (blob) {
    loadFile(new File([blob], 'image.png', { type: 'image/png' }));
  });
})();

/**
 * 70015 SVG Editor v2
 * Upgraded: zoom/pan, polygon/star, multi-select, align, grid/snap, rotation, gradients.
 */

(function () {
  'use strict';

  var SVG_NS = 'http://www.w3.org/2000/svg';
  var XLINK_NS = 'http://www.w3.org/1999/xlink';

  // DOM
  var artboard = document.getElementById('artboard');
  var stage = document.getElementById('stage');
  var overlay = document.getElementById('overlay');
  var selBox = document.getElementById('selBox');
  var handles = overlay.querySelectorAll('.editor__handle');
  var rotateHandle = document.getElementById('rotateHandle');
  var propType = document.getElementById('propType');
  var props = document.getElementById('props');
  var codeView = document.getElementById('codeView');
  var toast = document.getElementById('toast');

  // State
  var tool = 'select';
  var selected = [];
  var drawing = null;
  var dragging = null;
  var resizing = null;
  var rotating = null;
  var panning = null;
  var penPoints = [];
  var polygonPoints = [];
  var polygonPreview = null;
  var spaceDown = false;
  var history = [];
  var historyIdx = -1;
  var maxHistory = 50;
  var maxHistoryBytes = 8 * 1024 * 1024;
  var historyBytes = 0;
  var uidCounter = 0;
  var clipboard = [];
  var codeDirty = false;
  var geometryRatioLocked = true;
  var pathEditing = null;
  var pathNodeDragging = null;

  var pathNodeLayer = document.createElement('div');
  pathNodeLayer.className = 'editor__path-nodes';
  pathNodeLayer.hidden = true;
  overlay.appendChild(pathNodeLayer);

  // Document bounds and viewport (zoom/pan via viewBox)
  var DOC = { x: 0, y: 0, w: 800, h: 600 };
  var VB = { x: 0, y: 0, w: 800, h: 600 };
  var GRID = 20;
  var showGrid = false;
  var snapToGrid = false;

  var SWATCHES = ['#7dd3fc', '#203848', '#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#000000', '#ffffff', '#6b7280', '#fbbf24'];

  function uid() { return 'el-' + (++uidCounter); }
  function t(key, fallback) { return (typeof window.t === 'function') ? window.t(key) : fallback; }
  function tpl(key, fallback, vars) {
    var text = t(key, fallback);
    Object.keys(vars || {}).forEach(function (name) {
      text = text.replace(new RegExp('\\{' + name + '\\}', 'g'), vars[name]);
    });
    return text;
  }
  function showToast(m, d) { d = d || 2000; toast.textContent = m; toast.classList.add('is-visible'); setTimeout(function () { toast.classList.remove('is-visible'); }, d); }

  function el(tag, attrs) {
    var node = document.createElementNS(SVG_NS, tag);
    if (attrs) for (var k in attrs) node.setAttribute(k, attrs[k]);
    return node;
  }

  function escapeAttr(s) { return s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function optionMarkup(value, label, current) {
    return '<option value="' + escapeAttr(String(value)) + '"' + (String(value) === String(current) ? ' selected' : '') + '>' + escapeAttr(String(label)) + '</option>';
  }
  function normalizeHex(c) {
    if (!c) return '#000000';
    if (c[0] === '#') { if (c.length === 7) return c; if (c.length === 4) return '#' + c[1]+c[1]+c[2]+c[2]+c[3]+c[3]; return '#000000'; }
    var m = c.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
    if (m) return '#' + [1,2,3].map(function(i){ return ('0'+parseInt(m[i],10).toString(16)).slice(-2); }).join('');
    return '#000000';
  }

  function formatNumber(value) {
    var rounded = Math.round(Number(value) * 1000) / 1000;
    return String(Object.is(rounded, -0) ? 0 : rounded);
  }

  var PATH_PARAM_COUNTS = { M: 2, L: 2, H: 1, V: 1, C: 6, S: 4, Q: 4, T: 2, A: 7, Z: 0 };

  function parsePathData(data) {
    var tokens = String(data || '').match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g) || [];
    var segments = [], index = 0, command = null;
    var x = 0, y = 0, subpathX = 0, subpathY = 0;
    while (index < tokens.length) {
      if (/^[a-zA-Z]$/.test(tokens[index])) command = tokens[index++];
      if (!command) throw new Error('Missing path command');
      var upper = command.toUpperCase();
      var relative = command !== upper;
      var count = PATH_PARAM_COUNTS[upper];
      if (count === undefined) throw new Error('Unsupported path command');
      if (upper === 'Z') {
        segments.push({ cmd: 'Z', values: [] });
        x = subpathX; y = subpathY; command = null;
        continue;
      }
      var firstGroup = true;
      while (index < tokens.length && !/^[a-zA-Z]$/.test(tokens[index])) {
        if (index + count > tokens.length) throw new Error('Incomplete path command');
        var values = tokens.slice(index, index + count).map(Number);
        if (values.some(function (value) { return !isFinite(value); })) throw new Error('Invalid path number');
        index += count;
        var normalized = upper;
        if (upper === 'M' && !firstGroup) normalized = 'L';
        if (normalized === 'H') {
          values = [relative ? x + values[0] : values[0], y];
          normalized = 'L';
        } else if (normalized === 'V') {
          values = [x, relative ? y + values[0] : values[0]];
          normalized = 'L';
        } else if (relative) {
          if (normalized === 'A') {
            values[5] += x; values[6] += y;
          } else {
            for (var valueIndex = 0; valueIndex < values.length; valueIndex += 2) {
              values[valueIndex] += x;
              values[valueIndex + 1] += y;
            }
          }
        }
        segments.push({ cmd: normalized, values: values });
        var endpoint = pathSegmentEndpoint(segments[segments.length - 1]);
        if (endpoint) { x = endpoint.x; y = endpoint.y; }
        if (normalized === 'M') { subpathX = x; subpathY = y; }
        firstGroup = false;
        if (upper === 'M') command = relative ? 'l' : 'L';
      }
      if (firstGroup) throw new Error('Missing path values');
    }
    if (!segments.length || segments[0].cmd !== 'M') throw new Error('Path must start with M');
    return segments;
  }

  function serializePathData(segments) {
    return segments.map(function (segment) {
      return segment.cmd + (segment.values.length ? segment.values.map(formatNumber).join(' ') : '');
    }).join(' ');
  }

  function pathSegmentEndpoint(segment) {
    if (!segment) return null;
    var indexes = { M: [0, 1], L: [0, 1], C: [4, 5], S: [2, 3], Q: [2, 3], T: [0, 1], A: [5, 6] }[segment.cmd];
    return indexes ? { x: segment.values[indexes[0]], y: segment.values[indexes[1]], xIndex: indexes[0], yIndex: indexes[1] } : null;
  }

  function pathSegmentStart(segments, targetIndex) {
    var current = { x: 0, y: 0 }, subpath = { x: 0, y: 0 };
    for (var i = 0; i < targetIndex; i++) {
      var segment = segments[i];
      var endpoint = pathSegmentEndpoint(segment);
      if (endpoint) current = { x: endpoint.x, y: endpoint.y };
      if (segment.cmd === 'M') subpath = { x: current.x, y: current.y };
      if (segment.cmd === 'Z') current = { x: subpath.x, y: subpath.y };
    }
    return current;
  }

  function matrixOf(node) {
    var consolidated = node && node.transform && node.transform.baseVal ? node.transform.baseVal.consolidate() : null;
    var m = consolidated ? consolidated.matrix : null;
    return m ? new DOMMatrix([m.a, m.b, m.c, m.d, m.e, m.f]) : new DOMMatrix();
  }

  function matrixText(m) {
    return [m.a, m.b, m.c, m.d, m.e, m.f].map(function (value) {
      var rounded = Math.abs(value) < 0.000001 ? 0 : Math.round(value * 1000000) / 1000000;
      return String(rounded);
    }).join(' ');
  }

  function setNodeMatrix(node, matrix) {
    var identity = Math.abs(matrix.a - 1) < 0.000001 && Math.abs(matrix.b) < 0.000001 &&
      Math.abs(matrix.c) < 0.000001 && Math.abs(matrix.d - 1) < 0.000001 &&
      Math.abs(matrix.e) < 0.000001 && Math.abs(matrix.f) < 0.000001;
    if (identity) node.removeAttribute('transform');
    else node.setAttribute('transform', 'matrix(' + matrixText(matrix) + ')');
  }

  function translationMatrix(dx, dy) {
    return new DOMMatrix().translate(dx, dy);
  }

  function scaleAtMatrix(sx, sy, cx, cy) {
    return new DOMMatrix().translate(cx, cy).scale(sx, sy).translate(-cx, -cy);
  }

  function rotateAtMatrix(angle, cx, cy) {
    return new DOMMatrix().translate(cx, cy).rotate(angle).translate(-cx, -cy);
  }

  function transformPoint(matrix, x, y) {
    var point = new DOMPoint(x, y).matrixTransform(matrix);
    return { x: point.x, y: point.y };
  }

  function getParentBounds(node, matrix) {
    var bb = node.getBBox();
    var m = matrix || matrixOf(node);
    var points = [
      transformPoint(m, bb.x, bb.y),
      transformPoint(m, bb.x + bb.width, bb.y),
      transformPoint(m, bb.x, bb.y + bb.height),
      transformPoint(m, bb.x + bb.width, bb.y + bb.height)
    ];
    var xs = points.map(function (point) { return point.x; });
    var ys = points.map(function (point) { return point.y; });
    var minX = Math.min.apply(Math, xs), maxX = Math.max.apply(Math, xs);
    var minY = Math.min.apply(Math, ys), maxY = Math.max.apply(Math, ys);
    return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
  }

  function pointerInParent(e, node) {
    var parent = node.parentNode;
    var ctm = parent && parent.getScreenCTM ? parent.getScreenCTM() : null;
    if (!ctm) return getMouse(e);
    var point = new DOMPoint(e.clientX, e.clientY).matrixTransform(ctm.inverse());
    return { x: point.x, y: point.y };
  }

  function rotationOf(node) {
    var m = matrixOf(node);
    return Math.atan2(m.b, m.a) * 180 / Math.PI;
  }

  function translateNode(node, dx, dy, baseMatrix) {
    setNodeMatrix(node, translationMatrix(dx, dy).multiply(baseMatrix || matrixOf(node)));
  }

  // ---- Viewport ----
  function applyViewBox() {
    artboard.setAttribute('viewBox', VB.x + ' ' + VB.y + ' ' + VB.w + ' ' + VB.h);
    var zoom = DOC.w / VB.w;
    document.getElementById('zoomLabel').textContent = Math.round(zoom * 100) + '%';
    updateSelection();
    updateGrid();
  }

  function documentViewBox() {
    return DOC.x + ' ' + DOC.y + ' ' + DOC.w + ' ' + DOC.h;
  }

  function fitDocument() {
    VB = { x: DOC.x, y: DOC.y, w: DOC.w, h: DOC.h };
    applyViewBox();
  }

  function syncCanvasControls() {
    var widthInput = document.getElementById('canvasWidth');
    var heightInput = document.getElementById('canvasHeight');
    var preset = document.getElementById('canvasPreset');
    var label = document.getElementById('canvasSizeLabel');
    if (widthInput) widthInput.value = Math.round(DOC.w * 1000) / 1000;
    if (heightInput) heightInput.value = Math.round(DOC.h * 1000) / 1000;
    if (label) label.textContent = (Math.round(DOC.w * 1000) / 1000) + ' × ' + (Math.round(DOC.h * 1000) / 1000);
    if (preset) {
      var value = DOC.w + 'x' + DOC.h;
      preset.value = Array.from(preset.options).some(function (option) { return option.value === value; }) ? value : 'custom';
    }
  }

  function getMouse(e) {
    var rect = stage.getBoundingClientRect();
    var scaleX = VB.w / rect.width;
    var scaleY = VB.h / rect.height;
    var scale = Math.max(scaleX, scaleY);
    var renderW = VB.w / scale;
    var renderH = VB.h / scale;
    var offsetX = (rect.width - renderW) / 2;
    var offsetY = (rect.height - renderH) / 2;
    return {
      x: Math.round(((e.clientX - rect.left - offsetX) * scale + VB.x) * 1000) / 1000,
      y: Math.round(((e.clientY - rect.top - offsetY) * scale + VB.y) * 1000) / 1000
    };
  }

  function svgToScreen(x, y) {
    var rect = stage.getBoundingClientRect();
    var scaleX = VB.w / rect.width;
    var scaleY = VB.h / rect.height;
    var scale = Math.max(scaleX, scaleY);
    var renderW = VB.w / scale;
    var renderH = VB.h / scale;
    var offsetX = (rect.width - renderW) / 2;
    var offsetY = (rect.height - renderH) / 2;
    return { x: (x - VB.x) / scale + offsetX, y: (y - VB.y) / scale + offsetY };
  }

  function snapVal(v) { return snapToGrid ? Math.round(v / GRID) * GRID : v; }

  // ---- Grid ----
  var gridPattern = null;
  function initGrid() {
    var defs = artboard.querySelector('defs') || el('defs');
    if (!artboard.querySelector('defs')) artboard.insertBefore(defs, artboard.firstChild);
    gridPattern = artboard.querySelector('#gridPattern');
    if (!gridPattern) {
      gridPattern = el('pattern', { id: 'gridPattern', width: GRID, height: GRID, patternUnits: 'userSpaceOnUse' });
      gridPattern.appendChild(el('path', { d: 'M ' + GRID + ' 0 L 0 0 0 ' + GRID, fill: 'none', stroke: 'currentColor', 'stroke-width': 0.5, opacity: 0.3 }));
      defs.appendChild(gridPattern);
    }
    var rect = artboard.querySelector('#gridRect');
    if (!rect) {
      rect = el('rect', { id: 'gridRect', width: '100%', height: '100%', fill: 'url(#gridPattern)', opacity: '0', 'pointer-events': 'none' });
    }
    var firstUserNode = Array.from(artboard.children).find(function (node) { return node.tagName !== 'defs' && node !== rect; });
    if (firstUserNode) artboard.insertBefore(rect, firstUserNode); else artboard.appendChild(rect);
    updateGrid();
  }

  function updateGrid() {
    var gr = artboard.querySelector('#gridRect');
    if (gr) {
      gr.setAttribute('x', DOC.x);
      gr.setAttribute('y', DOC.y);
      gr.setAttribute('width', DOC.w);
      gr.setAttribute('height', DOC.h);
      gr.setAttribute('opacity', showGrid ? '1' : '0');
    }
  }

  // ---- History ----
  function cleanArtboardClone() {
    var clone = artboard.cloneNode(true);
    var gr = clone.querySelector('#gridRect'); if (gr) gr.remove();
    var gp = clone.querySelector('#gridPattern'); if (gp) gp.remove();
    var defs = clone.querySelector('defs'); if (defs && defs.children.length === 0) defs.remove();
    return clone;
  }

  function currentHistoryState() {
    return {
      markup: cleanArtboardClone().innerHTML,
      viewBox: documentViewBox(),
      document: { x: DOC.x, y: DOC.y, w: DOC.w, h: DOC.h },
      viewport: { x: VB.x, y: VB.y, w: VB.w, h: VB.h }
    };
  }

  function snapshot() {
    while (history.length > historyIdx + 1) historyBytes -= history.pop().bytes;
    var state = currentHistoryState();
    state.bytes = JSON.stringify(state).length * 2;
    history.push(state);
    historyBytes += state.bytes;
    if (history.length > maxHistory) { historyBytes -= history[0].bytes; history.shift(); }
    while (history.length > 1 && historyBytes > maxHistoryBytes) {
      historyBytes -= history[0].bytes;
      history.shift();
      historyIdx--;
    }
    historyIdx = history.length - 1;
    updateHistoryButtons();
    syncCode();
  }

  function restore() {
    if (historyIdx < 0 || historyIdx >= history.length) return;
    var state = history[historyIdx];
    artboard.innerHTML = state.markup;
    var restoredViewBox = String(state.viewBox || '0 0 800 600').split(/[\s,]+/).map(Number);
    DOC = state.document ? { x: state.document.x, y: state.document.y, w: state.document.w, h: state.document.h } : { x: restoredViewBox[0] || 0, y: restoredViewBox[1] || 0, w: restoredViewBox[2] || 800, h: restoredViewBox[3] || 600 };
    VB = state.viewport ? { x: state.viewport.x, y: state.viewport.y, w: state.viewport.w, h: state.viewport.h } : { x: DOC.x, y: DOC.y, w: DOC.w, h: DOC.h };
    initGrid();
    clearPathEditing();
    selected = [];
    applyViewBox();
    syncCanvasControls();
    updateProps();
    updateLayers();
    syncCode();
    updateHistoryButtons();
  }

  function undo() { if (historyIdx > 0) { historyIdx--; restore(); } }
  function redo() { if (historyIdx < history.length - 1) { historyIdx++; restore(); } }
  function updateHistoryButtons() {
    document.getElementById('undoBtn').disabled = historyIdx <= 0;
    document.getElementById('redoBtn').disabled = historyIdx >= history.length - 1;
  }

  // ---- Selection ----
  function primary() { return selected.length > 0 ? selected[selected.length - 1] : null; }

  function isLocked(node) { return !!node && node.getAttribute('data-locked') === 'true'; }
  function isHidden(node) { return !!node && node.getAttribute('data-hidden') === 'true'; }
  function userElements() {
    return Array.from(artboard.children).filter(function (node) { return node.tagName !== 'defs' && node.id !== 'gridRect'; });
  }

  function selectSingle(node) {
    if (!pathEditing || pathEditing.node !== node) clearPathEditing();
    selected = node && !isLocked(node) && !isHidden(node) ? [node] : [];
    updateSelection(); updateProps(); updateLayers(); syncToolbar(); updateActionButtons();
  }

  function toggleSelect(node) {
    if (isLocked(node) || isHidden(node)) return;
    var idx = selected.indexOf(node);
    if (idx >= 0) selected.splice(idx, 1);
    else selected.push(node);
    if (selected.length === 0) { node = null; }
    if (selected.length !== 1 || !pathEditing || pathEditing.node !== selected[0]) clearPathEditing();
    updateSelection(); updateProps(); updateLayers(); syncToolbar(); updateActionButtons();
  }

  function deselect() { clearPathEditing(); selected = []; updateSelection(); updateProps(); updateLayers(); syncToolbar(); updateActionButtons(); }

  function updateSelection() {
    if (selected.length === 0) {
      selBox.hidden = true;
      handles.forEach(function (h) { h.hidden = true; });
      rotateHandle.hidden = true;
      renderPathNodes();
      return;
    }
    var stageRect = stage.getBoundingClientRect();
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    selected.forEach(function (node) {
      var rect = node.getBoundingClientRect();
      minX = Math.min(minX, rect.left - stageRect.left);
      minY = Math.min(minY, rect.top - stageRect.top);
      maxX = Math.max(maxX, rect.right - stageRect.left);
      maxY = Math.max(maxY, rect.bottom - stageRect.top);
    });
    if (minX === Infinity) { selBox.hidden = true; return; }
    selBox.hidden = false;
    selBox.style.left = minX + 'px';
    selBox.style.top = minY + 'px';
    selBox.style.width = (maxX - minX) + 'px';
    selBox.style.height = (maxY - minY) + 'px';

    var x = minX, y = minY, w = maxX - minX, h = maxY - minY;
    var pos = {
      nw: [x, y], n: [x + w / 2, y], ne: [x + w, y],
      e: [x + w, y + h / 2], se: [x + w, y + h],
      s: [x + w / 2, y + h], sw: [x, y + h], w: [x, y + h / 2]
    };
    handles.forEach(function (hd) {
      var p = pos[hd.dataset.h];
      hd.hidden = false;
      hd.style.left = p[0] + 'px';
      hd.style.top = p[1] + 'px';
    });
    rotateHandle.hidden = selected.length !== 1;
    if (!rotateHandle.hidden) {
      rotateHandle.style.left = (x + w / 2) + 'px';
      rotateHandle.style.top = (y - 28) + 'px';
    }
    var editingThisPath = !!pathEditing && selected.length === 1 && pathEditing.node === primary();
    if (editingThisPath) {
      handles.forEach(function (handle) { handle.hidden = true; });
      rotateHandle.hidden = true;
    }
    renderPathNodes();
  }

  // ---- Path node editing ----
  function clearPathEditing() {
    pathEditing = null;
    pathNodeDragging = null;
    if (pathNodeLayer) { pathNodeLayer.hidden = true; pathNodeLayer.innerHTML = ''; }
  }

  function startPathEditing(node) {
    try {
      var segments = parsePathData(node.getAttribute('d'));
      var nodeCount = segments.filter(pathSegmentEndpoint).length;
      if (nodeCount > 500) {
        showToast(t('ed_path_too_many_nodes', 'This path has too many nodes to edit comfortably.'));
        return false;
      }
      pathEditing = { node: node, segments: segments, selectedIndex: null };
      renderPathNodes();
      updateSelection();
      return true;
    } catch (_) {
      showToast(t('ed_path_parse_fail', 'This path uses data that cannot be edited here.'));
      return false;
    }
  }

  function pathPointToOverlay(node, x, y) {
    var ctm = node.getScreenCTM();
    if (!ctm) return null;
    var point = new DOMPoint(x, y).matrixTransform(ctm);
    var rect = stage.getBoundingClientRect();
    return { x: point.x - rect.left, y: point.y - rect.top };
  }

  function pointerInPath(e, node) {
    var ctm = node.getScreenCTM();
    if (!ctm) return null;
    var point = new DOMPoint(e.clientX, e.clientY).matrixTransform(ctm.inverse());
    return { x: point.x, y: point.y };
  }

  function addPathGuide(from, to) {
    if (!from || !to) return;
    var line = document.createElement('span');
    var dx = to.x - from.x, dy = to.y - from.y;
    line.className = 'editor__path-guide';
    line.style.left = from.x + 'px';
    line.style.top = from.y + 'px';
    line.style.width = Math.hypot(dx, dy) + 'px';
    line.style.transform = 'rotate(' + Math.atan2(dy, dx) + 'rad)';
    pathNodeLayer.appendChild(line);
  }

  function addPathHandle(segmentIndex, pointName, xIndex, yIndex, control) {
    var segment = pathEditing.segments[segmentIndex];
    var point = pathPointToOverlay(pathEditing.node, segment.values[xIndex], segment.values[yIndex]);
    if (!point) return null;
    var handle = document.createElement('button');
    handle.type = 'button';
    handle.className = 'editor__path-node editor__path-node--' + (control ? 'control' : 'anchor');
    if (!control && pathEditing.selectedIndex === segmentIndex) handle.classList.add('is-active');
    handle.dataset.segment = segmentIndex;
    handle.dataset.point = pointName;
    handle.dataset.xIndex = xIndex;
    handle.dataset.yIndex = yIndex;
    handle.style.left = point.x + 'px';
    handle.style.top = point.y + 'px';
    handle.title = control ? t('ed_path_control_node', 'Curve control') : t('ed_path_anchor_node', 'Path node');
    handle.setAttribute('aria-label', handle.title + ' ' + (segmentIndex + 1));
    handle.addEventListener('focus', function () {
      if (!pathEditing) return;
      pathEditing.selectedIndex = segmentIndex;
      pathNodeLayer.querySelectorAll('.editor__path-node--anchor').forEach(function (anchor) { anchor.classList.remove('is-active'); });
      var anchor = pathNodeLayer.querySelector('.editor__path-node--anchor[data-segment="' + segmentIndex + '"]');
      if (anchor) anchor.classList.add('is-active');
      syncPathNodeButtons();
    });
    pathNodeLayer.appendChild(handle);
    return point;
  }

  function renderPathNodes() {
    if (!pathNodeLayer) return;
    pathNodeLayer.innerHTML = '';
    if (!pathEditing || !pathEditing.node.isConnected || selected.length !== 1 || primary() !== pathEditing.node) {
      pathNodeLayer.hidden = true;
      return;
    }
    pathNodeLayer.hidden = false;
    pathEditing.segments.forEach(function (segment, segmentIndex) {
      var endpoint = pathSegmentEndpoint(segment);
      if (!endpoint) return;
      var endPoint = pathPointToOverlay(pathEditing.node, endpoint.x, endpoint.y);
      var start = pathSegmentStart(pathEditing.segments, segmentIndex);
      var startPoint = pathPointToOverlay(pathEditing.node, start.x, start.y);
      if (segment.cmd === 'C') {
        var c1 = pathPointToOverlay(pathEditing.node, segment.values[0], segment.values[1]);
        var c2 = pathPointToOverlay(pathEditing.node, segment.values[2], segment.values[3]);
        addPathGuide(startPoint, c1); addPathGuide(endPoint, c2);
        addPathHandle(segmentIndex, 'c1', 0, 1, true);
        addPathHandle(segmentIndex, 'c2', 2, 3, true);
      } else if (segment.cmd === 'S') {
        var smoothControl = pathPointToOverlay(pathEditing.node, segment.values[0], segment.values[1]);
        addPathGuide(endPoint, smoothControl);
        addPathHandle(segmentIndex, 'c2', 0, 1, true);
      } else if (segment.cmd === 'Q') {
        var quadraticControl = pathPointToOverlay(pathEditing.node, segment.values[0], segment.values[1]);
        addPathGuide(startPoint, quadraticControl); addPathGuide(endPoint, quadraticControl);
        addPathHandle(segmentIndex, 'c1', 0, 1, true);
      }
      addPathHandle(segmentIndex, 'endpoint', endpoint.xIndex, endpoint.yIndex, false);
    });
    syncPathNodeButtons();
  }

  function syncPathNodeButtons() {
    var button = document.getElementById('propDeleteNode');
    if (!button) return;
    var segment = pathEditing && pathEditing.selectedIndex !== null ? pathEditing.segments[pathEditing.selectedIndex] : null;
    var endpointCount = pathEditing ? pathEditing.segments.filter(pathSegmentEndpoint).length : 0;
    button.disabled = !segment || segment.cmd === 'M' || endpointCount <= 2;
  }

  function detachParametricPath(node) {
    ['data-points', 'data-cx', 'data-cy', 'data-r'].forEach(function (name) { node.removeAttribute(name); });
  }

  function startPathNodeDrag(e, handle) {
    if (!pathEditing) return;
    var segmentIndex = Number(handle.dataset.segment);
    pathEditing.selectedIndex = segmentIndex;
    pathNodeDragging = {
      pointerId: e.pointerId,
      segmentIndex: segmentIndex,
      point: handle.dataset.point,
      xIndex: Number(handle.dataset.xIndex),
      yIndex: Number(handle.dataset.yIndex),
      moved: false
    };
    renderPathNodes();
    try { stage.setPointerCapture(e.pointerId); } catch (_) {}
    e.preventDefault();
    e.stopPropagation();
  }

  function shiftPathControl(segment, indexes, dx, dy) {
    if (!segment || !indexes) return;
    segment.values[indexes[0]] += dx;
    segment.values[indexes[1]] += dy;
  }

  function updatePathNodeDrag(e) {
    if (!pathNodeDragging || !pathEditing) return;
    var point = pointerInPath(e, pathEditing.node);
    if (!point) return;
    var drag = pathNodeDragging;
    var segment = pathEditing.segments[drag.segmentIndex];
    var oldX = segment.values[drag.xIndex], oldY = segment.values[drag.yIndex];
    var nextX = snapToGrid ? snapVal(point.x) : point.x;
    var nextY = snapToGrid ? snapVal(point.y) : point.y;
    var dx = nextX - oldX, dy = nextY - oldY;
    if (Math.abs(dx) < 0.0001 && Math.abs(dy) < 0.0001) return;
    segment.values[drag.xIndex] = nextX;
    segment.values[drag.yIndex] = nextY;
    if (drag.point === 'endpoint') {
      if (segment.cmd === 'C') shiftPathControl(segment, [2, 3], dx, dy);
      else if (segment.cmd === 'S' || segment.cmd === 'Q') shiftPathControl(segment, [0, 1], dx, dy);
      var nextSegment = pathEditing.segments[drag.segmentIndex + 1];
      if (nextSegment && (nextSegment.cmd === 'C' || nextSegment.cmd === 'Q')) shiftPathControl(nextSegment, [0, 1], dx, dy);
    }
    drag.moved = true;
    detachParametricPath(pathEditing.node);
    pathEditing.node.setAttribute('d', serializePathData(pathEditing.segments));
    syncCode(); updateSelection(); syncGeometryFields();
  }

  function endPathNodeDrag(e) {
    if (!pathNodeDragging) return;
    var changed = pathNodeDragging.moved;
    pathNodeDragging = null;
    try { stage.releasePointerCapture(e.pointerId); } catch (_) {}
    if (changed) {
      snapshot();
      updateProps();
      updateLayers();
    } else {
      renderPathNodes();
      syncPathNodeButtons();
    }
  }

  function deleteSelectedPathNode() {
    if (!pathEditing || pathEditing.selectedIndex === null) return false;
    var index = pathEditing.selectedIndex;
    var segment = pathEditing.segments[index];
    var endpointCount = pathEditing.segments.filter(pathSegmentEndpoint).length;
    if (!segment || segment.cmd === 'M' || endpointCount <= 2) return false;
    pathEditing.segments.splice(index, 1);
    pathEditing.selectedIndex = null;
    detachParametricPath(pathEditing.node);
    pathEditing.node.setAttribute('d', serializePathData(pathEditing.segments));
    syncCode(); updateSelection(); syncGeometryFields(); updateProps(); updateLayers(); snapshot();
    showToast(t('ed_path_node_deleted', 'Path node deleted'));
    return true;
  }


  // ---- Toolbar sync ----
  function syncToolbar() {
    var p = primary();
    if (!p) return;
    var fill = p.getAttribute('fill');
    var stroke = p.getAttribute('stroke');
    var sw = p.getAttribute('stroke-width');
    if (fill && fill !== 'none' && fill.indexOf('url') < 0) document.getElementById('fillColor').value = normalizeHex(fill);
    if (stroke && stroke !== 'none') document.getElementById('strokeColor').value = normalizeHex(stroke);
    if (sw) { document.getElementById('strokeWidth').value = sw; document.getElementById('strokeWidthValue').textContent = sw; }
  }

  function updateActionButtons() {
    var has = selected.length > 0;
    var multi = selected.length > 1;
    ['duplicateBtn', 'frontBtn', 'backBtn', 'deleteBtn', 'flipHBtn', 'flipVBtn', 'groupBtn'].forEach(function (id) {
      document.getElementById(id).disabled = !has;
    });
    document.getElementById('ungroupBtn').disabled = !has;
    document.getElementById('alignGroup').hidden = !multi;
    document.getElementById('groupBtn').disabled = !(multi && selected.every(function (n) { return n.parentNode === artboard; }));
    document.getElementById('ungroupBtn').disabled = !selected.some(function (n) { return n.tagName === 'g' || getElementType(n) === 'g'; });
  }

  // ---- Properties panel ----
  function getElementType(node) {
    var tag = node.tagName.toLowerCase();
    return tag === 'path' && node.hasAttribute('data-points') ? 'star' : tag;
  }

  function updateProps() {
    props.innerHTML = '';
    var p = primary();
    if (!p) { propType.textContent = t('ed_no_select', 'Nothing selected'); return; }
    var type = getElementType(p);
    propType.textContent = type.charAt(0).toUpperCase() + type.slice(1) + (selected.length > 1 ? ' (' + tpl('ed_selected_count', '{count} selected', { count: selected.length }) + ')' : '');

    var fill = p.getAttribute('fill') || 'none';
    var stroke = p.getAttribute('stroke') || 'none';
    var sw = p.getAttribute('stroke-width') || '0';
    var opacity = parseFloat(p.getAttribute('opacity') || '1');
    var rotation = rotationOf(p);
    var html = '';

    if (selected.length === 1) {
      var geometry = getParentBounds(p);
      html += '<div class="prop-section">';
      html += '<div class="prop-section__head"><span>' + t('ed_geometry', 'Geometry') + '</span><label class="prop-lock"><input type="checkbox" id="propLockRatio"' + (geometryRatioLocked ? ' checked' : '') + '> ' + t('ed_lock_ratio', 'Lock ratio') + '</label></div>';
      html += '<div class="prop-grid">';
      html += '<label><span>X</span><input class="prop-number" type="number" step="0.1" id="propX" value="' + formatNumber(geometry.x) + '"></label>';
      html += '<label><span>Y</span><input class="prop-number" type="number" step="0.1" id="propY" value="' + formatNumber(geometry.y) + '"></label>';
      html += '<label><span>' + t('ed_width_short', 'W') + '</span><input class="prop-number" type="number" min="0.001" step="0.1" id="propWidth" value="' + formatNumber(geometry.width) + '"' + (geometry.width <= 0 ? ' disabled' : '') + '></label>';
      html += '<label><span>' + t('ed_height_short', 'H') + '</span><input class="prop-number" type="number" min="0.001" step="0.1" id="propHeight" value="' + formatNumber(geometry.height) + '"' + (geometry.height <= 0 ? ' disabled' : '') + '></label>';
      html += '</div></div>';
    }

    // Fill
    html += '<div class="prop-row prop-row--swatches"><label>Fill</label>';
    html += '<input type="color" id="propFill" value="' + (fill !== 'none' && fill.indexOf('url') < 0 ? normalizeHex(fill) : '#000000') + '">';
    html += '<button class="color-swatch color-swatch--none" data-fill="none" title="No fill" aria-label="No fill"></button>';
    SWATCHES.forEach(function (c) { html += '<button class="color-swatch" data-fill="' + c + '" title="' + c + '" aria-label="Fill ' + c + '"></button>'; });
    html += '<button class="color-swatch color-swatch--linear" data-gradient="linear" title="Linear gradient" aria-label="Linear gradient"></button>';
    html += '<button class="color-swatch color-swatch--radial" data-gradient="radial" title="Radial gradient" aria-label="Radial gradient"></button>';
    html += '</div>';

    // Gradient editor
    if (fill.indexOf('url') >= 0) {
      var gid = fill.match(/url\(#([^)]+)\)/);
      if (gid) {
        var grad = artboard.querySelector('#' + gid[1]);
        if (grad) {
          var stops = grad.querySelectorAll('stop');
          var s1 = stops[0] ? stops[0].getAttribute('stop-color') : '#7dd3fc';
          var s2 = stops[1] ? stops[1].getAttribute('stop-color') : '#203848';
          html += '<div class="prop-row"><label>Grad 1</label><input type="color" id="propGrad1" value="' + normalizeHex(s1) + '"></div>';
          html += '<div class="prop-row"><label>Grad 2</label><input type="color" id="propGrad2" value="' + normalizeHex(s2) + '"></div>';
          if (grad.tagName === 'linearGradient') {
            var gx1 = parseFloat(grad.getAttribute('x1')) || 0;
            var gy1 = parseFloat(grad.getAttribute('y1')) || 0;
            var gx2 = parseFloat(grad.getAttribute('x2')) || 100;
            var gy2 = parseFloat(grad.getAttribute('y2')) || 0;
            var gradAngle = Math.round(Math.atan2(gy2 - gy1, gx2 - gx1) * 180 / Math.PI);
            if (gradAngle < 0) gradAngle += 360;
            html += '<div class="prop-row"><label>Angle</label><input class="range" type="range" id="propGradAngle" min="0" max="360" value="' + gradAngle + '"><span class="prop-value" id="propGradAngleVal">' + gradAngle + '</span></div>';
          }
        }
      }
    }

    // Stroke
    html += '<div class="prop-row prop-row--swatches"><label>Stroke</label>';
    html += '<input type="color" id="propStroke" value="' + (stroke !== 'none' ? normalizeHex(stroke) : '#000000') + '">';
    html += '<button class="color-swatch color-swatch--none" data-stroke="none" title="No stroke" aria-label="No stroke"></button>';
    SWATCHES.forEach(function (c) { html += '<button class="color-swatch" data-stroke="' + c + '" title="' + c + '" aria-label="Stroke ' + c + '"></button>'; });
    html += '</div>';

    html += '<div class="prop-row"><label>Width</label><input class="range" type="range" id="propStrokeWidth" min="0" max="40" value="' + sw + '"><span class="prop-value" id="propStrokeWidthVal">' + sw + '</span></div>';
    var lineCap = p.getAttribute('stroke-linecap') || 'butt';
    var lineJoin = p.getAttribute('stroke-linejoin') || 'miter';
    var dashArray = p.getAttribute('stroke-dasharray') || '';
    html += '<div class="prop-row"><label>' + t('ed_line_cap', 'Line cap') + '</label><select id="propLineCap">' + optionMarkup('butt', t('ed_cap_butt', 'Butt'), lineCap) + optionMarkup('round', t('ed_cap_round', 'Round'), lineCap) + optionMarkup('square', t('ed_cap_square', 'Square'), lineCap) + '</select></div>';
    html += '<div class="prop-row"><label>' + t('ed_line_join', 'Line join') + '</label><select id="propLineJoin">' + optionMarkup('miter', t('ed_join_miter', 'Miter'), lineJoin) + optionMarkup('round', t('ed_join_round', 'Round'), lineJoin) + optionMarkup('bevel', t('ed_join_bevel', 'Bevel'), lineJoin) + '</select></div>';
    html += '<div class="prop-row"><label>' + t('ed_dash', 'Dash') + '</label><input type="text" id="propDash" value="' + escapeAttr(dashArray) + '" placeholder="' + t('ed_solid', 'Solid') + '"></div>';
    html += '<div class="prop-row"><label>Opacity</label><input class="range" type="range" id="propOpacity" min="0" max="100" value="' + Math.round(opacity * 100) + '"><span class="prop-value" id="propOpacityVal">' + Math.round(opacity * 100) + '</span></div>';
    html += '<div class="prop-row"><label>Rotation</label><input class="range" type="range" id="propRotation" min="-180" max="180" value="' + Math.round(rotation) + '"><span class="prop-value" id="propRotationVal">' + Math.round(rotation) + '</span></div>';

    if (type === 'rect') {
      var rx = p.getAttribute('rx') || '0';
      html += '<div class="prop-row"><label>Corner</label><input class="range" type="range" id="propRx" min="0" max="100" value="' + rx + '"><span class="prop-value" id="propRxVal">' + rx + '</span></div>';
    }
    if (type === 'star') {
      var pts = p.getAttribute('data-points') || '5';
      html += '<div class="prop-row"><label>Points</label><input class="range" type="range" id="propStarPts" min="3" max="12" value="' + pts + '"><span class="prop-value" id="propStarPtsVal">' + pts + '</span></div>';
    }
    if ((type === 'path' || type === 'star') && selected.length === 1) {
      var editingNodes = !!pathEditing && pathEditing.node === p;
      html += '<div class="prop-section prop-section--path">';
      html += '<div class="prop-section__head"><span>' + t('ed_path_nodes', 'Path nodes') + '</span></div>';
      html += '<div class="prop-actions"><button type="button" class="btn btn--sm" id="propEditNodes">' + (editingNodes ? t('ed_finish_path_nodes', 'Finish editing') : t('ed_edit_path_nodes', 'Edit nodes')) + '</button>';
      if (editingNodes) html += '<button type="button" class="btn btn--sm" id="propDeleteNode" disabled>' + t('ed_delete_path_node', 'Delete node') + '</button>';
      html += '</div><p class="prop-hint">' + t('ed_path_node_hint', 'Drag anchors and curve controls. Arc endpoints can be moved.') + '</p>';
      html += '<p class="prop-hint prop-hint--mobile">' + t('ed_path_mobile_hint', 'When path nodes are crowded, zoom in before editing.') + '</p></div>';
    }
    if (type === 'text') {
      var ts = p.textContent || '';
      var fs = p.getAttribute('font-size') || '16';
      var fontFamily = p.getAttribute('font-family') || 'Inter, sans-serif';
      var fontWeight = p.getAttribute('font-weight') || '400';
      var fontStyle = p.getAttribute('font-style') || 'normal';
      var textAnchor = p.getAttribute('text-anchor') || 'start';
      var letterSpacingValue = parseFloat(p.getAttribute('letter-spacing') || '0');
      var letterSpacing = isFinite(letterSpacingValue) ? formatNumber(letterSpacingValue) : '0';
      html += '<div class="prop-row"><label>Text</label><input type="text" id="propText" value="' + escapeAttr(ts) + '"></div>';
      html += '<div class="prop-row"><label>' + t('ed_font_family', 'Font') + '</label><input type="text" id="propFontFamily" list="fontFamilyOptions" value="' + escapeAttr(fontFamily) + '"><datalist id="fontFamilyOptions"><option value="Inter, sans-serif"><option value="Arial, sans-serif"><option value="Georgia, serif"><option value="Times New Roman, serif"><option value="Courier New, monospace"><option value="system-ui, sans-serif"></datalist></div>';
      html += '<div class="prop-row"><label>' + t('ed_font_size', 'Size') + '</label><input class="range" type="range" id="propFontSize" min="8" max="300" value="' + fs + '"><span class="prop-value" id="propFontSizeVal">' + fs + '</span></div>';
      html += '<div class="prop-row"><label>' + t('ed_font_weight', 'Weight') + '</label><select id="propFontWeight">' + optionMarkup('300', '300', fontWeight) + optionMarkup('400', '400', fontWeight) + optionMarkup('500', '500', fontWeight) + optionMarkup('600', '600', fontWeight) + optionMarkup('700', '700', fontWeight) + optionMarkup('800', '800', fontWeight) + optionMarkup('900', '900', fontWeight) + optionMarkup('bold', t('ed_weight_bold', 'Bold'), fontWeight) + '</select></div>';
      html += '<div class="prop-row"><label>' + t('ed_font_style', 'Style') + '</label><select id="propFontStyle">' + optionMarkup('normal', t('ed_style_normal', 'Normal'), fontStyle) + optionMarkup('italic', t('ed_style_italic', 'Italic'), fontStyle) + '</select></div>';
      html += '<div class="prop-row"><label>' + t('ed_text_align', 'Align') + '</label><select id="propTextAnchor">' + optionMarkup('start', t('ed_align_start', 'Start'), textAnchor) + optionMarkup('middle', t('ed_align_middle', 'Center'), textAnchor) + optionMarkup('end', t('ed_align_end', 'End'), textAnchor) + '</select></div>';
      html += '<div class="prop-row"><label>' + t('ed_letter_spacing', 'Spacing') + '</label><input class="prop-number" type="number" step="0.1" id="propLetterSpacing" value="' + escapeAttr(letterSpacing) + '"></div>';
    }

    props.innerHTML = html;
    // CSSOM, not style="": inline style attributes are blocked by the site CSP.
    props.querySelectorAll('.color-swatch[data-fill], .color-swatch[data-stroke]').forEach(function (s) {
      var c = s.dataset.fill || s.dataset.stroke;
      if (c !== 'none') s.style.background = c;
    });
    bindPropEvents();
  }

  function syncGeometryFields() {
    var node = selected.length === 1 ? primary() : null;
    if (!node) return;
    var bounds = getParentBounds(node);
    [['propX', bounds.x], ['propY', bounds.y], ['propWidth', bounds.width], ['propHeight', bounds.height]].forEach(function (entry) {
      var input = document.getElementById(entry[0]);
      if (input && document.activeElement !== input) input.value = formatNumber(entry[1]);
    });
  }

  function bindPropEvents() {
    var p = primary();
    if (!p) return;

    function applyToSelected(fn) {
      selected.forEach(fn);
      syncToolbar(); updateLayers(); syncCode(); updateSelection();
    }
    function snapAll(fn) {
      selected.forEach(fn);
      syncToolbar(); updateLayers(); syncCode(); updateSelection();
      snapshot();
    }

    function bindFieldCommit(input, callback) {
      if (!input) return;
      var originalValue = input.value;
      var committing = false;
      function commit() {
        if (committing || input.value === originalValue) return;
        originalValue = input.value;
        committing = true;
        callback();
        committing = false;
      }
      input.addEventListener('change', commit);
      input.addEventListener('blur', commit);
      input.addEventListener('keydown', function (event) { if (event.key === 'Enter') { event.preventDefault(); commit(); } });
    }

    var ratioLock = document.getElementById('propLockRatio');
    if (ratioLock) ratioLock.addEventListener('change', function () { geometryRatioLocked = ratioLock.checked; });

    function bindGeometryInput(id, field) {
      var input = document.getElementById(id);
      if (!input) return;
      var committed = false;
      var originalValue = input.value;
      function commitGeometry() {
        if (committed || input.value === originalValue) return;
        committed = true;
        var node = primary();
        var value = Number(input.value);
        if (!node || !isFinite(value) || ((field === 'width' || field === 'height') && value <= 0)) {
          showToast(t('ed_invalid_geometry', 'Enter a valid geometry value.'));
          updateProps();
          return;
        }
        var bounds = getParentBounds(node);
        var changed = true;
        if (field === 'x') moveElement(node, value, bounds.y);
        else if (field === 'y') moveElement(node, bounds.x, value);
        else {
          var next = { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height };
          if (field === 'width') {
            next.width = value;
            if (geometryRatioLocked && bounds.width > 0) next.height = value * bounds.height / bounds.width;
          } else {
            next.height = value;
            if (geometryRatioLocked && bounds.height > 0) next.width = value * bounds.width / bounds.height;
          }
          changed = setElementBounds(node, next);
        }
        if (!changed) {
          showToast(t('ed_geometry_zero_size', 'This element cannot be resized on an empty axis.'));
          updateProps();
          return;
        }
        updateSelection(); updateLayers(); syncToolbar(); snapshot(); updateProps();
      }
      input.addEventListener('change', commitGeometry);
      input.addEventListener('blur', commitGeometry);
      input.addEventListener('keydown', function (event) { if (event.key === 'Enter') { event.preventDefault(); commitGeometry(); } });
    }
    bindGeometryInput('propX', 'x');
    bindGeometryInput('propY', 'y');
    bindGeometryInput('propWidth', 'width');
    bindGeometryInput('propHeight', 'height');

    var propEditNodes = document.getElementById('propEditNodes');
    if (propEditNodes) propEditNodes.addEventListener('click', function () {
      if (pathEditing && pathEditing.node === p) {
        clearPathEditing();
        updateSelection();
        updateProps();
      } else if (startPathEditing(p)) {
        updateProps();
        updateSelection();
      }
    });
    var propDeleteNode = document.getElementById('propDeleteNode');
    if (propDeleteNode) propDeleteNode.addEventListener('click', deleteSelectedPathNode);
    syncPathNodeButtons();

    var propFill = document.getElementById('propFill');
    if (propFill) { propFill.addEventListener('input', function () { applyToSelected(function (n) { n.setAttribute('fill', propFill.value); }); }); propFill.addEventListener('change', function () { snapAll(function (n) { n.setAttribute('fill', propFill.value); }); }); }

    var propStroke = document.getElementById('propStroke');
    if (propStroke) { propStroke.addEventListener('input', function () { applyToSelected(function (n) { n.setAttribute('stroke', propStroke.value); }); }); propStroke.addEventListener('change', function () { snapAll(function (n) { n.setAttribute('stroke', propStroke.value); }); }); }

    var propSW = document.getElementById('propStrokeWidth');
    if (propSW) { propSW.addEventListener('input', function () { document.getElementById('propStrokeWidthVal').textContent = propSW.value; applyToSelected(function (n) { n.setAttribute('stroke-width', propSW.value); }); }); propSW.addEventListener('change', function () { snapAll(function () {}); }); }

    var propLineCap = document.getElementById('propLineCap');
    if (propLineCap) propLineCap.addEventListener('change', function () { snapAll(function (n) { n.setAttribute('stroke-linecap', propLineCap.value); }); });

    var propLineJoin = document.getElementById('propLineJoin');
    if (propLineJoin) propLineJoin.addEventListener('change', function () { snapAll(function (n) { n.setAttribute('stroke-linejoin', propLineJoin.value); }); });

    var propDash = document.getElementById('propDash');
    bindFieldCommit(propDash, function () {
      var value = propDash.value.trim().replace(/,/g, ' ').replace(/\s+/g, ' ');
      var values = value ? value.split(' ').map(Number) : [];
      if (value && (!values.length || values.some(function (part) { return !isFinite(part) || part < 0; }))) {
        showToast(t('ed_invalid_dash', 'Use non-negative numbers such as 8 4.'));
        updateProps();
        return;
      }
      snapAll(function (n) { if (value) n.setAttribute('stroke-dasharray', value); else n.removeAttribute('stroke-dasharray'); });
    });

    var propOp = document.getElementById('propOpacity');
    if (propOp) { propOp.addEventListener('input', function () { document.getElementById('propOpacityVal').textContent = propOp.value; applyToSelected(function (n) { n.setAttribute('opacity', (propOp.value / 100).toFixed(2)); }); }); propOp.addEventListener('change', function () { snapAll(function () {}); }); }

    var propRot = document.getElementById('propRotation');
    if (propRot) {
      var rotationStates = selected.map(function (node) {
        var matrix = matrixOf(node);
        return { node: node, matrix: matrix, bounds: getParentBounds(node, matrix), angle: rotationOf(node) };
      });
      propRot.addEventListener('input', function () {
        document.getElementById('propRotationVal').textContent = propRot.value;
        var targetAngle = parseFloat(propRot.value);
        rotationStates.forEach(function (state) {
          var cx = state.bounds.x + state.bounds.width / 2;
          var cy = state.bounds.y + state.bounds.height / 2;
          setNodeMatrix(state.node, rotateAtMatrix(targetAngle - state.angle, cx, cy).multiply(state.matrix));
        });
        syncToolbar(); updateLayers(); syncCode(); updateSelection(); syncGeometryFields();
      });
      propRot.addEventListener('change', function () { snapAll(function () {}); });
    }

    var propRx = document.getElementById('propRx');
    if (propRx) { propRx.addEventListener('input', function () { document.getElementById('propRxVal').textContent = propRx.value; applyToSelected(function (n) { n.setAttribute('rx', propRx.value); }); }); propRx.addEventListener('change', function () { snapAll(function () {}); }); }

    var propStarPts = document.getElementById('propStarPts');
    if (propStarPts && getElementType(p) === 'star') {
      propStarPts.addEventListener('input', function () {
        document.getElementById('propStarPtsVal').textContent = propStarPts.value;
        p.setAttribute('data-points', propStarPts.value);
        rebuildStar(p, parseInt(propStarPts.value, 10));
        syncCode(); updateSelection(); syncGeometryFields();
      });
      propStarPts.addEventListener('change', function () { snapshot(); });
    }

    var propText = document.getElementById('propText');
    if (propText) { propText.addEventListener('input', function () { p.textContent = propText.value; syncCode(); updateSelection(); syncGeometryFields(); }); propText.addEventListener('change', function () { snapshot(); }); }

    var propFontFamily = document.getElementById('propFontFamily');
    bindFieldCommit(propFontFamily, function () { var value = propFontFamily.value.trim(); if (value) { p.setAttribute('font-family', value); updateSelection(); syncGeometryFields(); snapshot(); } });

    var propFS = document.getElementById('propFontSize');
    if (propFS) { propFS.addEventListener('input', function () { document.getElementById('propFontSizeVal').textContent = propFS.value; p.setAttribute('font-size', propFS.value); syncCode(); updateSelection(); syncGeometryFields(); }); propFS.addEventListener('change', function () { snapshot(); }); }

    var propFontWeight = document.getElementById('propFontWeight');
    if (propFontWeight) propFontWeight.addEventListener('change', function () { p.setAttribute('font-weight', propFontWeight.value); updateSelection(); syncGeometryFields(); snapshot(); });

    var propFontStyle = document.getElementById('propFontStyle');
    if (propFontStyle) propFontStyle.addEventListener('change', function () { p.setAttribute('font-style', propFontStyle.value); updateSelection(); syncGeometryFields(); snapshot(); });

    var propTextAnchor = document.getElementById('propTextAnchor');
    if (propTextAnchor) propTextAnchor.addEventListener('change', function () { p.setAttribute('text-anchor', propTextAnchor.value); updateSelection(); syncGeometryFields(); snapshot(); });

    var propLetterSpacing = document.getElementById('propLetterSpacing');
    bindFieldCommit(propLetterSpacing, function () {
      var value = Number(propLetterSpacing.value);
      if (!isFinite(value)) { showToast(t('ed_invalid_spacing', 'Enter a valid letter spacing.')); updateProps(); return; }
      p.setAttribute('letter-spacing', formatNumber(value)); updateSelection(); syncGeometryFields(); snapshot();
    });

    // Gradient editors
    var pg1 = document.getElementById('propGrad1');
    var pg2 = document.getElementById('propGrad2');
    var pgA = document.getElementById('propGradAngle');
    if (pg1) { pg1.addEventListener('input', function () { updateGradient(p, pg1.value, null, null); }); pg1.addEventListener('change', function () { snapshot(); }); }
    if (pg2) { pg2.addEventListener('input', function () { updateGradient(p, null, pg2.value, null); }); pg2.addEventListener('change', function () { snapshot(); }); }
    if (pgA) { pgA.addEventListener('input', function () { document.getElementById('propGradAngleVal').textContent = pgA.value; updateGradient(p, null, null, parseInt(pgA.value, 10)); }); pgA.addEventListener('change', function () { snapshot(); }); }

    // Swatches
    props.querySelectorAll('[data-fill]').forEach(function (s) {
      s.addEventListener('click', function () {
        applyToSelected(function (n) { n.setAttribute('fill', s.dataset.fill); });
        if (s.dataset.fill !== 'none' && propFill) propFill.value = normalizeHex(s.dataset.fill);
        snapshot();
      });
    });
    props.querySelectorAll('[data-stroke]').forEach(function (s) {
      s.addEventListener('click', function () {
        applyToSelected(function (n) { n.setAttribute('stroke', s.dataset.stroke); });
        if (s.dataset.stroke !== 'none' && propStroke) propStroke.value = normalizeHex(s.dataset.stroke);
        snapshot();
      });
    });
    // Gradient buttons
    props.querySelectorAll('[data-gradient]').forEach(function (s) {
      s.addEventListener('click', function () {
        var gid = createGradient(s.dataset.gradient);
        p.setAttribute('fill', 'url(#' + gid + ')');
        updateProps();
        syncCode();
        snapshot();
      });
    });
  }

  // ---- Gradients ----
  function createGradient(type) {
    var gid = 'grad-' + (++uidCounter);
    var defs = artboard.querySelector('defs');
    if (!defs) { defs = el('defs'); artboard.insertBefore(defs, artboard.firstChild); }
    var grad;
    if (type === 'radial') {
      grad = el('radialGradient', { id: gid, cx: '50%', cy: '50%', r: '50%' });
    } else {
      grad = el('linearGradient', { id: gid, x1: '0%', y1: '0%', x2: '100%', y2: '100%' });
    }
    grad.appendChild(el('stop', { offset: '0%', 'stop-color': '#7dd3fc' }));
    grad.appendChild(el('stop', { offset: '100%', 'stop-color': '#203848' }));
    defs.appendChild(grad);
    return gid;
  }

  function updateGradient(node, c1, c2, angle) {
    var fill = node.getAttribute('fill') || '';
    var m = fill.match(/url\(#([^)]+)\)/);
    if (!m) return;
    var grad = artboard.querySelector('#' + m[1]);
    if (!grad) return;
    var stops = grad.querySelectorAll('stop');
    if (c1 && stops[0]) stops[0].setAttribute('stop-color', c1);
    if (c2 && stops[1]) stops[1].setAttribute('stop-color', c2);
    if (angle !== null && angle !== undefined && grad.tagName === 'linearGradient') {
      var r = angle * Math.PI / 180;
      grad.setAttribute('x1', Math.round((1 - Math.cos(r)) / 2 * 100) + '%');
      grad.setAttribute('y1', Math.round((1 - Math.sin(r)) / 2 * 100) + '%');
      grad.setAttribute('x2', Math.round((1 + Math.cos(r)) / 2 * 100) + '%');
      grad.setAttribute('y2', Math.round((1 + Math.sin(r)) / 2 * 100) + '%');
    }
    syncCode();
  }

  // ---- Layers panel ----
  function updateLayers() {
    var panel = document.querySelector('.editor__panel--layers');
    if (!panel) return;
    var list = panel.querySelector('.editor__layers');
    if (!list) return;
    var countEl = panel.querySelector('#layerCount');
    list.innerHTML = '';
    var nodes = userElements().reverse();
    if (countEl) countEl.textContent = nodes.length === 1 ? tpl('ed_element_count', '{count} element', { count: nodes.length }) : tpl('ed_elements_count', '{count} elements', { count: nodes.length });
    if (nodes.length === 0) { list.innerHTML = '<p class="editor__layers-empty">' + t('ed_no_elements', 'No elements yet') + '</p>'; return; }

    function layerButton(label, glyph, disabled, handler) {
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'layer-item__button';
      button.title = label;
      button.setAttribute('aria-label', label);
      button.textContent = glyph;
      button.disabled = !!disabled;
      button.addEventListener('click', function (event) {
        event.stopPropagation();
        if (!button.disabled) handler();
      });
      return button;
    }

    function finishLayerChange(message) {
      updateSelection();
      updateProps();
      updateLayers();
      updateActionButtons();
      snapshot();
      if (message) showToast(message);
    }

    function moveLayer(node, towardFront) {
      var ordered = userElements();
      var index = ordered.indexOf(node);
      if (towardFront && index < ordered.length - 1) artboard.insertBefore(ordered[index + 1], node);
      else if (!towardFront && index > 0) artboard.insertBefore(node, ordered[index - 1]);
      finishLayerChange();
    }

    nodes.forEach(function (node, i) {
      var type = getElementType(node);
      var fill = node.getAttribute('fill') || 'none';
      var hidden = isHidden(node), locked = isLocked(node);
      var defaultName = type + ' ' + (nodes.length - i);
      var name = node.getAttribute('data-name') || defaultName;
      var item = document.createElement('div');
      item.className = 'layer-item' + (selected.indexOf(node) >= 0 ? ' is-active' : '') + (hidden ? ' is-hidden' : '') + (locked ? ' is-locked' : '');
      var sw = fill !== 'none' && fill.indexOf('url') < 0 ? fill : fill.indexOf('url') >= 0 ? 'transparent' : 'transparent';
      item.appendChild(layerButton(hidden ? t('ed_layer_show', 'Show layer') : t('ed_layer_hide', 'Hide layer'), hidden ? '○' : '◉', false, function () {
        if (hidden) node.removeAttribute('data-hidden'); else node.setAttribute('data-hidden', 'true');
        if (!hidden) selected = selected.filter(function (selectedNode) { return selectedNode !== node; });
        finishLayerChange(hidden ? t('ed_layer_shown', 'Layer shown') : t('ed_layer_hidden', 'Layer hidden'));
      }));
      item.appendChild(layerButton(locked ? t('ed_layer_unlock', 'Unlock layer') : t('ed_layer_lock', 'Lock layer'), locked ? '◆' : '◇', false, function () {
        if (locked) node.removeAttribute('data-locked'); else node.setAttribute('data-locked', 'true');
        if (!locked) selected = selected.filter(function (selectedNode) { return selectedNode !== node; });
        finishLayerChange(locked ? t('ed_layer_unlocked', 'Layer unlocked') : t('ed_layer_locked', 'Layer locked'));
      }));
      var swatch = document.createElement('span');
      swatch.className = 'layer-item__swatch';
      swatch.style.background = sw;
      item.appendChild(swatch);
      var label = document.createElement('span');
      label.className = 'layer-item__label';
      label.textContent = name;
      label.title = name + ' · ' + type;
      item.appendChild(label);
      item.appendChild(layerButton(t('ed_layer_rename', 'Rename layer'), '✎', false, function () {
        var input = document.createElement('input');
        input.className = 'layer-item__name-input';
        input.value = node.getAttribute('data-name') || defaultName;
        label.replaceWith(input);
        input.focus(); input.select();
        var done = false;
        function finish(save) {
          if (done) return;
          done = true;
          if (save) {
            var nextName = input.value.trim().slice(0, 80);
            var storedName = nextName && nextName !== defaultName ? nextName : null;
            if (storedName === node.getAttribute('data-name')) { updateLayers(); return; }
            if (storedName) node.setAttribute('data-name', storedName);
            else node.removeAttribute('data-name');
            finishLayerChange(t('ed_layer_renamed', 'Layer renamed'));
          } else updateLayers();
        }
        input.addEventListener('keydown', function (event) {
          if (event.key === 'Enter') { event.preventDefault(); finish(true); }
          else if (event.key === 'Escape') { event.preventDefault(); finish(false); }
        });
        input.addEventListener('blur', function () { finish(true); });
      }));
      item.appendChild(layerButton(t('ed_layer_up', 'Move layer forward'), '↑', i === 0, function () { moveLayer(node, true); }));
      item.appendChild(layerButton(t('ed_layer_down', 'Move layer backward'), '↓', i === nodes.length - 1, function () { moveLayer(node, false); }));
      item.addEventListener('click', function (e) {
        if (locked || hidden) {
          showToast(locked ? t('ed_layer_locked_hint', 'Unlock this layer to edit it.') : t('ed_layer_hidden_hint', 'Show this layer to edit it.'));
          return;
        }
        if (e.shiftKey) toggleSelect(node); else selectSingle(node);
      });
      list.appendChild(item);
    });
  }

  function updateSourceButtons() {
    var applyButton = document.getElementById('applyCodeBtn');
    var revertButton = document.getElementById('revertCodeBtn');
    if (applyButton) applyButton.disabled = !codeDirty;
    if (revertButton) revertButton.disabled = !codeDirty;
  }

  function syncCode(force) {
    if (codeDirty && !force) return;
    var clone = cleanArtboardClone();
    clone.removeAttribute('id');
    clone.setAttribute('xmlns', SVG_NS);
    clone.setAttribute('viewBox', documentViewBox());
    clone.setAttribute('width', DOC.w);
    clone.setAttribute('height', DOC.h);
    codeView.value = new XMLSerializer().serializeToString(clone).replace(/></g, '>\n<');
    codeDirty = false;
    codeView.removeAttribute('aria-invalid');
    updateSourceButtons();
  }

  // ---- Tools ----
  function setTool(t) {
    tool = t;
    stage.dataset.tool = t;
    document.querySelectorAll('.tool').forEach(function (b) { b.classList.toggle('is-active', b.dataset.tool === t); });
    if (t !== 'select') deselect();
    polygonPoints = [];
    if (polygonPreview) { polygonPreview.remove(); polygonPreview = null; }
  }

  document.querySelectorAll('.tool').forEach(function (b) { b.addEventListener('click', function () { setTool(b.dataset.tool); }); });

  // ---- Drawing ----
  stage.addEventListener('pointerdown', function (e) {
    var pathHandle = e.target.closest('.editor__path-node');
    if (pathHandle) { startPathNodeDrag(e, pathHandle); return; }
    if (e.target.closest('.editor__handle') || e.target === rotateHandle) {
      if (e.target === rotateHandle) startRotate(e); else startResize(e);
      return;
    }
    if (spaceDown || e.button === 1) { startPan(e); return; }
    if (tool === 'select') {
      var node = e.target.closest('[data-id]');
      if (node && node !== artboard && node.id !== 'gridRect') {
        if (isLocked(node) || isHidden(node)) return;
        if (e.shiftKey) toggleSelect(node); else { if (selected.indexOf(node) < 0) selectSingle(node); }
        startDrag(e);
      } else { deselect(); }
      return;
    }
    if (tool === 'polygon') { handlePolygonClick(e); return; }
    startDraw(e);
  });

  function startDraw(e) {
    var p = getMouse(e);
    p.x = snapVal(p.x); p.y = snapVal(p.y);
    drawing = { x: p.x, y: p.y };
    penPoints = [];
    var node, id = uid();
    var fill = document.getElementById('fillColor').value;
    var stroke = document.getElementById('strokeColor').value;
    var sw = parseInt(document.getElementById('strokeWidth').value, 10);

    if (tool === 'rect') node = el('rect', { x: p.x, y: p.y, width: 1, height: 1, rx: 0, fill: fill, stroke: stroke, 'stroke-width': sw, 'data-id': id });
    else if (tool === 'ellipse') node = el('ellipse', { cx: p.x, cy: p.y, rx: 1, ry: 1, fill: fill, stroke: stroke, 'stroke-width': sw, 'data-id': id });
    else if (tool === 'line') node = el('line', { x1: p.x, y1: p.y, x2: p.x, y2: p.y, stroke: stroke, 'stroke-width': Math.max(1, sw), 'data-id': id, fill: 'none' });
    else if (tool === 'text') { node = el('text', { x: p.x, y: p.y, 'font-size': 24, fill: fill, stroke: 'none', 'data-id': id, 'font-family': 'Inter, sans-serif' }); node.textContent = t('ed_text_default', 'Text'); }
    else if (tool === 'pen') { penPoints.push(p); node = el('path', { d: 'M' + p.x + ' ' + p.y, fill: 'none', stroke: stroke, 'stroke-width': Math.max(1, sw), 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'data-id': id }); }
    else if (tool === 'star') { node = el('path', { d: '', fill: fill, stroke: stroke, 'stroke-width': sw, 'data-id': id, 'data-points': '5', 'data-cx': p.x, 'data-cy': p.y, 'data-r': 1 }); drawing.isStar = true; }

    if (node) { artboard.appendChild(node); drawing.node = node; drawing.id = id; }
  }

  stage.addEventListener('pointermove', function (e) {
    if (pathNodeDragging) { updatePathNodeDrag(e); return; }
    if (panning) { updatePan(e); return; }
    if (drawing) { updateDraw(e); return; }
    if (dragging) { updateDrag(e); return; }
    if (resizing) { updateResize(e); return; }
    if (rotating) { updateRotate(e); return; }
    if (tool === 'polygon' && polygonPoints.length > 0) { updatePolygonPreview(e); }
  });

  function updateDraw(e) {
    var p = getMouse(e); p.x = snapVal(p.x); p.y = snapVal(p.y);
    var n = drawing.node; if (!n) return;
    var sx = drawing.x, sy = drawing.y;
    var dx = p.x - sx, dy = p.y - sy;
    if (tool === 'rect') {
      if (e.shiftKey) {
        var size = Math.max(Math.abs(dx), Math.abs(dy));
        dx = dx >= 0 ? size : -size;
        dy = dy >= 0 ? size : -size;
      }
      if (e.altKey) {
        var w = Math.max(1, Math.abs(dx)), h = Math.max(1, Math.abs(dy));
        n.setAttribute('x', sx - w); n.setAttribute('y', sy - h);
        n.setAttribute('width', w * 2); n.setAttribute('height', h * 2);
      } else {
        n.setAttribute('x', Math.min(sx, sx + dx)); n.setAttribute('y', Math.min(sy, sy + dy));
        n.setAttribute('width', Math.max(1, Math.abs(dx))); n.setAttribute('height', Math.max(1, Math.abs(dy)));
      }
    } else if (tool === 'ellipse') {
      if (e.shiftKey) {
        var r = Math.max(Math.abs(dx), Math.abs(dy));
        dx = dx >= 0 ? r : -r;
        dy = dy >= 0 ? r : -r;
      }
      if (e.altKey) {
        n.setAttribute('cx', sx); n.setAttribute('cy', sy);
        n.setAttribute('rx', Math.max(1, Math.abs(dx))); n.setAttribute('ry', Math.max(1, Math.abs(dy)));
      } else {
        n.setAttribute('cx', (sx + sx + dx) / 2); n.setAttribute('cy', (sy + sy + dy) / 2);
        n.setAttribute('rx', Math.max(1, Math.abs(dx) / 2)); n.setAttribute('ry', Math.max(1, Math.abs(dy) / 2));
      }
    } else if (tool === 'line') {
      var x2 = p.x, y2 = p.y;
      if (e.shiftKey) {
        var len = Math.hypot(x2 - sx, y2 - sy);
        var angle = Math.atan2(y2 - sy, x2 - sx) * 180 / Math.PI;
        angle = Math.round(angle / 15) * 15;
        x2 = sx + len * Math.cos(angle * Math.PI / 180);
        y2 = sy + len * Math.sin(angle * Math.PI / 180);
      }
      n.setAttribute('x2', x2); n.setAttribute('y2', y2);
    } else if (tool === 'pen') { penPoints.push(p); var d = 'M' + penPoints[0].x + ' ' + penPoints[0].y; for (var i = 1; i < penPoints.length; i++) d += ' L' + penPoints[i].x + ' ' + penPoints[i].y; n.setAttribute('d', d); }
    else if (tool === 'star' && drawing.isStar) {
      var cx = parseFloat(n.getAttribute('data-cx')), cy = parseFloat(n.getAttribute('data-cy'));
      var r = Math.max(1, Math.hypot(p.x - cx, p.y - cy));
      n.setAttribute('data-r', r);
      rebuildStar(n, 5);
    }
  }

  stage.addEventListener('pointerup', function (e) {
    if (pathNodeDragging) { endPathNodeDrag(e); return; }
    if (panning) { endPan(e); return; }
    if (drawing) { endDraw(e); return; }
    if (dragging) { endDrag(e); return; }
    if (resizing) { endResize(e); return; }
    if (rotating) { endRotate(e); return; }
  });

  stage.addEventListener('pointercancel', function (e) {
    if (drawing && drawing.node) drawing.node.remove();
    if (polygonPreview) { polygonPreview.remove(); polygonPreview = null; }
    if (pathNodeDragging) endPathNodeDrag(e);
    drawing = null; dragging = null; resizing = null; rotating = null; panning = null; penPoints = [];
    polygonPoints = [];
  });

  stage.addEventListener('pointerleave', function (e) { if (!e.buttons) { if (pathNodeDragging) endPathNodeDrag(e); if (drawing) endDraw(e); if (dragging) endDrag(e); if (resizing) endResize(e); if (rotating) endRotate(e); if (panning) endPan(e); } });

  function endDraw(e) { var n = drawing.node; drawing = null; penPoints = []; if (n) { if (n.tagName === 'path' && !n.getAttribute('d')) { n.remove(); return; } selectSingle(n); snapshot(); } }

  // ---- Star ----
  function rebuildStar(node, points) {
    var cx = parseFloat(node.getAttribute('data-cx')), cy = parseFloat(node.getAttribute('data-cy'));
    var r = parseFloat(node.getAttribute('data-r'));
    var ri = r * 0.4;
    var d = '';
    for (var i = 0; i < points * 2; i++) {
      var ang = (Math.PI / points) * i - Math.PI / 2;
      var rad = i % 2 === 0 ? r : ri;
      var x = cx + rad * Math.cos(ang), y = cy + rad * Math.sin(ang);
      d += (i === 0 ? 'M' : 'L') + x.toFixed(1) + ' ' + y.toFixed(1) + ' ';
    }
    node.setAttribute('d', d + 'Z');
  }

  // ---- Polygon (click-based) ----
  function closePolygon() {
    if (polygonPoints.length < 3) return;
    // Remove duplicate consecutive points (e.g. from a double-click)
    var pts = [polygonPoints[0]];
    for (var i = 1; i < polygonPoints.length; i++) {
      var last = pts[pts.length - 1], p = polygonPoints[i];
      if (Math.hypot(p.x - last.x, p.y - last.y) >= 1) pts.push(p);
    }
    if (pts.length < 3) { polygonPoints = []; if (polygonPreview) { polygonPreview.remove(); polygonPreview = null; } return; }
    var d = 'M' + pts[0].x + ' ' + pts[0].y;
    for (var i = 1; i < pts.length; i++) d += ' L' + pts[i].x + ' ' + pts[i].y;
    var node = el('path', { d: d + 'Z', fill: document.getElementById('fillColor').value, stroke: document.getElementById('strokeColor').value, 'stroke-width': parseInt(document.getElementById('strokeWidth').value, 10), 'stroke-linejoin': 'round', 'data-id': uid() });
    artboard.appendChild(node);
    if (polygonPreview) { polygonPreview.remove(); polygonPreview = null; }
    polygonPoints = [];
    selectSingle(node);
    snapshot();
  }

  function handlePolygonClick(e) {
    var p = getMouse(e); p.x = snapVal(p.x); p.y = snapVal(p.y);
    if (polygonPoints.length >= 3) {
      var first = polygonPoints[0];
      if (Math.hypot(p.x - first.x, p.y - first.y) < GRID / 2) { closePolygon(); return; }
    }
    polygonPoints.push(p);
    if (!polygonPreview) {
      polygonPreview = el('path', { fill: 'none', stroke: document.getElementById('strokeColor').value, 'stroke-width': 1, 'stroke-dasharray': '4 4', opacity: 0.5, 'pointer-events': 'none' });
      artboard.appendChild(polygonPreview);
    }
    updatePolygonPreview(e);
  }

  function updatePolygonPreview(e) {
    if (!polygonPreview || polygonPoints.length === 0) return;
    var p = getMouse(e); p.x = snapVal(p.x); p.y = snapVal(p.y);
    var d = 'M' + polygonPoints[0].x + ' ' + polygonPoints[0].y;
    for (var i = 1; i < polygonPoints.length; i++) d += ' L' + polygonPoints[i].x + ' ' + polygonPoints[i].y;
    d += ' L' + p.x + ' ' + p.y;
    polygonPreview.setAttribute('d', d);
  }

  stage.addEventListener('dblclick', function (e) {
    if (tool === 'polygon' && polygonPoints.length >= 3) {
      closePolygon();
      e.preventDefault();
    }
  });

  // ---- Drag / Move ----
  function startDrag(e) {
    if (selected.length === 0) return;
    if (e.altKey) {
      var clones = cloneNodesWithReferences(selected);
      clones.forEach(function (clone) { artboard.appendChild(clone); });
      selectSingle(clones[0]);
      for (var i = 1; i < clones.length; i++) selected.push(clones[i]);
      updateSelection(); updateLayers(); updateActionButtons(); syncToolbar();
      showToast(t('toast_duplicated', 'Duplicated'));
    }
    dragging = {
      states: selected.map(function (node) {
        var matrix = matrixOf(node);
        return { node: node, start: pointerInParent(e, node), matrix: matrix, bounds: getParentBounds(node, matrix) };
      })
    };
    stage.setPointerCapture(e.pointerId);
  }

  function updateDrag(e) {
    dragging.states.forEach(function (state) {
      var point = pointerInParent(e, state.node);
      var dx = point.x - state.start.x;
      var dy = point.y - state.start.y;
      if (snapToGrid) {
        dx = snapVal(state.bounds.x + dx) - state.bounds.x;
        dy = snapVal(state.bounds.y + dy) - state.bounds.y;
      }
      translateNode(state.node, dx, dy, state.matrix);
    });
    dragging.moved = true;
    updateSelection();
  }

  function endDrag(e) { var moved = dragging && dragging.moved; dragging = null; try { stage.releasePointerCapture(e.pointerId); } catch (_) {} if (moved) snapshot(); }

  function moveElement(node, x, y) {
    var bounds = getParentBounds(node);
    translateNode(node, x - bounds.x, y - bounds.y);
  }

  function setElementBounds(node, nextBounds) {
    var matrix = matrixOf(node);
    var bounds = getParentBounds(node, matrix);
    var width = nextBounds.width === undefined ? bounds.width : nextBounds.width;
    var height = nextBounds.height === undefined ? bounds.height : nextBounds.height;
    var x = nextBounds.x === undefined ? bounds.x : nextBounds.x;
    var y = nextBounds.y === undefined ? bounds.y : nextBounds.y;
    if (width < 0 || height < 0) return false;
    if (bounds.width <= 0 && Math.abs(width - bounds.width) > 0.000001) return false;
    if (bounds.height <= 0 && Math.abs(height - bounds.height) > 0.000001) return false;
    var sx = bounds.width > 0 ? width / bounds.width : 1;
    var sy = bounds.height > 0 ? height / bounds.height : 1;
    // Scale in the element's local space so rotated elements don't shear,
    // then reposition to the requested x/y.
    var bb = node.getBBox();
    var localScale = new DOMMatrix().translate(bb.x, bb.y).scale(sx, sy).translate(-bb.x, -bb.y);
    setNodeMatrix(node, matrix.multiply(localScale));
    var scaledBounds = getParentBounds(node);
    translateNode(node, x - scaledBounds.x, y - scaledBounds.y);
    return true;
  }

  // ---- Resize ----
  function startResize(e) {
    var handle = e.target.closest('.editor__handle'); if (!handle || selected.length !== 1) return;
    var dir = handle.dataset.h, node = primary();
    var matrix = matrixOf(node), bounds = getParentBounds(node, matrix), p = pointerInParent(e, node);
    resizing = { dir: dir, sx: p.x, sy: p.y, bx: bounds.x, by: bounds.y, bw: bounds.width, bh: bounds.height, matrix: matrix, node: node };
    stage.setPointerCapture(e.pointerId); e.preventDefault();
  }

  function updateResize(e) {
    var node = resizing.node, p = pointerInParent(e, node);
    if (snapToGrid) { p.x = snapVal(p.x); p.y = snapVal(p.y); }
    var dx = p.x - resizing.sx, dy = p.y - resizing.sy, dir = resizing.dir;
    var nw = resizing.bw, nh = resizing.bh;
    if (dir.indexOf('w') >= 0) nw = resizing.bw - dx;
    if (dir.indexOf('e') >= 0) nw = resizing.bw + dx;
    if (dir.indexOf('n') >= 0) nh = resizing.bh - dy;
    if (dir.indexOf('s') >= 0) nh = resizing.bh + dy;
    if (e.shiftKey && resizing.bw > 0 && resizing.bh > 0) {
      var ratio = resizing.bw / resizing.bh;
      if (dir === 'n' || dir === 's') { nw = nh * ratio; }
      else if (dir === 'e' || dir === 'w') { nh = nw / ratio; }
      else {
        if (nw / nh > ratio) { nh = nw / ratio; } else { nw = nh * ratio; }
      }
    }
    if (nw < 2) nw = 2;
    if (nh < 2) nh = 2;
    var sx = resizing.bw ? nw / resizing.bw : 1;
    var sy = resizing.bh ? nh / resizing.bh : 1;
    // Scale in the element's local space anchored at the opposite corner
    // so rotated elements resize without shearing.
    var bb = node.getBBox();
    var ax = dir.indexOf('w') >= 0 ? bb.x + bb.width : bb.x;
    var ay = dir.indexOf('n') >= 0 ? bb.y + bb.height : bb.y;
    var localScale = new DOMMatrix().translate(ax, ay).scale(sx, sy).translate(-ax, -ay);
    setNodeMatrix(node, resizing.matrix.multiply(localScale));
    resizing.moved = true;
    updateSelection();
  }

  function endResize(e) { var moved = resizing && resizing.moved; resizing = null; try { stage.releasePointerCapture(e.pointerId); } catch (_) {} if (moved) { snapshot(); updateProps(); } }

  // ---- Rotation ----
  function startRotate(e) {
    if (selected.length !== 1) return;
    var node = primary(), matrix = matrixOf(node), bounds = getParentBounds(node, matrix);
    var p = pointerInParent(e, node), cx = bounds.x + bounds.width / 2, cy = bounds.y + bounds.height / 2;
    rotating = {
      node: node, matrix: matrix, cx: cx, cy: cy,
      startPointerAngle: Math.atan2(p.y - cy, p.x - cx) * 180 / Math.PI,
      initialAngle: rotationOf(node)
    };
    stage.setPointerCapture(e.pointerId); e.preventDefault();
  }

  function updateRotate(e) {
    var node = rotating.node, p = pointerInParent(e, node);
    var pointerAngle = Math.atan2(p.y - rotating.cy, p.x - rotating.cx) * 180 / Math.PI;
    var targetAngle = rotating.initialAngle + pointerAngle - rotating.startPointerAngle;
    targetAngle = Math.round(targetAngle);
    if (e.shiftKey) targetAngle = Math.round(targetAngle / 15) * 15;
    setNodeMatrix(node, rotateAtMatrix(targetAngle - rotating.initialAngle, rotating.cx, rotating.cy).multiply(rotating.matrix));
    rotating.moved = true;
    updateSelection();
  }

  function endRotate(e) { var moved = rotating && rotating.moved; rotating = null; try { stage.releasePointerCapture(e.pointerId); } catch (_) {} if (moved) { snapshot(); updateProps(); } }

  // ---- Pan / Zoom ----
  function startPan(e) { var p = getMouse(e); panning = { sx: e.clientX, sy: e.clientY, vx: VB.x, vy: VB.y }; stage.setPointerCapture(e.pointerId); e.preventDefault(); }
  function updatePan(e) {
    var rect = stage.getBoundingClientRect();
    var scale = Math.max(VB.w / rect.width, VB.h / rect.height);
    VB.x = panning.vx - (e.clientX - panning.sx) * scale;
    VB.y = panning.vy - (e.clientY - panning.sy) * scale;
    applyViewBox();
  }
  function endPan(e) { panning = null; try { stage.releasePointerCapture(e.pointerId); } catch (_) {} }

  stage.addEventListener('wheel', function (e) {
    e.preventDefault();
    var p = getMouse(e), delta = e.deltaY > 0 ? 1.1 : 0.9;
    var newW = VB.w * delta, newH = VB.h * delta;
    if (newW < DOC.w / 100 || newW > DOC.w * 100 || newH < DOC.h / 100 || newH > DOC.h * 100) return;
    VB.x = p.x - (p.x - VB.x) * delta;
    VB.y = p.y - (p.y - VB.y) * delta;
    VB.w = newW; VB.h = newH;
    applyViewBox();
  }, { passive: false });

  document.addEventListener('keydown', function (e) {
    if (e.key === ' ' && !e.target.matches('input, textarea')) { spaceDown = true; stage.style.cursor = 'grab'; e.preventDefault(); }
  });
  document.addEventListener('keyup', function (e) { if (e.key === ' ') { spaceDown = false; stage.style.cursor = ''; } });

  // Zoom buttons
  function zoomBy(factor) { var cx = VB.x + VB.w / 2, cy = VB.y + VB.h / 2; VB.w *= factor; VB.h *= factor; VB.x = cx - VB.w / 2; VB.y = cy - VB.h / 2; applyViewBox(); }
  document.getElementById('zoomInBtn').addEventListener('click', function () { zoomBy(0.8); });
  document.getElementById('zoomOutBtn').addEventListener('click', function () { zoomBy(1.25); });
  document.getElementById('fitBtn').addEventListener('click', fitDocument);

  function applyCanvasSize(width, height) {
    width = Number(width);
    height = Number(height);
    if (!isFinite(width) || !isFinite(height) || width < 1 || height < 1 || width > 100000 || height > 100000) {
      showToast(t('ed_invalid_canvas_size', 'Enter a canvas size from 1 to 100000.'));
      syncCanvasControls();
      return;
    }
    DOC.w = width;
    DOC.h = height;
    fitDocument();
    syncCanvasControls();
    snapshot();
    showToast(tpl('ed_canvas_resized', 'Canvas resized to {width} × {height}', { width: width, height: height }));
  }

  document.getElementById('canvasPreset').addEventListener('change', function () {
    if (this.value === 'custom') return;
    var size = this.value.split('x').map(Number);
    applyCanvasSize(size[0], size[1]);
  });
  document.getElementById('applyCanvasBtn').addEventListener('click', function () {
    applyCanvasSize(document.getElementById('canvasWidth').value, document.getElementById('canvasHeight').value);
  });
  document.getElementById('fitCanvasBtn').addEventListener('click', fitDocument);

  // Grid / Snap
  document.getElementById('gridBtn').addEventListener('click', function () { showGrid = !showGrid; this.classList.toggle('is-toggled', showGrid); updateGrid(); });
  document.getElementById('snapBtn').addEventListener('click', function () { snapToGrid = !snapToGrid; this.classList.toggle('is-toggled', snapToGrid); });

  // ---- Toolbar controls ----
  document.getElementById('fillColor').addEventListener('input', function () { if (selected.length) { selected.forEach(function(n){n.setAttribute('fill',this.value);}.bind(this)); updateLayers(); syncCode(); } });
  document.getElementById('fillColor').addEventListener('change', function () { if (selected.length) snapshot(); });
  document.getElementById('strokeColor').addEventListener('input', function () { if (selected.length) { selected.forEach(function(n){n.setAttribute('stroke',this.value);}.bind(this)); updateLayers(); syncCode(); } });
  document.getElementById('strokeColor').addEventListener('change', function () { if (selected.length) snapshot(); });
  document.getElementById('strokeWidth').addEventListener('input', function () { document.getElementById('strokeWidthValue').textContent = this.value; if (selected.length) { selected.forEach(function(n){n.setAttribute('stroke-width',this.value);}.bind(this)); syncCode(); } });
  document.getElementById('strokeWidth').addEventListener('change', function () { if (selected.length) snapshot(); });

  // ---- Actions ----
  document.getElementById('deleteBtn').addEventListener('click', function () { if (!selected.length) return; selected.forEach(function (n) { n.remove(); }); deselect(); snapshot(); showToast(t('toast_deleted', 'Deleted')); });
  document.getElementById('duplicateBtn').addEventListener('click', function () { if (!selected.length) return; var clones = cloneNodesWithReferences(selected); clones.forEach(function (c) { offsetElement(c, 20, 20); artboard.appendChild(c); }); selectSingle(clones[0]); for (var i = 1; i < clones.length; i++) selected.push(clones[i]); updateSelection(); updateLayers(); updateActionButtons(); syncToolbar(); snapshot(); showToast(t('toast_duplicated', 'Duplicated')); });
  document.getElementById('frontBtn').addEventListener('click', function () {
    if (!selected.length) return;
    var ordered = userElements().filter(function (node) { return selected.indexOf(node) >= 0; });
    ordered.forEach(function (node) { artboard.appendChild(node); });
    snapshot(); updateLayers();
  });
  document.getElementById('backBtn').addEventListener('click', function () {
    if (!selected.length) return;
    var ordered = userElements().filter(function (node) { return selected.indexOf(node) >= 0; });
    var firstUnselected = userElements().find(function (node) { return selected.indexOf(node) < 0; });
    if (firstUnselected) ordered.forEach(function (node) { artboard.insertBefore(node, firstUnselected); });
    snapshot(); updateLayers();
  });
  document.getElementById('undoBtn').addEventListener('click', undo);
  document.getElementById('redoBtn').addEventListener('click', redo);

  // Flip
  function flipSelected(horizontal) {
    selected.forEach(function (node) {
      var matrix = matrixOf(node), bounds = getParentBounds(node, matrix);
      var cx = bounds.x + bounds.width / 2, cy = bounds.y + bounds.height / 2;
      var flip = scaleAtMatrix(horizontal ? -1 : 1, horizontal ? 1 : -1, cx, cy);
      setNodeMatrix(node, flip.multiply(matrix));
    });
    snapshot(); updateSelection(); updateProps();
  }
  document.getElementById('flipHBtn').addEventListener('click', function () { flipSelected(true); });
  document.getElementById('flipVBtn').addEventListener('click', function () { flipSelected(false); });

  // Group / Ungroup
  document.getElementById('groupBtn').addEventListener('click', function () {
    if (selected.length < 2) return;
    var g = el('g', { 'data-id': uid() });
    var parent = selected[0].parentNode;
    parent.insertBefore(g, selected[0]);
    selected.forEach(function (n) { g.appendChild(n); });
    selectSingle(g);
    snapshot();
    showToast(t('toast_grouped', 'Grouped'));
  });
  document.getElementById('ungroupBtn').addEventListener('click', function () {
    var groups = selected.filter(function (n) { return getElementType(n) === 'g'; });
    if (groups.length === 0) return;
    groups.forEach(function (g) {
      var parent = g.parentNode;
      var groupMatrix = matrixOf(g);
      while (g.firstChild) {
        var child = g.firstChild;
        g.removeChild(child);
        if (child.nodeType !== Node.ELEMENT_NODE) { parent.insertBefore(child, g); continue; }
        var childMatrix = matrixOf(child);
        parent.insertBefore(child, g);
        setNodeMatrix(child, groupMatrix.multiply(childMatrix));
        child.setAttribute('data-id', child.getAttribute('data-id') || uid());
      }
      parent.removeChild(g);
    });
    deselect();
    snapshot();
    showToast(t('toast_ungrouped', 'Ungrouped'));
  });

  // Align
  document.getElementById('alignGroup').addEventListener('click', function (e) {
    var btn = e.target.closest('[data-align]'); if (!btn || selected.length < 2) return;
    var bbs = selected.map(function (n) { return getParentBounds(n); });
    var type = btn.dataset.align;
    if (type === 'left') bbs.forEach(function (b, i) { moveElement(selected[i], bbs[0].x, b.y); });
    else if (type === 'right') bbs.forEach(function (b, i) { moveElement(selected[i], bbs[0].x + bbs[0].width - b.width, b.y); });
    else if (type === 'ch') { var cx = bbs[0].x + bbs[0].width/2; bbs.forEach(function(b,i){ moveElement(selected[i], cx - b.width/2, b.y); }); }
    else if (type === 'top') bbs.forEach(function (b, i) { moveElement(selected[i], b.x, bbs[0].y); });
    else if (type === 'bottom') bbs.forEach(function (b, i) { moveElement(selected[i], b.x, bbs[0].y + bbs[0].height - b.height); });
    else if (type === 'cv') { var cy = bbs[0].y + bbs[0].height/2; bbs.forEach(function(b,i){ moveElement(selected[i], b.x, cy - b.height/2); }); }
    updateSelection(); snapshot();
  });

  // ---- Import / Export ----
  function deepImport(srcNode) {
    if (srcNode.nodeType === Node.TEXT_NODE) return document.createTextNode(srcNode.textContent);
    if (srcNode.nodeType !== Node.ELEMENT_NODE) return null;
    // localName keeps camelCase (linearGradient, clipPath); lowercasing breaks them.
    var node = document.createElementNS(SVG_NS, srcNode.localName);
    for (var i = 0; i < srcNode.attributes.length; i++) {
      node.setAttribute(srcNode.attributes[i].name, srcNode.attributes[i].value);
    }
    Array.from(srcNode.childNodes).forEach(function (child) {
      var imported = deepImport(child);
      if (imported) node.appendChild(imported);
    });
    return node;
  }

  document.getElementById('importBtn').addEventListener('click', function () { document.getElementById('importInput').click(); });
  document.getElementById('importInput').addEventListener('change', function () {
    var file = this.files[0]; if (!file) return;
    var reader = new FileReader();
    reader.onload = function (e) {
      try {
        // DOMParser gives an inert document: unlike div.innerHTML, handlers such as
        // <img onerror> in the file never fire. text/html keeps lenient parsing.
        var parsedDoc = new DOMParser().parseFromString(e.target.result, 'text/html');
        var svg = parsedDoc.querySelector('svg'); if (!svg) { showToast(t('ed_no_svg_found', 'No SVG found')); return; }
        sanitizeSvg(svg);
        var importedViewBox = sourceViewBox(svg);
        DOC = { x: importedViewBox[0], y: importedViewBox[1], w: importedViewBox[2], h: importedViewBox[3] };
        VB = { x: DOC.x, y: DOC.y, w: DOC.w, h: DOC.h };
        artboard.innerHTML = '';
        initGrid();
        var children = Array.from(svg.children);
        children.forEach(function (child) {
          if (child.tagName.toLowerCase() === 'defs') {
            var defs = artboard.querySelector('defs') || el('defs');
            if (!artboard.querySelector('defs')) artboard.insertBefore(defs, artboard.firstChild);
            Array.from(child.children).forEach(function (defChild) { defs.appendChild(deepImport(defChild)); });
            return;
          }
          var imported = deepImport(child);
          if (!imported) return;
          imported.setAttribute('data-id', uid());
          artboard.appendChild(imported);
        });
        deselect(); applyViewBox(); syncCanvasControls(); snapshot();
        showToast(tpl('ed_imported_elements', 'Imported {count} elements', { count: children.length }));
      } catch (err) { showToast(t('ed_import_fail', 'Import failed')); }
    };
    reader.readAsText(file); this.value = '';
  });

  function sanitizeSvg(svgEl) {
    svgEl.querySelectorAll('script').forEach(function (s) { s.remove(); });
    svgEl.querySelectorAll('foreignObject').forEach(function (f) { f.remove(); });
    svgEl.querySelectorAll('*').forEach(function (n) {
      Array.from(n.attributes).forEach(function (a) {
        if (/^on/i.test(a.name)) n.removeAttribute(a.name);
        if ((a.name === 'href' || a.name === 'xlink:href') && /^\s*javascript:/i.test(a.value)) n.removeAttribute(a.name);
      });
    });
  }

  function getExportBounds() {
    var nodes = Array.from(artboard.children).filter(function (n) {
      return n.tagName !== 'defs' && n.id !== 'gridRect' && n.id !== 'gridPattern' && n.getAttribute('data-hidden') !== 'true';
    });
    if (!nodes.length) return null;

    var rootMatrix = artboard.getCTM();
    if (!rootMatrix) return null;
    var rootInverse = rootMatrix.inverse();
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;

    nodes.forEach(function (node) {
      try {
        var bb = node.getBBox();
        var matrix = node.getCTM();
        if (!matrix || !isFinite(bb.width) || !isFinite(bb.height)) return;
        var strokeWidth = parseFloat(node.getAttribute('stroke-width') || window.getComputedStyle(node).strokeWidth || '0') || 0;
        var pad = strokeWidth / 2;
        var points = [
          [bb.x - pad, bb.y - pad],
          [bb.x + bb.width + pad, bb.y - pad],
          [bb.x - pad, bb.y + bb.height + pad],
          [bb.x + bb.width + pad, bb.y + bb.height + pad]
        ];
        points.forEach(function (pt) {
          var p = new DOMPoint(pt[0], pt[1]).matrixTransform(matrix).matrixTransform(rootInverse);
          minX = Math.min(minX, p.x); minY = Math.min(minY, p.y);
          maxX = Math.max(maxX, p.x); maxY = Math.max(maxY, p.y);
        });
      } catch (_) {}
    });

    if (minX === Infinity) return null;
    var padding = 2;
    return {
      x: Math.floor(minX - padding),
      y: Math.floor(minY - padding),
      w: Math.ceil(maxX - minX + padding * 2),
      h: Math.ceil(maxY - minY + padding * 2)
    };
  }

  function makeExportClone() {
    var clone = cleanArtboardClone();
    clone.removeAttribute('id');
    clone.querySelectorAll('[data-hidden="true"]').forEach(function (node) { node.remove(); });
    clone.querySelectorAll('[data-id], [data-name], [data-locked], [data-hidden], [data-points], [data-cx], [data-cy], [data-r]').forEach(function (node) {
      node.removeAttribute('data-id');
      node.removeAttribute('data-name');
      node.removeAttribute('data-locked');
      node.removeAttribute('data-hidden');
      node.removeAttribute('data-points');
      node.removeAttribute('data-cx');
      node.removeAttribute('data-cy');
      node.removeAttribute('data-r');
    });
    var mode = document.getElementById('exportArea').value;
    var bounds = mode === 'content' ? getExportBounds() : { x: DOC.x, y: DOC.y, w: DOC.w, h: DOC.h };
    if (!bounds || bounds.w <= 0 || bounds.h <= 0) return null;
    clone.setAttribute('xmlns', SVG_NS);
    clone.setAttribute('viewBox', bounds.x + ' ' + bounds.y + ' ' + bounds.w + ' ' + bounds.h);
    clone.setAttribute('width', bounds.w);
    clone.setAttribute('height', bounds.h);
    return { clone: clone, bounds: bounds };
  }

  document.getElementById('exportSvgBtn').addEventListener('click', function () {
    var output = makeExportClone();
    if (!output) { showToast(t('ed_nothing_export', 'Nothing visible to export')); return; }
    var clone = output.clone;
    var source = '<?xml version="1.0" encoding="UTF-8"?>\n' + new XMLSerializer().serializeToString(clone).replace(/></g, '>\n<');
    downloadBlob(new Blob([source], { type: 'image/svg+xml' }), '70015-editor-' + Date.now() + '.svg');
    showToast(t('toast_exported', 'Exported'));
  });

  document.getElementById('exportPngBtn').addEventListener('click', function () {
    var output = makeExportClone();
    if (!output) { showToast(t('ed_nothing_export', 'Nothing visible to export')); return; }
    var clone = output.clone;
    var source = new XMLSerializer().serializeToString(clone);
    var url = URL.createObjectURL(new Blob([source], { type: 'image/svg+xml' }));
    var img = new Image();
    var scale = parseInt(document.getElementById('pngScale').value, 10) || 1;
    var vb = (clone.getAttribute('viewBox') || '0 0 800 600').split(/\s+/).map(parseFloat);
    var vw = vb[2] || 800, vh = vb[3] || 600;
    var outputWidth = Math.round(vw * scale), outputHeight = Math.round(vh * scale);
    if (outputWidth > 16384 || outputHeight > 16384 || outputWidth * outputHeight > 67108864) {
      URL.revokeObjectURL(url);
      showToast(t('ed_export_too_large', 'PNG dimensions are too large for this browser. Reduce the canvas or export scale.'));
      return;
    }
    img.onload = function () {
      var cv = document.createElement('canvas');
      cv.width = outputWidth; cv.height = outputHeight;
      var cx = cv.getContext('2d'); cx.drawImage(img, 0, 0, cv.width, cv.height);
      cv.toBlob(function (b) {
        downloadBlob(b, '70015-editor-' + Date.now() + '.png');
        URL.revokeObjectURL(url);
        if (b) showToast(t('toast_exported', 'Exported'));
      }, 'image/png');
    };
    img.onerror = function () { URL.revokeObjectURL(url); showToast(t('ed_png_export_fail', 'PNG export failed')); };
    img.src = url;
  });

  function downloadBlob(blob, name) {
    if (!blob) return;
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  // ---- Copy code ----
  document.getElementById('copyCodeBtn').addEventListener('click', function () {
    var text = codeView.value;
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function(){showToast(t('toast_copied', 'Copied'));},function(){showToast(t('toast_copy_fail', 'Copy failed'));});
    else { codeView.select(); try{document.execCommand('copy');showToast(t('toast_copied', 'Copied'));}catch(_){showToast(t('toast_copy_fail', 'Copy failed'));} }
  });

  function sourceViewBox(svg) {
    var raw = (svg.getAttribute('viewBox') || '').trim();
    var values = raw ? raw.split(/[\s,]+/).map(Number) : [];
    if (values.length === 4 && values.every(isFinite) && values[2] > 0 && values[3] > 0) return values;
    var width = parseFloat(svg.getAttribute('width')) || 800;
    var height = parseFloat(svg.getAttribute('height')) || 600;
    return [0, 0, width, height];
  }

  function applySourceCode() {
    try {
      var doc = new DOMParser().parseFromString(codeView.value, 'image/svg+xml');
      if (doc.querySelector('parsererror') || !doc.documentElement || doc.documentElement.tagName.toLowerCase() !== 'svg') throw new Error('Invalid SVG');
      var parsed = doc.documentElement;
      sanitizeSvg(parsed);
      var viewBox = sourceViewBox(parsed);
      artboard.innerHTML = '';
      var defs = el('defs');
      artboard.appendChild(defs);
      Array.from(parsed.children).forEach(function (child) {
        if (child.tagName.toLowerCase() === 'defs') {
          Array.from(child.childNodes).forEach(function (definition) {
            var importedDefinition = deepImport(definition);
            if (importedDefinition) defs.appendChild(importedDefinition);
          });
        } else {
          var imported = deepImport(child);
          if (!imported) return;
          if (!imported.getAttribute('data-id')) imported.setAttribute('data-id', uid());
          artboard.appendChild(imported);
        }
      });
      DOC = { x: viewBox[0], y: viewBox[1], w: viewBox[2], h: viewBox[3] };
      VB = { x: DOC.x, y: DOC.y, w: DOC.w, h: DOC.h };
      initGrid();
      codeDirty = false;
      codeView.removeAttribute('aria-invalid');
      deselect(); applyViewBox(); syncCanvasControls(); snapshot(); showToast(t('toast_applied', 'Source applied'));
    } catch (err) {
      codeView.setAttribute('aria-invalid', 'true');
      showToast(t('toast_invalid', 'Invalid SVG'));
    }
  }

  codeView.addEventListener('input', function () {
    codeDirty = true;
    codeView.removeAttribute('aria-invalid');
    updateSourceButtons();
  });
  document.getElementById('applyCodeBtn').addEventListener('click', applySourceCode);
  document.getElementById('revertCodeBtn').addEventListener('click', function () { syncCode(true); });

  // ---- Clear ----
  document.getElementById('clearBtn').addEventListener('click', function () {
    Array.from(artboard.children).forEach(function (c) { if (c.tagName !== 'defs' && c.id !== 'gridRect') c.remove(); });
    var defs = artboard.querySelector('defs');
    if (defs) Array.from(defs.children).forEach(function (child) { if (child.id !== 'gridPattern') child.remove(); });
    initGrid();
    deselect(); snapshot(); showToast(t('ed_canvas_cleared', 'Canvas cleared'));
  });

  // ---- Clipboard ----
  function elementsIn(root) {
    return [root].concat(Array.from(root.querySelectorAll('*')));
  }

  function referencedIds(root) {
    var ids = [];
    elementsIn(root).forEach(function (node) {
      Array.from(node.attributes || []).forEach(function (attr) {
        var value = attr.value || '', match;
        var urlPattern = /url\(\s*#([^)\s]+)\s*\)/g;
        while ((match = urlPattern.exec(value))) ids.push(match[1]);
        if ((attr.name === 'href' || attr.name === 'xlink:href') && value.charAt(0) === '#') ids.push(value.slice(1));
      });
    });
    return ids;
  }

  function findArtboardId(id) {
    return Array.from(artboard.querySelectorAll('[id]')).find(function (node) { return node.id === id; }) || null;
  }

  function nextReferenceId(base) {
    return (base || 'ref') + '-copy-' + (++uidCounter);
  }

  function rewriteReferences(root, idMap) {
    elementsIn(root).forEach(function (node) {
      Array.from(node.attributes || []).forEach(function (attr) {
        var value = attr.value;
        Object.keys(idMap).forEach(function (oldId) {
          var newId = idMap[oldId];
          value = value.split('url(#' + oldId + ')').join('url(#' + newId + ')');
          if ((attr.name === 'href' || attr.name === 'xlink:href') && value === '#' + oldId) value = '#' + newId;
        });
        if (value !== attr.value) node.setAttribute(attr.name, value);
      });
    });
  }

  function cloneWithNewIds(node, idMap) {
    var clone = node.cloneNode(true);
    idMap = idMap || {};
    elementsIn(clone).forEach(function (child) {
      if (child.hasAttribute && child.hasAttribute('data-id')) child.setAttribute('data-id', uid());
      if (child.id) {
        var oldId = child.id;
        if (!idMap[oldId]) idMap[oldId] = nextReferenceId(oldId);
        child.id = idMap[oldId];
      }
    });
    clone.setAttribute('data-id', uid());

    var defs = artboard.querySelector('defs') || el('defs');
    if (!artboard.querySelector('defs')) artboard.insertBefore(defs, artboard.firstChild);
    var queue = referencedIds(clone);
    var definitionClones = [];
    while (queue.length) {
      var refId = queue.shift();
      if (idMap[refId]) continue;
      var source = findArtboardId(refId);
      if (!source || !source.closest('defs')) continue;
      var definition = source.cloneNode(true);
      elementsIn(definition).forEach(function (child) {
        if (!child.id) return;
        var oldId = child.id;
        if (!idMap[oldId]) idMap[oldId] = nextReferenceId(oldId);
        child.id = idMap[oldId];
      });
      definitionClones.push(definition);
      queue = queue.concat(referencedIds(definition));
    }
    rewriteReferences(clone, idMap);
    definitionClones.forEach(function (definition) { rewriteReferences(definition, idMap); defs.appendChild(definition); });
    return clone;
  }

  function cloneNodesWithReferences(nodes) {
    var idMap = {};
    return nodes.map(function (node) { return cloneWithNewIds(node, idMap); });
  }

  function copySelected(cut) {
    if (!selected.length) return;
    clipboard = selected.map(function (n) { return n.cloneNode(true); });
    if (cut) {
      selected.forEach(function (n) { n.remove(); });
      deselect();
      snapshot();
      showToast(t('ed_cut', 'Cut'));
    } else {
      showToast(t('toast_copied', 'Copied'));
    }
  }

  function pasteClipboard() {
    if (!clipboard.length) return;
    var clones = cloneNodesWithReferences(clipboard);
    clones.forEach(function (c) {
      offsetElement(c, 20, 20);
      artboard.appendChild(c);
    });
    selectSingle(clones[0]);
    for (var i = 1; i < clones.length; i++) selected.push(clones[i]);
    updateSelection(); updateLayers(); updateActionButtons(); syncToolbar();
    snapshot();
    showToast(t('ed_pasted', 'Pasted'));
  }

  // ---- Keyboard ----
  document.addEventListener('keydown', function (e) {
    var tag = e.target.tagName; if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    if (e.ctrlKey || e.metaKey) {
      // Shift/CapsLock turn e.key uppercase ('Z'), so compare lowercased.
      var key = e.key.toLowerCase();
      if (key === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
      if (key === 'y') { e.preventDefault(); redo(); return; }
      if (key === 'd' && selected.length) { e.preventDefault(); document.getElementById('duplicateBtn').click(); return; }
      if (key === 'g' && selected.length) { e.preventDefault(); if (e.shiftKey) document.getElementById('ungroupBtn').click(); else document.getElementById('groupBtn').click(); return; }
      if (key === 'a') { e.preventDefault(); clearPathEditing(); selected = userElements().filter(function (node) { return !isLocked(node) && !isHidden(node); }); updateSelection(); updateProps(); updateLayers(); updateActionButtons(); return; }
      if (key === 'c') { e.preventDefault(); copySelected(false); return; }
      if (key === 'x') { e.preventDefault(); copySelected(true); return; }
      if (key === 'v') { e.preventDefault(); pasteClipboard(); return; }
    }
    if ((e.key === 'Delete' || e.key === 'Backspace') && selected.length) {
      e.preventDefault();
      if (pathEditing) deleteSelectedPathNode();
      else document.getElementById('deleteBtn').click();
    }
    if (e.key === 'Escape') {
      if (pathEditing) { clearPathEditing(); updateSelection(); updateProps(); return; }
      if (drawing && drawing.node) { drawing.node.remove(); drawing = null; penPoints = []; return; }
      if (polygonPoints.length) { polygonPoints = []; if (polygonPreview) { polygonPreview.remove(); polygonPreview = null; } return; }
      deselect();
    }
    // Arrow nudge
    if (selected.length && !spaceDown && !pathEditing) {
      var step = e.shiftKey ? 10 : 1;
      if (e.key === 'ArrowLeft') { e.preventDefault(); selected.forEach(function(n){ var bb=getParentBounds(n); moveElement(n, bb.x - step, bb.y); }); updateSelection(); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); selected.forEach(function(n){ var bb=getParentBounds(n); moveElement(n, bb.x + step, bb.y); }); updateSelection(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); selected.forEach(function(n){ var bb=getParentBounds(n); moveElement(n, bb.x, bb.y - step); }); updateSelection(); }
      else if (e.key === 'ArrowDown') { e.preventDefault(); selected.forEach(function(n){ var bb=getParentBounds(n); moveElement(n, bb.x, bb.y + step); }); updateSelection(); }
    }
    // Tool shortcuts
    if (!e.ctrlKey && !e.metaKey && !e.altKey) {
      if (e.key === '1') setTool('select');
      if (e.key === '2') setTool('rect');
      if (e.key === '3') setTool('ellipse');
      if (e.key === '4') setTool('line');
      if (e.key === '5') setTool('text');
      if (e.key === '6') setTool('pen');
      if (e.key === '7') setTool('polygon');
      if (e.key === '8') setTool('star');
    }
  });

  document.addEventListener('keyup', function (e) {
    var tag = e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    if (e.key.startsWith('Arrow') && selected.length && !pathEditing) snapshot();
  });

  // ---- Helper: offset element ----
  function offsetElement(node, dx, dy) {
    translateNode(node, dx, dy);
  }

  // ---- Layers panel ----
  var sidebar = document.querySelector('.editor__sidebar');
  var layersPanel = document.createElement('div');
  layersPanel.className = 'editor__panel editor__panel--layers';
  layersPanel.innerHTML = '<div class="editor__panel-head"><span class="editor__panel-title" data-i18n="ed_layers">' + t('ed_layers', 'Layers') + '</span><span class="editor__panel-sub" id="layerCount">' + tpl('ed_elements_count', '{count} elements', { count: 0 }) + '</span></div><div class="editor__layers" id="layerList"></div>';
  sidebar.insertBefore(layersPanel, sidebar.firstChild);

  // ---- Init ----
  initGrid();
  applyViewBox();
  syncCanvasControls();

  snapshot();
  updateLayers();
  window.addEventListener('resize', updateSelection);
  // Sidebar growth / i18n reflow can resize the stage without a window resize;
  // the viewBox re-centers content in that case, so refresh the selection box.
  if (typeof ResizeObserver === 'function') new ResizeObserver(updateSelection).observe(stage);
})();

/**
 * 70015 Isometric Studio (等距画板)
 * Standalone browser-based isometric modeling, floorplan extrusion, and 3D reference tool.
 */
(function () {
  'use strict';

  // 常数与数学
  var COS_30 = Math.cos(Math.PI / 6);
  var SIN_30 = Math.sin(Math.PI / 6);
  var ISO_30_ANGLES = [-150, -90, -30, 30, 90, 150];
  var GAME_21_ANGLES = [-153.435, -90, -26.565, 26.565, 90, 153.435];

  // 状态
  var viewMode = 'iso'; // 'iso' | 'plan'
  var gridMode = 'true_iso_30'; // 'true_iso_30' | 'game_iso_2_1'
  var showGrid = true;
  var snapToGrid = true;
  var snapStep = 0.25; // 吸附精度：默认 0.25格 (支持薄墙、细家具与地砖)
  var currentTool = 'box'; // 'select' | 'box' | 'plane' | 'brush' | 'line' | 'rect_2d' | 'eraser' | 'eyedropper'
  var currentPlane = 'top'; // 'top' | 'left' | 'right'
  var currentColor = '#317fa8';
  var hasOutline = true;
  var outlineColor = '#1f2937';
  var tileSize = 40;

  var shapes = [];
  var history = [[]];
  var historyIndex = 0;

  var pan = { x: 0, y: 0 };
  var zoom = 1.0;

  // 交互临时状态
  var isDragging = false;
  var isPanning = false;
  var isSpacePressed = false;
  var panStart = { x: 0, y: 0 };
  var startMouse = { x: 0, y: 0 };
  var currentMouse = { x: 0, y: 0 };
  var hoverPoint = null;
  var hoverHitFace = 'top';

  // 3D 盒子两段式拉伸状态
  var boxExtrudeStage = 'idle'; // 'idle' | 'drawing_base' | 'pulling_height'
  var boxBase = null;
  var boxHeight = 1.5;

  // 画笔笔触
  var currentBrushStroke = [];

  // 画风：'smooth' 普通矢量 | 'pixel' 整个场景按 pixelSize 像素块渲染
  var renderStyle = 'smooth';
  var pixelSize = 4;

  // 选择 / 移动
  var selected = null; // the selected shape object (replaced, never mutated, when it moves)
  var drag = null;     // { orig, current, start, base } while dragging a selection

  // DOM 元素
  var canvas, ctx, container, statusText;
  var toolBtns, viewModeBtns, planeBtns;
  var undoBtn, redoBtn, extrudeBtn, sampleBtn, exportBtn, clearBtn;
  var gridBtn, snapBtn, snapStepSelect;
  var fillColorInput, strokeColorInput, hasOutlineInput;
  var shadeTopBox, shadeLeftBox, shadeRightBox;

  // i18n 辅助
  function tr(key) {
    if (typeof window.t === 'function') return window.t(key);
    return key;
  }

  // ==================== 核心数学函数 ====================

  function gridToScreen(gx, gy, gz, gMode, tSize) {
    gz = gz || 0;
    tSize = tSize || tileSize;
    gMode = gMode || gridMode;
    if (gMode === 'true_iso_30') {
      return {
        x: (gx - gy) * tSize * COS_30,
        y: (gx + gy) * tSize * SIN_30 - gz * tSize
      };
    } else {
      return {
        x: (gx - gy) * (tSize * 0.5),
        y: (gx + gy) * (tSize * 0.25) - gz * (tSize * 0.5)
      };
    }
  }

  function screenToGrid(sx, sy, gMode, tSize, gz) {
    gz = gz || 0;
    tSize = tSize || tileSize;
    gMode = gMode || gridMode;
    if (gMode === 'true_iso_30') {
      var adjustedY = sy + gz * tSize;
      var u = sx / (tSize * COS_30);
      var v = adjustedY / (tSize * SIN_30);
      return { gx: (u + v) / 2, gy: (v - u) / 2 };
    } else {
      var adjustedY2 = sy + gz * (tSize * 0.5);
      var u2 = sx / (tSize * 0.5);
      var v2 = adjustedY2 / (tSize * 0.25);
      return { gx: (u2 + v2) / 2, gy: (v2 - u2) / 2 };
    }
  }

  function snapToGridPoint(sx, sy, gMode, tSize, gz, step) {
    step = step || snapStep;
    var g = screenToGrid(sx, sy, gMode, tSize, gz);
    var snappedGx = Math.round(g.gx / step) * step;
    var snappedGy = Math.round(g.gy / step) * step;
    return {
      screen: gridToScreen(snappedGx, snappedGy, gz, gMode, tSize),
      grid: { gx: snappedGx, gy: snappedGy, gz: gz || 0 }
    };
  }

  function snapToIsometricAxis(startX, startY, currX, currY, gMode) {
    var dx = currX - startX;
    var dy = currY - startY;
    var length = Math.hypot(dx, dy);
    if (length < 3) return { point: { x: currX, y: currY }, angle: 0 };

    var currentAngleDeg = Math.atan2(dy, dx) * (180 / Math.PI);
    var targetAngles = gMode === 'true_iso_30' ? ISO_30_ANGLES : GAME_21_ANGLES;

    var closestAngle = targetAngles[0];
    var minDiff = Math.abs(currentAngleDeg - closestAngle);

    for (var i = 0; i < targetAngles.length; i++) {
      var angle = targetAngles[i];
      var diff = Math.abs(currentAngleDeg - angle);
      if (diff > 180) diff = 360 - diff;
      if (diff < minDiff) {
        minDiff = diff;
        closestAngle = angle;
      }
    }

    var rad = (closestAngle * Math.PI) / 180;
    return {
      point: { x: startX + length * Math.cos(rad), y: startY + length * Math.sin(rad) },
      angle: closestAngle
    };
  }

  function snapRayToGridStep(startX, startY, projX, projY, tSize, step) {
    var dx = projX - startX;
    var dy = projY - startY;
    var length = Math.hypot(dx, dy);
    if (length < 3) return { x: projX, y: projY };
    var unit = (tSize || tileSize) * (step || snapStep);
    var snapped = Math.round(length / unit) * unit;
    var scale = snapped / length;
    return { x: startX + dx * scale, y: startY + dy * scale };
  }

  // ==================== 颜色明暗推算 ====================

  function hexToRgb(hex) {
    var c = hex.replace('#', '');
    if (c.length === 3) c = c.split('').map(function (x) { return x + x; }).join('');
    var num = parseInt(c, 16);
    return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
  }

  function rgbToHex(r, g, b) {
    var toH = function (n) {
      var cl = Math.max(0, Math.min(255, Math.round(n)));
      return cl.toString(16).padStart(2, '0');
    };
    return '#' + toH(r) + toH(g) + toH(b);
  }

  function hexToHsl(hex) {
    var rgb = hexToRgb(hex);
    var r = rgb.r / 255, g = rgb.g / 255, b = rgb.b / 255;
    var max = Math.max(r, g, b), min = Math.min(r, g, b);
    var h = 0, s = 0, l = (max + min) / 2;
    if (max !== min) {
      var d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
  }

  function hslToHex(h, s, l) {
    h = ((h % 360) + 360) % 360;
    s = Math.max(0, Math.min(100, s)) / 100;
    l = Math.max(0, Math.min(100, l)) / 100;
    var c = (1 - Math.abs(2 * l - 1)) * s;
    var x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    var m = l - c / 2;
    var rNorm = 0, gNorm = 0, bNorm = 0;
    if (h >= 0 && h < 60) { rNorm = c; gNorm = x; }
    else if (h >= 60 && h < 120) { rNorm = x; gNorm = c; }
    else if (h >= 120 && h < 180) { gNorm = c; bNorm = x; }
    else if (h >= 180 && h < 240) { gNorm = x; bNorm = c; }
    else if (h >= 240 && h < 300) { rNorm = x; bNorm = c; }
    else { rNorm = c; bNorm = x; }
    return rgbToHex((rNorm + m) * 255, (gNorm + m) * 255, (bNorm + m) * 255);
  }

  function compute3Shades(baseColor) {
    var hsl = hexToHsl(baseColor);
    var topL = Math.min(95, hsl.l + 16);
    var topS = Math.max(10, hsl.s - 6);
    var leftL = Math.max(5, hsl.l - 4);
    var rightL = Math.max(5, hsl.l - 24);
    var rightS = Math.min(100, hsl.s + 8);
    return {
      topColor: hslToHex(hsl.h, topS, topL),
      leftColor: hslToHex(hsl.h, hsl.s, leftL),
      rightColor: hslToHex(hsl.h, rightS, rightL)
    };
  }

  // ==================== 顶点与图形辅助 ====================

  function getBoxVertices(box, gMode, tSize) {
    var gx = box.gx, gy = box.gy, gz = box.gz || 0, gw = box.gw, gd = box.gd, gh = box.gh;
    return [
      gridToScreen(gx, gy, gz, gMode, tSize),
      gridToScreen(gx + gw, gy, gz, gMode, tSize),
      gridToScreen(gx + gw, gy + gd, gz, gMode, tSize),
      gridToScreen(gx, gy + gd, gz, gMode, tSize),
      gridToScreen(gx, gy, gz + gh, gMode, tSize),
      gridToScreen(gx + gw, gy, gz + gh, gMode, tSize),
      gridToScreen(gx + gw, gy + gd, gz + gh, gMode, tSize),
      gridToScreen(gx, gy + gd, gz + gh, gMode, tSize)
    ];
  }

  function getPlaneVertices(plane, gMode, tSize) {
    var gx = plane.gx, gy = plane.gy, gz = plane.gz || 0, gw = plane.gw, gd = plane.gd;
    if (plane.planeType === 'top') {
      return [
        gridToScreen(gx, gy, gz, gMode, tSize),
        gridToScreen(gx + gw, gy, gz, gMode, tSize),
        gridToScreen(gx + gw, gy + gd, gz, gMode, tSize),
        gridToScreen(gx, gy + gd, gz, gMode, tSize)
      ];
    } else if (plane.planeType === 'left') {
      return [
        gridToScreen(gx, gy, gz, gMode, tSize),
        gridToScreen(gx, gy + gd, gz, gMode, tSize),
        gridToScreen(gx, gy + gd, gz + gw, gMode, tSize),
        gridToScreen(gx, gy, gz + gw, gMode, tSize)
      ];
    } else {
      return [
        gridToScreen(gx, gy, gz, gMode, tSize),
        gridToScreen(gx + gw, gy, gz, gMode, tSize),
        gridToScreen(gx + gw, gy, gz + gd, gMode, tSize),
        gridToScreen(gx, gy, gz + gd, gMode, tSize)
      ];
    }
  }

  function pointInPolygon(pt, poly) {
    var inside = false;
    for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      var xi = poly[i].x, yi = poly[i].y;
      var xj = poly[j].x, yj = poly[j].y;
      var intersect = ((yi > pt.y) !== (yj > pt.y)) && (pt.x < (xj - xi) * (pt.y - yi) / (yj - yi) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }

  function detectHoveredFace(world) {
    var boxes = shapes.filter(function (s) { return s.type === 'box'; });
    for (var i = boxes.length - 1; i >= 0; i--) {
      var v = getBoxVertices(boxes[i], gridMode, tileSize);
      if (pointInPolygon(world, [v[4], v[5], v[6], v[7]])) return 'top';
      if (pointInPolygon(world, [v[3], v[2], v[6], v[7]])) return 'left';
      if (pointInPolygon(world, [v[2], v[1], v[5], v[6]])) return 'right';
    }
    return currentPlane;
  }

  // ==================== 渲染系统 ====================

  // Canvas can't parse 'var(--x)'; resolve theme tokens to real colors (cache reset each render).
  var themeColors = {};
  function cssVar(name) {
    if (!themeColors[name]) {
      themeColors[name] = getComputedStyle(document.documentElement).getPropertyValue('--' + name).trim() || '#888888';
    }
    return themeColors[name];
  }

  function toWorld(sx, sy) {
    return { x: (sx - pan.x) / zoom, y: (sy - pan.y) / zoom };
  }

  function getEffectivePoint(world) {
    if (!snapToGrid) return world;
    if (viewMode === 'iso') {
      var sn = snapToGridPoint(world.x, world.y, gridMode, tileSize, 0, snapStep);
      return sn.screen;
    } else {
      var step2D = 32 * snapStep;
      return { x: Math.round(world.x / step2D) * step2D, y: Math.round(world.y / step2D) * step2D };
    }
  }

  function isSolid(s) { return s.type === 'box' || s.type === 'plane' || s.type === 'rect_2d' || s.type === 'beads'; }

  // ponytail: painter's sort by gx+gy, overlapping boxes of very different sizes can mis-order
  function isoDepth(s) {
    if (s.type === 'rect_2d') return (s.x + s.y) / 32;
    if (s.type === 'beads') {
      // Measured from the piece's middle, so a piece on a desk sorts after the desk.
      var e = beadsFrame(s).ext;
      return (s.gx + e[0] / 2) + (s.gy + e[1] / 2) + ((s.gz || 0) + e[2] / 2) * 0.5;
    }
    return (s.gx + s.gy) + (s.gz || 0) * 0.5;
  }

  // Solids depth-sorted first, then strokes/lines on top in drawing order
  // (strokes have no depth and would otherwise be hidden behind boxes).
  function isoDrawOrder(list) {
    return list.filter(isSolid).sort(function (a, b) { return isoDepth(a) - isoDepth(b); })
      .concat(list.filter(function (s) { return !isSolid(s); }));
  }

  function drawIsoScene(list) {
    isoDrawOrder(list).forEach(function (s) {
      if (s.type === 'box') drawBox(s);
      else if (s.type === 'plane') drawPlane(s);
      else if (s.type === 'brush_stroke') drawBrushStroke(s);
      else if (s.type === 'line') drawLine(s);
      else if (s.type === 'rect_2d') drawRect2DAsIso(s);
      else if (s.type === 'beads') drawBeads(s);
    });
  }

  function distToSegment(p, a, b) {
    var dx = b.x - a.x, dy = b.y - a.y;
    var len2 = dx * dx + dy * dy;
    var t = len2 ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2)) : 0;
    return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
  }

  function hitsPolyline(world, points, width) {
    var tol = Math.max(6 / zoom, (width || 2) / 2);
    for (var i = 1; i < points.length; i++) {
      if (distToSegment(world, points[i - 1], points[i]) <= tol) return true;
    }
    return false;
  }

  function hitsBoxIso(b, world) {
    var v = getBoxVertices(b);
    return pointInPolygon(world, [v[4], v[5], v[6], v[7]]) ||
      pointInPolygon(world, [v[3], v[2], v[6], v[7]]) ||
      pointInPolygon(world, [v[2], v[1], v[5], v[6]]);
  }

  function hitsRect(world, x, y, w, h) {
    return world.x >= x && world.x <= x + w && world.y >= y && world.y <= y + h;
  }

  function shapeHit(s, world) {
    if (s.type === 'line') return hitsPolyline(world, [s.start, s.end], s.width);
    if (s.type === 'brush_stroke') return viewMode === 'iso' && hitsPolyline(world, s.points, s.size);
    if (s.type === 'beads') {
      if (viewMode === 'iso') return pointInPolygon(world, beadsCorners(s, true));
      var e = beadsFrame(s).ext;
      return hitsRect(world, s.gx * 32 - 4, s.gy * 32 - 4, e[0] * 32 + 8, e[1] * 32 + 8);
    }
    if (viewMode === 'iso') {
      if (s.type === 'box') return hitsBoxIso(s, world);
      if (s.type === 'plane') return pointInPolygon(world, getPlaneVertices(s));
      if (s.type === 'rect_2d') return hitsBoxIso({ gx: s.x / 32, gy: s.y / 32, gz: 0, gw: s.width / 32, gd: s.height / 32, gh: s.extrudeHeight || 0.25 }, world);
      return false;
    }
    if (s.type === 'box' || (s.type === 'plane' && s.planeType === 'top')) return hitsRect(world, s.gx * 32, s.gy * 32, s.gw * 32, s.gd * 32);
    if (s.type === 'rect_2d') return hitsRect(world, s.x, s.y, s.width, s.height);
    return false;
  }

  // Topmost shape under the pointer, in the same order the current view draws them.
  function shapeAt(world) {
    var order = viewMode === 'iso' ? isoDrawOrder(shapes) : shapes;
    for (var i = order.length - 1; i >= 0; i--) {
      if (shapeHit(order[i], world)) return order[i];
    }
    return null;
  }

  // ==================== 像素画风：直接在像素格上绘制 ====================
  // Like a pixel editor rather than a filter: shapes are drawn straight onto a grid of
  // ps x ps blocks, never smooth-drawn and shrunk. A face fills every block whose center lies
  // inside it (one exact color, no blending); outlines and lines are 1-block Bresenham lines;
  // strokes drop L-shaped corner blocks, the way Aseprite's "Pixel-perfect" does, so diagonals
  // stay one block thin. Bead pieces look up, per block, which bead it falls on.
  // The block grid is tied to the world (pan rounded to whole blocks), so it doesn't shimmer
  // while panning. Drawn onto `target` in its own pixels (tx, ty = pan, z = zoom).

  function hexRgb(hex, fallback) {
    return /^#[0-9a-f]{6}$/i.test(hex || '') ? hexToRgb(hex) : hexToRgb(fallback);
  }

  // A block-space raster: plot / fill / line, all in whole blocks with exact colors.
  function makeRaster(bw, bh, k, px, py) {
    var img = new ImageData(bw, bh), d = img.data;
    function toBlock(p) { return { x: p.x * k + px, y: p.y * k + py }; } // world -> block coords
    function plot(x, y, c) {
      if (x < 0 || y < 0 || x >= bw || y >= bh) return;
      var i = (y * bw + x) * 4;
      d[i] = c.r; d[i + 1] = c.g; d[i + 2] = c.b; d[i + 3] = 255;
    }
    // Every block whose center is inside the polygon (world coords).
    function fill(poly, c) {
      var pts = poly.map(toBlock);
      var x0 = Math.max(0, Math.floor(Math.min.apply(null, pts.map(function (p) { return p.x; }))));
      var x1 = Math.min(bw - 1, Math.ceil(Math.max.apply(null, pts.map(function (p) { return p.x; }))));
      var y0 = Math.max(0, Math.floor(Math.min.apply(null, pts.map(function (p) { return p.y; }))));
      var y1 = Math.min(bh - 1, Math.ceil(Math.max.apply(null, pts.map(function (p) { return p.y; }))));
      for (var y = y0; y <= y1; y++) {
        for (var x = x0; x <= x1; x++) if (pointInPolygon({ x: x + 0.5, y: y + 0.5 }, pts)) plot(x, y, c);
      }
    }
    // Blocks a straight line passes through, 8-connected (Bresenham).
    function lineBlocks(a, b, out) {
      var p = toBlock(a), q = toBlock(b);
      var x = Math.floor(p.x), y = Math.floor(p.y), x1 = Math.floor(q.x), y1 = Math.floor(q.y);
      var dx = Math.abs(x1 - x), dy = -Math.abs(y1 - y), sx = x < x1 ? 1 : -1, sy = y < y1 ? 1 : -1, err = dx + dy;
      for (;;) {
        var last = out[out.length - 1];
        if (!last || last.x !== x || last.y !== y) out.push({ x: x, y: y });
        if (x === x1 && y === y1) break;
        var e2 = 2 * err;
        if (e2 >= dy) { err += dy; x += sx; }
        if (e2 <= dx) { err += dx; y += sy; }
      }
      return out;
    }
    // Aseprite-style pixel-perfect: drop a block that only turns an L-shaped corner.
    function pixelPerfect(pts) {
      var out = [];
      for (var i = 0; i < pts.length; i++) {
        var a = out[out.length - 1], b = pts[i], c = pts[i + 1];
        if (a && c && (a.x === b.x || a.y === b.y) && (c.x === b.x || c.y === b.y) && a.x !== c.x && a.y !== c.y) continue;
        out.push(b);
      }
      return out;
    }
    function polyline(points, closed, c) {
      var blocks = [];
      for (var i = 1; i < points.length; i++) lineBlocks(points[i - 1], points[i], blocks);
      if (closed && points.length > 2) lineBlocks(points[points.length - 1], points[0], blocks);
      pixelPerfect(blocks).forEach(function (p) { plot(p.x, p.y, c); });
    }
    return { img: img, k: k, px: px, py: py, plot: plot, fill: fill, polyline: polyline, toBlock: toBlock };
  }

  var OUTLINE_FALLBACK = '#1f2937';

  function rasterBox(R, b) {
    var v = getBoxVertices(b);
    var faces = [
      { pts: [v[3], v[2], v[6], v[7]], color: b.leftColor },
      { pts: [v[2], v[1], v[5], v[6]], color: b.rightColor },
      { pts: [v[4], v[5], v[6], v[7]], color: b.topColor }
    ];
    faces.forEach(function (f) { R.fill(f.pts, hexRgb(f.color, '#888888')); });
    if (b.hasOutline) {
      var oc = hexRgb(b.outlineColor, OUTLINE_FALLBACK);
      faces.forEach(function (f) { R.polyline(f.pts, true, oc); });
    }
  }

  // Bead piece: for each block, solve which bead (column, row) its center falls on, first on the
  // back layer (darker side) then on the front face, so the piece keeps a one-block edge.
  function rasterBeads(R, b) {
    var f = beadsFrame(b), s = f.s, th = s * 0.4;
    var P = function (v) { return gridToScreen(v[0], v[1], v[2]); };
    var colV = P(f.col), rowV = P(f.row), nV = P(f.n), base = gridToScreen(b.gx, b.gy, b.gz || 0), o = P(f.o);
    var det = colV.x * rowV.y - colV.y * rowV.x;
    if (Math.abs(det) < 1e-9) return;
    var cells;
    try { cells = decodeCells(b.cells); } catch (e) { return; }
    var colors = b.colors.map(function (c) { return hexRgb(c, '#888888'); });
    var sides = b.colors.map(function (c) { return hexRgb(shadeHex(c, 0.7), '#555555'); });
    [[0, sides], [th, colors]].forEach(function (layer) {
      var lift = layer[0], pal = layer[1];
      var ox = base.x + o.x + nV.x * lift, oy = base.y + o.y + nV.y * lift;
      var corners = [{ x: ox, y: oy }, { x: ox + colV.x * f.u, y: oy + colV.y * f.u },
        { x: ox + colV.x * f.u + rowV.x * f.v, y: oy + colV.y * f.u + rowV.y * f.v }, { x: ox + rowV.x * f.v, y: oy + rowV.y * f.v }];
      var bc = corners.map(R.toBlock);
      var x0 = Math.floor(Math.min.apply(null, bc.map(function (p) { return p.x; })));
      var x1 = Math.ceil(Math.max.apply(null, bc.map(function (p) { return p.x; })));
      var y0 = Math.floor(Math.min.apply(null, bc.map(function (p) { return p.y; })));
      var y1 = Math.ceil(Math.max.apply(null, bc.map(function (p) { return p.y; })));
      for (var y = y0; y <= y1; y++) {
        for (var x = x0; x <= x1; x++) {
          // block center back to world, then into the piece's (column, row) grid units
          var wx = (x + 0.5 - R.px) / R.k - ox, wy = (y + 0.5 - R.py) / R.k - oy;
          var a = (wx * rowV.y - wy * rowV.x) / det, c = (colV.x * wy - colV.y * wx) / det;
          var col = Math.floor(a / s), row = Math.floor(c / s);
          if (col < 0 || row < 0 || col >= b.bw || row >= b.bh) continue;
          var v = cells[row * b.bw + col];
          if (v >= 0 && pal[v]) R.plot(x, y, pal[v]);
        }
      }
    });
  }

  var pixelBuf = null;
  function drawPixelArt(target, outW, outH, tx, ty, z, ps, list) {
    var bw = Math.ceil(outW / ps) + 1, bh = Math.ceil(outH / ps) + 1;
    var px = Math.round(tx / ps), py = Math.round(ty / ps);
    var R = makeRaster(bw, bh, z / ps, px, py);
    isoDrawOrder(list).forEach(function (s) {
      if (s.type === 'box') rasterBox(R, s);
      else if (s.type === 'rect_2d') {
        var sh = compute3Shades(s.fillColor || currentColor);
        rasterBox(R, { gx: s.x / 32, gy: s.y / 32, gz: 0, gw: s.width / 32, gd: s.height / 32, gh: s.extrudeHeight || 0.25,
          topColor: sh.topColor, leftColor: sh.leftColor, rightColor: sh.rightColor, hasOutline: true, outlineColor: s.outlineColor || outlineColor });
      } else if (s.type === 'plane') {
        var pv = getPlaneVertices(s);
        R.fill(pv, hexRgb(s.color, '#888888'));
        if (s.hasOutline) R.polyline(pv, true, hexRgb(s.outlineColor, OUTLINE_FALLBACK));
      } else if (s.type === 'line') R.polyline([s.start, s.end], false, hexRgb(s.color, OUTLINE_FALLBACK));
      else if (s.type === 'brush_stroke') R.polyline(s.points, false, hexRgb(s.color, OUTLINE_FALLBACK));
      else if (s.type === 'beads') rasterBeads(R, s);
    });
    pixelBuf = pixelBuf || document.createElement('canvas');
    pixelBuf.width = bw;
    pixelBuf.height = bh;
    pixelBuf.getContext('2d').putImageData(R.img, 0, 0);
    target.save();
    target.setTransform(1, 0, 0, 1, 0, 0);
    target.imageSmoothingEnabled = false;
    target.drawImage(pixelBuf, tx - px * ps, ty - py * ps, bw * ps, bh * ps);
    target.restore();
  }

  function render() {
    if (!canvas || !ctx) return;
    themeColors = {};
    var w = canvas.width;
    var h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    ctx.save();
    ctx.translate(pan.x, pan.y);
    ctx.scale(zoom, zoom);

    // 网格与底板
    if (showGrid) {
      if (viewMode === 'iso') drawIsoGrid();
      else drawPlanGrid();
    }

    if (viewMode === 'iso') {
      var tempBox = null;
      // 实时 3D 盒子高度拉伸
      if (boxExtrudeStage === 'pulling_height' && boxBase) {
        var shades = compute3Shades(currentColor);
        tempBox = {
          type: 'box',
          gx: boxBase.gx,
          gy: boxBase.gy,
          gz: boxBase.gz,
          gw: boxBase.gw,
          gd: boxBase.gd,
          gh: boxHeight,
          topColor: shades.topColor,
          leftColor: shades.leftColor,
          rightColor: shades.rightColor,
          hasOutline: true,
          outlineColor: outlineColor
        };
      }
      var paintScene = function () {
        drawIsoScene(shapes);
        if (tempBox) drawBox(tempBox);
      };
      if (renderStyle === 'pixel') drawPixelArt(ctx, w, h, pan.x, pan.y, zoom, pixelSize, tempBox ? shapes.concat([tempBox]) : shapes);
      else paintScene();
      if (tempBox) drawHeightIndicator(tempBox);
    } else {
      // 2D 平面模式：将所有 3D 盒子、平面与 2D 图元渲染为标准的 2D 俯视平面图
      for (var j = 0; j < shapes.length; j++) {
        var shape = shapes[j];
        if (shape.type === 'box') {
          drawBoxIn2DPlan(shape);
        } else if (shape.type === 'plane') {
          drawPlaneIn2DPlan(shape);
        } else if (shape.type === 'rect_2d') {
          drawRect2D(shape);
        } else if (shape.type === 'line') {
          drawLine(shape);
        } else if (shape.type === 'beads') {
          drawBeadsIn2DPlan(shape);
        }
      }
    }

    if (selected && shapes.indexOf(selected) < 0) selected = null; // undone or erased
    if (selected) drawSelection(selected);
    updateSelUi();

    // 拖拽预览
    if (isDragging && !isSpacePressed && !isPanning && boxExtrudeStage !== 'pulling_height') {
      drawPreview();
    }

    // 磁吸或 3D 表面贴面光标
    if (!isPanning && !isSpacePressed && hoverPoint) {
      if (currentTool === 'brush' && viewMode === 'iso') {
        drawSurfaceBrushCursor(hoverPoint, hoverHitFace);
      } else if (snapToGrid) {
        drawSnapCursor(hoverPoint);
      }
    }

    ctx.restore();
    updateStatusBar();
  }

  // ==================== 2D 平面图与 3D 等距投影转换 ====================

  /**
   * 将 3D 盒子在 2D 平面视图中渲染为俯视平面图 (带厚度、墙体/家具辨识)
   */
  function drawBoxIn2DPlan(b) {
    var rx = b.gx * 32;
    var ry = b.gy * 32;
    var rw = b.gw * 32;
    var rh = b.gd * 32;
    var isWall = (b.gh >= 2.0); // 高度大于 2.0 判定为墙体

    ctx.save();
    ctx.beginPath();
    ctx.rect(rx, ry, rw, rh);
    ctx.fillStyle = isWall ? (b.leftColor || b.baseColor || '#64748b') : (b.topColor || b.baseColor || '#317fa8');
    ctx.fill();

    ctx.lineWidth = isWall ? 2 : 1;
    ctx.strokeStyle = isWall ? '#111827' : (b.outlineColor || '#374151');
    ctx.stroke();

    // 如果是墙体，加上精细剖切斜线
    if (isWall && (rw > 12 && rh > 12)) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(rx, ry); ctx.lineTo(rx + rw, ry + rh);
      ctx.stroke();
    }

    // 标注尺寸信息
    if (rw > 36 && rh > 24) {
      ctx.font = '9px monospace';
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.fillText(b.gw.toFixed(1) + '×' + b.gd.toFixed(1), rx + 4, ry + 14);
    }
    ctx.restore();
  }

  function drawPlaneIn2DPlan(p) {
    if (p.planeType === 'top') {
      var rx = p.gx * 32;
      var ry = p.gy * 32;
      var rw = p.gw * 32;
      var rh = p.gd * 32;
      ctx.save();
      ctx.beginPath();
      ctx.rect(rx, ry, rw, rh);
      ctx.fillStyle = p.color || 'rgba(49, 127, 168, 0.3)';
      ctx.fill();
      ctx.strokeStyle = p.outlineColor || '#374151';
      ctx.stroke();
      ctx.restore();
    }
  }

  function drawRect2DAsIso(r) {
    var gx = r.x / 32;
    var gy = r.y / 32;
    var gw = r.width / 32;
    var gd = r.height / 32;
    var sh = compute3Shades(r.fillColor || currentColor);
    var temp = {
      gx: gx, gy: gy, gz: 0, gw: gw, gd: gd, gh: r.extrudeHeight || 0.25,
      topColor: sh.topColor, leftColor: sh.leftColor, rightColor: sh.rightColor,
      hasOutline: true, outlineColor: r.outlineColor || outlineColor
    };
    drawBox(temp);
  }

  // ==================== 基础绘制函数 ====================

  function drawIsoGrid() {
    ctx.save();
    ctx.strokeStyle = cssVar('border');
    ctx.lineWidth = 0.5 / zoom;
    var range = 35;
    for (var gx = -range; gx <= range; gx += (snapStep >= 0.5 ? 1 : 0.5)) {
      var isMajor = Math.abs(gx % 5) < 0.01;
      var p1 = gridToScreen(gx, -range, 0);
      var p2 = gridToScreen(gx, range, 0);
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.strokeStyle = isMajor ? cssVar('text-muted') : cssVar('border');
      ctx.lineWidth = (isMajor ? 0.8 : 0.4) / zoom;
      ctx.stroke();
    }
    for (var gy = -range; gy <= range; gy += (snapStep >= 0.5 ? 1 : 0.5)) {
      var isMajor2 = Math.abs(gy % 5) < 0.01;
      var q1 = gridToScreen(-range, gy, 0);
      var q2 = gridToScreen(range, gy, 0);
      ctx.beginPath();
      ctx.moveTo(q1.x, q1.y);
      ctx.lineTo(q2.x, q2.y);
      ctx.strokeStyle = isMajor2 ? cssVar('text-muted') : cssVar('border');
      ctx.lineWidth = (isMajor2 ? 0.8 : 0.4) / zoom;
      ctx.stroke();
    }

    // 原点
    var o = gridToScreen(0, 0, 0);
    var xEnd = gridToScreen(2, 0, 0);
    ctx.strokeStyle = cssVar('primary');
    ctx.lineWidth = 1.5 / zoom;
    ctx.beginPath();
    ctx.moveTo(o.x, o.y);
    ctx.lineTo(xEnd.x, xEnd.y);
    ctx.stroke();

    var yEnd = gridToScreen(0, 2, 0);
    ctx.beginPath();
    ctx.moveTo(o.x, o.y);
    ctx.lineTo(yEnd.x, yEnd.y);
    ctx.stroke();

    var zEnd = gridToScreen(0, 0, 2);
    ctx.strokeStyle = cssVar('text');
    ctx.beginPath();
    ctx.moveTo(o.x, o.y);
    ctx.lineTo(zEnd.x, zEnd.y);
    ctx.stroke();

    ctx.font = Math.max(9, Math.round(10 / zoom)) + 'px sans-serif';
    ctx.fillStyle = cssVar('text-muted');
    ctx.fillText('+X', xEnd.x + 4 / zoom, xEnd.y + 4 / zoom);
    ctx.fillText('+Y', yEnd.x - 16 / zoom, yEnd.y + 4 / zoom);
    ctx.fillStyle = cssVar('text');
    ctx.fillText('+Z (H)', zEnd.x - 14 / zoom, zEnd.y - 4 / zoom);

    ctx.restore();
  }

  function drawPlanGrid() {
    ctx.save();
    ctx.strokeStyle = cssVar('border');
    ctx.lineWidth = 0.5 / zoom;
    var range = 40 * 32;
    var step = 32 * snapStep;
    for (var x = -range; x <= range; x += step) {
      var isMajor = Math.abs((x / 32) % 5) < 0.01;
      ctx.beginPath();
      ctx.moveTo(x, -range);
      ctx.lineTo(x, range);
      ctx.strokeStyle = isMajor ? cssVar('text-muted') : cssVar('border');
      ctx.lineWidth = (isMajor ? 0.8 : 0.4) / zoom;
      ctx.stroke();
    }
    for (var y = -range; y <= range; y += step) {
      var isMajor2 = Math.abs((y / 32) % 5) < 0.01;
      ctx.beginPath();
      ctx.moveTo(-range, y);
      ctx.lineTo(range, y);
      ctx.strokeStyle = isMajor2 ? cssVar('text-muted') : cssVar('border');
      ctx.lineWidth = (isMajor2 ? 0.8 : 0.4) / zoom;
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawBox(b) {
    var v = getBoxVertices(b);
    ctx.save();
    ctx.lineJoin = 'round';
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = b.hasOutline ? (b.outlineColor || cssVar('border')) : 'transparent';

    // Left
    ctx.beginPath();
    ctx.moveTo(v[3].x, v[3].y); ctx.lineTo(v[2].x, v[2].y); ctx.lineTo(v[6].x, v[6].y); ctx.lineTo(v[7].x, v[7].y);
    ctx.closePath();
    ctx.fillStyle = b.leftColor;
    ctx.fill();
    if (b.hasOutline) ctx.stroke();

    // Right
    ctx.beginPath();
    ctx.moveTo(v[2].x, v[2].y); ctx.lineTo(v[1].x, v[1].y); ctx.lineTo(v[5].x, v[5].y); ctx.lineTo(v[6].x, v[6].y);
    ctx.closePath();
    ctx.fillStyle = b.rightColor;
    ctx.fill();
    if (b.hasOutline) ctx.stroke();

    // Top
    ctx.beginPath();
    ctx.moveTo(v[4].x, v[4].y); ctx.lineTo(v[5].x, v[5].y); ctx.lineTo(v[6].x, v[6].y); ctx.lineTo(v[7].x, v[7].y);
    ctx.closePath();
    ctx.fillStyle = b.topColor;
    ctx.fill();
    if (b.hasOutline) ctx.stroke();
    ctx.restore();
  }

  function drawPlane(p) {
    var pts = getPlaneVertices(p);
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    pts.forEach(function (pt) { ctx.lineTo(pt.x, pt.y); });
    ctx.closePath();
    ctx.fillStyle = p.color;
    ctx.fill();
    if (p.hasOutline) {
      ctx.lineWidth = 1.2;
      ctx.strokeStyle = p.outlineColor || cssVar('border');
      ctx.stroke();
    }
    ctx.restore();
  }

  // ==================== 拼豆作品 (bead works) ====================
  // A bead piece is one shape: { type: 'beads', name, gx, gy, gz, orient, bw, bh, per, colors, cells }.
  // colors: '#rrggbb' list; cells: base64 Int16 (index into colors, -1 = no bead), bw x bh beads;
  // per: beads per grid cell. orient 'top' lies on the floor (columns +gx, rows +gy);
  // 'left' stands in a plane of constant gx, 'right' in one of constant gy, both facing the
  // viewer so the art reads as drawn, top row highest.

  function decodeCells(b64) {
    var s = atob(b64), bytes = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) bytes[i] = s.charCodeAt(i);
    return new Int16Array(bytes.buffer);
  }

  function encodeCells(cells) {
    var bytes = new Uint8Array(cells.buffer, cells.byteOffset, cells.byteLength), s = '';
    for (var i = 0; i < bytes.length; i += 8192) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
    return btoa(s);
  }

  // Origin offset, column / row / normal directions (grid units) and size of a piece.
  function beadsFrame(b) {
    var s = 1 / b.per, u = b.bw * s, v = b.bh * s;
    if (b.orient === 'top') return { o: [0, 0, 0], col: [1, 0, 0], row: [0, 1, 0], n: [0, 0, 1], s: s, u: u, v: v, ext: [u, v, 0] };
    // Columns toward -gy on a constant-gx wall, so they run left to right on screen.
    if (b.orient === 'left') return { o: [0, u, v], col: [0, -1, 0], row: [0, 0, -1], n: [1, 0, 0], s: s, u: u, v: v, ext: [0, u, v] };
    return { o: [0, 0, v], col: [1, 0, 0], row: [0, 0, -1], n: [0, 1, 0], s: s, u: u, v: v, ext: [u, 0, v] };
  }

  function add3(a, b, k) { return [a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k]; }

  // Screen-space corners of the piece's face (relative to its anchor unless abs).
  function beadsCorners(b, abs) {
    var f = beadsFrame(b), base = abs ? [b.gx, b.gy, b.gz || 0] : [0, 0, 0];
    var o = add3(base, f.o, 1);
    return [o, add3(o, f.col, f.u), add3(add3(o, f.col, f.u), f.row, f.v), add3(o, f.row, f.v)]
      .map(function (p) { return gridToScreen(p[0], p[1], p[2]); });
  }

  function shadeHex(hex, k) {
    var c = hexToRgb(hex);
    return rgbToHex(Math.round(c.r * k), Math.round(c.g * k), Math.round(c.b * k));
  }

  // The piece drawn once into an offscreen canvas: each bead a short cylinder (darker body,
  // colored face, hole), nearer beads over farther ones. Projection is linear, so the image
  // stays valid when the piece moves; it is redrawn only when the grid or the piece changes.
  function beadsImage(b) {
    var key = gridMode + '|' + tileSize + '|' + b.orient + '|' + b.per + '|' + b.cells.length + '|' + b.colors.join();
    if (b._img && b._img.key === key) return b._img;
    var f = beadsFrame(b), s = f.s, r = s * 0.5, th = s * 0.4;
    var P = function (v) { return gridToScreen(v[0], v[1], v[2]); };
    var colV = P(f.col), rowV = P(f.row), nV = P(f.n);
    var pts = beadsCorners(b, false);
    pts = pts.concat(pts.map(function (p) { return { x: p.x + nV.x * th, y: p.y + nV.y * th }; }));
    var minX = Math.min.apply(null, pts.map(function (p) { return p.x; })) - 2;
    var minY = Math.min.apply(null, pts.map(function (p) { return p.y; })) - 2;
    var maxX = Math.max.apply(null, pts.map(function (p) { return p.x; })) + 2;
    var maxY = Math.max.apply(null, pts.map(function (p) { return p.y; })) + 2;
    // 2x for sharp zooming, less for huge pieces (canvas area kept under ~16 M px).
    var scale = Math.min(2, Math.sqrt(16e6 / Math.max(1, (maxX - minX) * (maxY - minY))));
    var c = document.createElement('canvas');
    c.width = Math.ceil((maxX - minX) * scale);
    c.height = Math.ceil((maxY - minY) * scale);
    var g = c.getContext('2d');
    var cells = decodeCells(b.cells), list = [];
    for (var row = 0; row < b.bh; row++) {
      for (var col = 0; col < b.bw; col++) {
        var v = cells[row * b.bw + col];
        if (v < 0 || !b.colors[v]) continue;
        var ctr = add3(add3(f.o, f.col, (col + 0.5) * s), f.row, (row + 0.5) * s);
        list.push({ ctr: ctr, color: b.colors[v], depth: ctr[0] + ctr[1] + ctr[2] * 0.5 });
      }
    }
    list.sort(function (a, bb) { return a.depth - bb.depth; });
    function disc(center, lift, rad, fill) {
      var p = P(center);
      g.setTransform(colV.x * rad * scale, colV.y * rad * scale, rowV.x * rad * scale, rowV.y * rad * scale,
        (p.x + nV.x * lift - minX) * scale, (p.y + nV.y * lift - minY) * scale);
      g.beginPath();
      g.arc(0, 0, 1, 0, Math.PI * 2);
      g.fillStyle = fill;
      g.fill();
    }
    list.forEach(function (bd) {
      var side = shadeHex(bd.color, 0.7);
      disc(bd.ctr, 0, r, side);
      disc(bd.ctr, th / 2, r, side);
      disc(bd.ctr, th, r, bd.color);
      disc(bd.ctr, th, r * 0.36, shadeHex(bd.color, 0.55));
    });
    b._img = { key: key, canvas: c, minX: minX, minY: minY, scale: scale };
    return b._img;
  }

  function drawBeads(b) {
    var im;
    try { im = beadsImage(b); } catch (e) { return; } // damaged saved data: skip the piece
    var o = gridToScreen(b.gx, b.gy, b.gz || 0);
    ctx.save();
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(im.canvas, o.x + im.minX, o.y + im.minY, im.canvas.width / im.scale, im.canvas.height / im.scale);
    ctx.restore();
  }

  // Plan view: a lying piece shows its art from above; a standing one is a thin strip.
  function drawBeadsIn2DPlan(b) {
    var f = beadsFrame(b), x = b.gx * 32, y = b.gy * 32;
    ctx.save();
    if (b.orient === 'top') {
      if (!b._plan || b._plan.cells !== b.cells) {
        var pc = document.createElement('canvas');
        pc.width = b.bw;
        pc.height = b.bh;
        var pg = pc.getContext('2d'), cells = decodeCells(b.cells);
        for (var i = 0; i < cells.length; i++) {
          if (cells[i] < 0) continue;
          pg.fillStyle = b.colors[cells[i]];
          pg.fillRect(i % b.bw, Math.floor(i / b.bw), 1, 1);
        }
        b._plan = { cells: b.cells, canvas: pc };
      }
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(b._plan.canvas, x, y, f.u * 32, f.v * 32);
      ctx.strokeStyle = cssVar('border');
      ctx.strokeRect(x, y, f.u * 32, f.v * 32);
    } else {
      ctx.fillStyle = cssVar('primary');
      if (b.orient === 'left') ctx.fillRect(x - 2, y, 4, f.u * 32);
      else ctx.fillRect(x, y - 2, f.u * 32, 4);
    }
    ctx.restore();
  }

  // ==================== 选择与移动 ====================

  // Convex hull (monotone chain) of screen points, for the selection outline.
  function hull(points) {
    var p = points.slice().sort(function (a, b) { return a.x - b.x || a.y - b.y; });
    if (p.length < 3) return p;
    function cross(o, a, b) { return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x); }
    var lower = [], upper = [], i;
    for (i = 0; i < p.length; i++) {
      while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p[i]) <= 0) lower.pop();
      lower.push(p[i]);
    }
    for (i = p.length - 1; i >= 0; i--) {
      while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p[i]) <= 0) upper.pop();
      upper.push(p[i]);
    }
    return lower.slice(0, -1).concat(upper.slice(0, -1));
  }

  function outlinePoints(s) {
    if (viewMode === 'plan') {
      var e = s.type === 'beads' ? beadsFrame(s).ext : [s.gw || 0, s.gd || 0];
      if (s.type === 'rect_2d') return [{ x: s.x, y: s.y }, { x: s.x + s.width, y: s.y + s.height }];
      if (s.type === 'line') return [s.start, s.end];
      if (s.gx === undefined) return [];
      return [{ x: s.gx * 32 - 3, y: s.gy * 32 - 3 }, { x: (s.gx + e[0]) * 32 + 3, y: s.gy * 32 - 3 },
        { x: (s.gx + e[0]) * 32 + 3, y: (s.gy + e[1]) * 32 + 3 }, { x: s.gx * 32 - 3, y: (s.gy + e[1]) * 32 + 3 }];
    }
    if (s.type === 'box') return getBoxVertices(s);
    if (s.type === 'plane') return getPlaneVertices(s);
    if (s.type === 'beads') return beadsCorners(s, true);
    if (s.type === 'rect_2d') return getBoxVertices({ gx: s.x / 32, gy: s.y / 32, gz: 0, gw: s.width / 32, gd: s.height / 32, gh: s.extrudeHeight || 0.25 });
    if (s.type === 'line') return [s.start, s.end];
    if (s.type === 'brush_stroke') return s.points;
    return [];
  }

  function drawSelection(s) {
    var pts = hull(outlinePoints(s));
    if (pts.length < 2) return;
    ctx.save();
    ctx.strokeStyle = cssVar('primary');
    ctx.lineWidth = 2 / zoom;
    ctx.setLineDash([6 / zoom, 4 / zoom]);
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    pts.forEach(function (p) { ctx.lineTo(p.x, p.y); });
    ctx.closePath();
    ctx.stroke();
    ctx.restore();
  }

  // A moved copy of a shape (grid shapes by grid units, drawn lines by the matching screen offset).
  function movedShape(s, dx, dy) {
    if (s.type === 'rect_2d') return Object.assign({}, s, { x: s.x + dx * 32, y: s.y + dy * 32 });
    if (s.type === 'line' || s.type === 'brush_stroke') {
      var d = gridToScreen(dx, dy, 0);
      var off = function (p) { return { x: p.x + d.x, y: p.y + d.y }; };
      return s.type === 'line'
        ? Object.assign({}, s, { start: off(s.start), end: off(s.end) })
        : Object.assign({}, s, { points: s.points.map(off) });
    }
    return Object.assign({}, s, { gx: s.gx + dx, gy: s.gy + dy });
  }

  // Swap one shape for its edited copy as a single undo step, keeping it selected.
  function replaceSelected(next) {
    var prev = selected;
    selected = next;
    pushState(shapes.map(function (s) { return s === prev ? next : s; }));
  }

  var selGroup, selTurnBtn;
  function updateSelUi() {
    if (!selGroup) return;
    [].forEach.call(selGroup.querySelectorAll('button'), function (b) {
      var usable = !!selected;
      if (b === selTurnBtn) usable = !!selected && selected.type === 'beads';
      else if (b.id !== 'selDelete') usable = !!selected && selected.gz !== undefined;
      b.disabled = !usable;
    });
  }

  function selRaise(dir) {
    if (!selected || selected.gz === undefined) return;
    replaceSelected(Object.assign({}, selected, { gz: Math.max(0, (selected.gz || 0) + dir * snapStep) }));
  }

  function selTurn() {
    if (!selected || selected.type !== 'beads') return;
    var order = ['top', 'right', 'left'];
    var next = Object.assign({}, selected, { orient: order[(order.indexOf(selected.orient) + 1) % order.length] });
    delete next._img;
    // Keep the piece's middle exactly where it was (the footprint changes shape when it turns;
    // rounding here would make a full turn drift).
    var was = beadsFrame(selected).ext, now = beadsFrame(next).ext;
    next.gx = selected.gx + was[0] / 2 - now[0] / 2;
    next.gy = selected.gy + was[1] / 2 - now[1] / 2;
    next.gz = restHeight(next, shapes);
    replaceSelected(next);
  }

  function selDelete() {
    if (!selected) return;
    var gone = selected;
    selected = null;
    pushState(shapes.filter(function (s) { return s !== gone; }));
  }

  // Boxes a piece can rest on: at least one cell each way (floors, desks, shelves), not thin
  // walls or a monitor's edge.
  function isSurface(s) { return s.type === 'box' && s.gw >= 1 && s.gd >= 1; }

  // Height a piece rests at: the top of the highest surface under its middle, else the floor.
  function restHeight(b, others) {
    var f = beadsFrame(b), cx = b.gx + f.ext[0] / 2, cy = b.gy + f.ext[1] / 2, z = 0;
    others.forEach(function (s) {
      if (!isSurface(s) || s === b) return;
      if (cx >= s.gx && cx <= s.gx + s.gw && cy >= s.gy && cy <= s.gy + s.gd) z = Math.max(z, (s.gz || 0) + s.gh);
    });
    return z;
  }

  function drawBrushStroke(st) {
    if (st.points.length < 2) return;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(st.points[0].x, st.points[0].y);
    for (var i = 1; i < st.points.length; i++) {
      ctx.lineTo(st.points[i].x, st.points[i].y);
    }
    ctx.lineWidth = st.size || 3;
    ctx.strokeStyle = st.color;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
    ctx.restore();
  }

  function drawLine(l) {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(l.start.x, l.start.y);
    ctx.lineTo(l.end.x, l.end.y);
    ctx.lineWidth = l.width || 2;
    ctx.strokeStyle = l.color;
    ctx.lineCap = 'round';
    ctx.stroke();
    ctx.restore();
  }

  function drawRect2D(r) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(r.x, r.y, r.width, r.height);
    ctx.fillStyle = r.fillColor;
    ctx.fill();
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = r.outlineColor || cssVar('border');
    ctx.stroke();
    ctx.restore();
  }

  function drawHeightIndicator(b) {
    var v = getBoxVertices(b);
    ctx.save();
    ctx.strokeStyle = cssVar('text');
    ctx.setLineDash([2, 2]);
    ctx.lineWidth = 1.2 / zoom;
    ctx.beginPath();
    ctx.moveTo(v[2].x, v[2].y);
    ctx.lineTo(v[6].x, v[6].y);
    ctx.stroke();

    var labelX = v[6].x + 12 / zoom;
    var labelY = (v[2].y + v[6].y) / 2;
    var tag = 'H: ' + b.gh.toFixed(2) + ' (Click)';
    ctx.font = 'bold ' + Math.max(9, Math.round(10.5 / zoom)) + 'px monospace';
    ctx.fillStyle = cssVar('surface');
    ctx.fillRect(labelX - 2 / zoom, labelY - 8 / zoom, 110 / zoom, 16 / zoom);
    ctx.fillStyle = cssVar('text');
    ctx.fillText(tag, labelX, labelY + 4 / zoom);
    ctx.restore();
  }

  function drawSurfaceBrushCursor(pt, face) {
    ctx.save();
    ctx.strokeStyle = cssVar('primary');
    ctx.lineWidth = 1.5 / zoom;
    var r = 8 / zoom;
    ctx.beginPath();
    if (face === 'top') {
      ctx.moveTo(pt.x, pt.y - r * 0.58);
      ctx.lineTo(pt.x + r, pt.y);
      ctx.lineTo(pt.x, pt.y + r * 0.58);
      ctx.lineTo(pt.x - r, pt.y);
    } else if (face === 'left') {
      ctx.moveTo(pt.x, pt.y);
      ctx.lineTo(pt.x - r * 0.86, pt.y + r * 0.5);
      ctx.lineTo(pt.x - r * 0.86, pt.y - r * 0.8);
      ctx.lineTo(pt.x, pt.y - r * 1.3);
    } else {
      ctx.moveTo(pt.x, pt.y);
      ctx.lineTo(pt.x + r * 0.86, pt.y + r * 0.5);
      ctx.lineTo(pt.x + r * 0.86, pt.y - r * 0.8);
      ctx.lineTo(pt.x, pt.y - r * 1.3);
    }
    ctx.closePath();
    ctx.fillStyle = 'rgba(49, 127, 168, 0.2)';
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  function drawSnapCursor(pt) {
    ctx.save();
    ctx.strokeStyle = cssVar('primary');
    ctx.fillStyle = cssVar('primary');
    ctx.lineWidth = 1 / zoom;
    var size = 3 / zoom;
    ctx.beginPath();
    ctx.moveTo(pt.x - size, pt.y); ctx.lineTo(pt.x + size, pt.y);
    ctx.moveTo(pt.x, pt.y - size); ctx.lineTo(pt.x, pt.y + size);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 1.5 / zoom, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawPreview() {
    ctx.save();
    if (viewMode === 'iso') {
      if (currentTool === 'box') {
        var gStart = screenToGrid(startMouse.x, startMouse.y);
        var gCurr = screenToGrid(currentMouse.x, currentMouse.y);
        var step = snapToGrid ? snapStep : 0.1;
        var gx = Math.min(Math.round(gStart.gx / step) * step, Math.round(gCurr.gx / step) * step);
        var gy = Math.min(Math.round(gStart.gy / step) * step, Math.round(gCurr.gy / step) * step);
        var gw = Math.max(step, Math.abs(Math.round((gCurr.gx - gStart.gx) / step) * step) || step);
        var gd = Math.max(step, Math.abs(Math.round((gCurr.gy - gStart.gy) / step) * step) || step);

        var pts = [
          gridToScreen(gx, gy, 0),
          gridToScreen(gx + gw, gy, 0),
          gridToScreen(gx + gw, gy + gd, 0),
          gridToScreen(gx, gy + gd, 0)
        ];
        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        pts.forEach(function (p) { ctx.lineTo(p.x, p.y); });
        ctx.closePath();
        ctx.fillStyle = 'rgba(49, 127, 168, 0.25)';
        ctx.fill();
        ctx.strokeStyle = cssVar('primary');
        ctx.lineWidth = 1.5;
        ctx.stroke();
      } else if (currentTool === 'plane') {
        var gS = screenToGrid(startMouse.x, startMouse.y);
        var gC = screenToGrid(currentMouse.x, currentMouse.y);
        var stp = snapToGrid ? snapStep : 0.1;
        var gpx = Math.min(Math.round(gS.gx / stp) * stp, Math.round(gC.gx / stp) * stp);
        var gpy = Math.min(Math.round(gS.gy / stp) * stp, Math.round(gC.gy / stp) * stp);
        var gpw = Math.max(stp, Math.abs(Math.round((gC.gx - gS.gx) / stp) * stp) || stp);
        var gpd = Math.max(stp, Math.abs(Math.round((gC.gy - gS.gy) / stp) * stp) || stp);

        var previewPlane = {
          type: 'plane',
          planeType: currentPlane,
          gx: gpx, gy: gpy, gz: 0, gw: gpw, gd: gpd,
          color: currentColor,
          hasOutline: true,
          outlineColor: outlineColor
        };
        ctx.globalAlpha = 0.8;
        drawPlane(previewPlane);
      } else if (currentTool === 'brush') {
        if (currentBrushStroke.length >= 2) {
          ctx.beginPath();
          ctx.moveTo(currentBrushStroke[0].x, currentBrushStroke[0].y);
          for (var i = 1; i < currentBrushStroke.length; i++) {
            ctx.lineTo(currentBrushStroke[i].x, currentBrushStroke[i].y);
          }
          ctx.lineWidth = 3;
          ctx.strokeStyle = currentColor;
          ctx.lineCap = 'round';
          ctx.stroke();
        }
      } else if (currentTool === 'line') {
        var snapped = snapToIsometricAxis(startMouse.x, startMouse.y, currentMouse.x, currentMouse.y, gridMode);
        var endP = snapToGrid ? snapRayToGridStep(startMouse.x, startMouse.y, snapped.point.x, snapped.point.y) : snapped.point;
        ctx.beginPath();
        ctx.moveTo(startMouse.x, startMouse.y);
        ctx.lineTo(endP.x, endP.y);
        ctx.strokeStyle = currentColor;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    } else {
      if (currentTool === 'box' || currentTool === 'plane') {
        ctx.fillStyle = currentColor;
        ctx.strokeStyle = cssVar('primary');
        var rx = Math.min(startMouse.x, currentMouse.x);
        var ry = Math.min(startMouse.y, currentMouse.y);
        var rw = Math.abs(currentMouse.x - startMouse.x);
        var rh = Math.abs(currentMouse.y - startMouse.y);
        ctx.fillRect(rx, ry, rw, rh);
        ctx.strokeRect(rx, ry, rw, rh);
      }
    }
    ctx.restore();
  }

  // ==================== 状态与交互 ====================

  function pushState(newShapes) {
    shapes = newShapes;
    history = history.slice(0, historyIndex + 1);
    history.push(shapes.slice());
    historyIndex++;
    updateUndoRedoBtns();
    render();
    scheduleSceneSave();
  }

  function undo() {
    if (historyIndex > 0) {
      historyIndex--;
      shapes = history[historyIndex].slice();
      updateUndoRedoBtns();
      render();
      scheduleSceneSave();
    }
  }

  function redo() {
    if (historyIndex < history.length - 1) {
      historyIndex++;
      shapes = history[historyIndex].slice();
      updateUndoRedoBtns();
      render();
      scheduleSceneSave();
    }
  }

  function updateUndoRedoBtns() {
    if (undoBtn) undoBtn.disabled = historyIndex <= 0;
    if (redoBtn) redoBtn.disabled = historyIndex >= history.length - 1;
  }

  function updateShadeBoxes() {
    var sh = compute3Shades(currentColor);
    if (shadeTopBox) { shadeTopBox.style.backgroundColor = sh.topColor; shadeTopBox.title = 'Top: ' + sh.topColor; }
    if (shadeLeftBox) { shadeLeftBox.style.backgroundColor = sh.leftColor; shadeLeftBox.title = 'Left: ' + sh.leftColor; }
    if (shadeRightBox) { shadeRightBox.style.backgroundColor = sh.rightColor; shadeRightBox.title = 'Right: ' + sh.rightColor; }
  }

  function updateStatusBar() {
    if (!statusText) return;
    var modeStr = viewMode === 'iso' ? tr('iso_view_3d') : tr('iso_view_2d');
    statusText.textContent = modeStr +
      ' | ' + tr('iso_precision') + ': ' + snapStep +
      ' | Zoom: ' + Math.round(zoom * 100) + '%' +
      ' | ' + shapes.length + ' ' + (shapes.length === 1 ? 'object' : 'objects');
  }

  // ==================== 事件监听 ====================

  function handleMouseDown(e) {
    var rect = canvas.getBoundingClientRect();
    var sx = e.clientX - rect.left;
    var sy = e.clientY - rect.top;
    var rawWorld = toWorld(sx, sy);
    var world = getEffectivePoint(rawWorld);

    if (e.button === 1 || isSpacePressed || e.button === 2) {
      if (e.button === 2 && boxExtrudeStage === 'pulling_height') {
        boxExtrudeStage = 'idle';
        boxBase = null;
        render();
        return;
      }
      isPanning = true;
      panStart = { x: sx - pan.x, y: sy - pan.y };
      return;
    }

    if (boxExtrudeStage === 'pulling_height' && boxBase) {
      var sh = compute3Shades(currentColor);
      var newBox = {
        type: 'box',
        gx: boxBase.gx,
        gy: boxBase.gy,
        gz: boxBase.gz,
        gw: boxBase.gw,
        gd: boxBase.gd,
        gh: Math.max(snapStep, boxHeight),
        baseColor: currentColor,
        topColor: sh.topColor,
        leftColor: sh.leftColor,
        rightColor: sh.rightColor,
        hasOutline: hasOutline,
        outlineColor: outlineColor
      };
      pushState(shapes.concat([newBox]));
      boxExtrudeStage = 'idle';
      boxBase = null;
      render();
      return;
    }

    // e.altKey, not a tracked keydown flag: Alt+Tab never delivers the keyup.
    if (currentTool === 'eyedropper' || e.altKey) {
      var picked = shapeAt(rawWorld);
      var pickedColor = picked && (picked.baseColor || picked.color || picked.fillColor);
      if (pickedColor) {
        currentColor = pickedColor;
        if (fillColorInput) fillColorInput.value = currentColor;
        updateShadeBoxes();
        render();
      }
      return;
    }

    if (currentTool === 'select') {
      selected = shapeAt(rawWorld);
      if (selected) drag = { orig: selected, current: selected, start: rawWorld, base: shapes };
      render();
      return;
    }

    if (currentTool === 'eraser') {
      var hit = shapeAt(rawWorld);
      if (hit) pushState(shapes.filter(function (s) { return s !== hit; }));
      return;
    }

    // Plan view only draws footprints: box → wall, plane → floor tile.
    if (viewMode === 'plan' && currentTool !== 'box' && currentTool !== 'plane') return;

    if (currentTool === 'brush') {
      isDragging = true;
      currentBrushStroke = [world];
      return;
    }

    if (currentTool === 'box' && viewMode === 'iso') {
      isDragging = true;
      boxExtrudeStage = 'drawing_base';
      startMouse = world;
      currentMouse = world;
      return;
    }

    isDragging = true;
    startMouse = world;
    currentMouse = world;
  }

  function handleMouseMove(e) {
    var rect = canvas.getBoundingClientRect();
    var sx = e.clientX - rect.left;
    var sy = e.clientY - rect.top;

    if (isPanning) {
      pan = { x: sx - panStart.x, y: sy - panStart.y };
      render();
      return;
    }

    var rawWorld = toWorld(sx, sy);

    if (drag) {
      // Move along the floor by whole snap steps; bead pieces settle onto whatever is under them.
      var dx, dy;
      if (viewMode === 'iso') {
        var g0 = screenToGrid(drag.start.x, drag.start.y), g1 = screenToGrid(rawWorld.x, rawWorld.y);
        dx = g1.gx - g0.gx;
        dy = g1.gy - g0.gy;
      } else {
        dx = (rawWorld.x - drag.start.x) / 32;
        dy = (rawWorld.y - drag.start.y) / 32;
      }
      var st = snapToGrid ? snapStep : 0.05;
      dx = Math.round(dx / st) * st;
      dy = Math.round(dy / st) * st;
      var moved = movedShape(drag.orig, dx, dy);
      if (moved.type === 'beads') moved.gz = restHeight(moved, drag.base);
      shapes = drag.base.map(function (s) { return s === drag.orig ? moved : s; });
      drag.current = moved;
      selected = moved;
      render();
      return;
    }

    var effPoint = getEffectivePoint(rawWorld);
    hoverPoint = effPoint;

    if (viewMode === 'iso') {
      hoverHitFace = detectHoveredFace(rawWorld);
    }

    if (boxExtrudeStage === 'pulling_height' && boxBase) {
      var baseCenterScreen = gridToScreen(boxBase.gx + boxBase.gw / 2, boxBase.gy + boxBase.gd / 2, boxBase.gz);
      var deltaY = baseCenterScreen.y - rawWorld.y;
      var calcH = deltaY / (tileSize * (gridMode === 'true_iso_30' ? 1.0 : 0.5));
      if (snapToGrid) calcH = Math.round(calcH / snapStep) * snapStep;
      boxHeight = Math.max(snapStep, calcH);
      render();
      return;
    }

    if (isDragging) {
      if (currentTool === 'brush') {
        currentBrushStroke.push(effPoint);
      } else {
        currentMouse = effPoint;
      }
    }
    render();
  }

  function handleMouseUp() {
    if (isPanning) { isPanning = false; return; }
    if (drag) {
      // One undo step for the whole move (the array before the drag is still in history).
      var movedIt = drag.current !== drag.orig;
      drag = null;
      if (movedIt) pushState(shapes);
      return;
    }
    if (!isDragging) return;
    isDragging = false;

    var dist = Math.hypot(currentMouse.x - startMouse.x, currentMouse.y - startMouse.y);

    if (viewMode === 'iso') {
      if (currentTool === 'box' && boxExtrudeStage === 'drawing_base') {
        var gS = screenToGrid(startMouse.x, startMouse.y);
        var gC = screenToGrid(currentMouse.x, currentMouse.y);
        var st = snapToGrid ? snapStep : 0.1;
        var gx = Math.min(Math.round(gS.gx / st) * st, Math.round(gC.gx / st) * st);
        var gy = Math.min(Math.round(gS.gy / st) * st, Math.round(gC.gy / st) * st);
        var gw = Math.max(st, Math.abs(Math.round((gC.gx - gS.gx) / st) * st) || st);
        var gd = Math.max(st, Math.abs(Math.round((gC.gy - gS.gy) / st) * st) || st);

        boxBase = { gx: gx, gy: gy, gz: 0, gw: gw, gd: gd };
        boxHeight = 1.5;
        boxExtrudeStage = 'pulling_height';
        render();
        return;
      }

      if (currentTool === 'plane') {
        var gS2 = screenToGrid(startMouse.x, startMouse.y);
        var gC2 = screenToGrid(currentMouse.x, currentMouse.y);
        var st2 = snapToGrid ? snapStep : 0.1;
        var px = Math.min(Math.round(gS2.gx / st2) * st2, Math.round(gC2.gx / st2) * st2);
        var py = Math.min(Math.round(gS2.gy / st2) * st2, Math.round(gC2.gy / st2) * st2);
        var pw = Math.max(st2, Math.abs(Math.round((gC2.gx - gS2.gx) / st2) * st2) || st2);
        var pd = Math.max(st2, Math.abs(Math.round((gC2.gy - gS2.gy) / st2) * st2) || st2);

        var newPlane = {
          type: 'plane',
          planeType: currentPlane,
          gx: px, gy: py, gz: 0, gw: pw, gd: pd,
          color: currentColor,
          hasOutline: hasOutline,
          outlineColor: outlineColor
        };
        pushState(shapes.concat([newPlane]));
        return;
      }

      if (currentTool === 'brush') {
        if (currentBrushStroke.length >= 2) {
          var newStroke = {
            type: 'brush_stroke',
            points: currentBrushStroke.slice(),
            color: currentColor,
            size: 3,
            targetFace: hoverHitFace
          };
          pushState(shapes.concat([newStroke]));
        }
        currentBrushStroke = [];
        return;
      }

      if (currentTool === 'line') {
        var snapped = snapToIsometricAxis(startMouse.x, startMouse.y, currentMouse.x, currentMouse.y, gridMode);
        var endP = snapToGrid ? snapRayToGridStep(startMouse.x, startMouse.y, snapped.point.x, snapped.point.y, tileSize, snapStep) : snapped.point;
        if (dist > 3) {
          var newLine = {
            type: 'line',
            start: startMouse,
            end: endP,
            color: currentColor,
            width: 2
          };
          pushState(shapes.concat([newLine]));
        }
        return;
      }
    } else {
      // 2D 平面模式：直接创建 3D 兼容的矩形
      if (dist <= 3) return; // a stray click shouldn't drop a wall
      var rx = Math.min(startMouse.x, currentMouse.x);
      var ry = Math.min(startMouse.y, currentMouse.y);
      var rw = Math.max(16, Math.abs(currentMouse.x - startMouse.x));
      var rh = Math.max(16, Math.abs(currentMouse.y - startMouse.y));

      var gx2 = rx / 32;
      var gy2 = ry / 32;
      var gw2 = rw / 32;
      var gd2 = rh / 32;
      var sh2 = compute3Shades(currentColor);

      if (currentTool === 'plane') {
        pushState(shapes.concat([{
          type: 'plane', planeType: 'top',
          gx: gx2, gy: gy2, gz: 0, gw: gw2, gd: gd2,
          color: currentColor, hasOutline: hasOutline, outlineColor: outlineColor
        }]));
        return;
      }

      var newBoxFromPlan = {
        type: 'box',
        gx: gx2, gy: gy2, gz: 0, gw: gw2, gd: gd2, gh: 2.5,
        baseColor: currentColor, topColor: sh2.topColor, leftColor: sh2.leftColor, rightColor: sh2.rightColor,
        hasOutline: hasOutline, outlineColor: outlineColor
      };
      pushState(shapes.concat([newBoxFromPlan]));
    }
  }

  function handleWheel(e) {
    e.preventDefault();
    var rect = canvas.getBoundingClientRect();
    var mouseX = e.clientX - rect.left;
    var mouseY = e.clientY - rect.top;
    var zoomFactor = e.deltaY < 0 ? 1.15 : 0.87;
    var newZoom = Math.max(0.12, Math.min(4.5, zoom * zoomFactor));
    if (renderStyle === 'pixel') {
      // Whole zoom steps only; always move at least one step per wheel notch.
      var snapped = snapZoom(newZoom);
      if (snapped === zoom) snapped = snapZoom(zoom + (e.deltaY < 0 ? 1 : -1) * zoomStep());
      newZoom = snapped;
    }
    zoomAround(newZoom, mouseX, mouseY);
    render();
  }

  function loadSampleRoom() {
    var shFloor = compute3Shades('#e5e7eb');
    var shWallL = compute3Shades('#94a3b8');
    var shWallR = compute3Shades('#64748b');
    var shDesk = compute3Shades('#317fa8');
    var shScreen = compute3Shades('#111827');
    var shChair = compute3Shades('#53c9df');

    var sampleShapes = [
      // 地板 (7x7, 高 0.25)
      { type: 'box', gx: 0, gy: 0, gz: 0, gw: 7, gd: 7, gh: 0.25, baseColor: '#e5e7eb', topColor: shFloor.topColor, leftColor: shFloor.leftColor, rightColor: shFloor.rightColor, hasOutline: true, outlineColor: '#1f2937' },
      // 后左薄墙 (厚度 0.25)
      { type: 'box', gx: 0, gy: 0, gz: 0.25, gw: 0.25, gd: 7, gh: 3.2, baseColor: '#94a3b8', topColor: shWallL.topColor, leftColor: shWallL.leftColor, rightColor: shWallL.rightColor, hasOutline: true, outlineColor: '#1f2937' },
      // 后右薄墙 (厚度 0.25)
      { type: 'box', gx: 0.25, gy: 0, gz: 0.25, gw: 6.75, gd: 0.25, gh: 3.2, baseColor: '#64748b', topColor: shWallR.topColor, leftColor: shWallR.leftColor, rightColor: shWallR.rightColor, hasOutline: true, outlineColor: '#1f2937' },
      // 书桌 (长 3.0, 宽 1.5, 高 1.25)
      { type: 'box', gx: 1.0, gy: 1.0, gz: 0.25, gw: 3.0, gd: 1.5, gh: 1.25, baseColor: '#317fa8', topColor: shDesk.topColor, leftColor: shDesk.leftColor, rightColor: shDesk.rightColor, hasOutline: true, outlineColor: '#1f2937' },
      // 电脑屏幕 (厚度 0.25, 高 0.9)
      { type: 'box', gx: 1.75, gy: 1.25, gz: 1.5, gw: 1.5, gd: 0.25, gh: 0.9, baseColor: '#111827', topColor: shScreen.topColor, leftColor: shScreen.leftColor, rightColor: shScreen.rightColor, hasOutline: true, outlineColor: '#1f2937' },
      // 办公椅 (长 1.25, 宽 1.25, 高 0.8)
      { type: 'box', gx: 2.0, gy: 3.25, gz: 0.25, gw: 1.25, gd: 1.25, gh: 0.8, baseColor: '#53c9df', topColor: shChair.topColor, leftColor: shChair.leftColor, rightColor: shChair.rightColor, hasOutline: true, outlineColor: '#1f2937' }
    ];

    viewMode = 'iso';
    if (viewModeBtns) {
      viewModeBtns.forEach(function (b) {
        b.classList.toggle('is-active', b.dataset.view === 'iso');
      });
    }
    pushState(sampleShapes);
    pan = { x: canvas.width / 2, y: canvas.height / 2 };
    zoom = snapZoom(1.0);
    render();
  }

  function extrude2DPlan() {
    var boxes = shapes.filter(function (s) { return s.type === 'box'; });
    if (boxes.length === 0) {
      alert(tr('iso_no_boxes'));
      return;
    }
    viewMode = 'iso';
    if (viewModeBtns) {
      viewModeBtns.forEach(function (b) {
        b.classList.toggle('is-active', b.dataset.view === 'iso');
      });
    }
    render();
  }

  function exportImage(format) {
    if (shapes.length === 0) return;
    var offCanvas = document.createElement('canvas');
    offCanvas.width = canvas.width * 2;
    offCanvas.height = canvas.height * 2;
    var offCtx = offCanvas.getContext('2d');
    offCtx.scale(2, 2);
    offCtx.translate(pan.x, pan.y);
    offCtx.scale(zoom, zoom);

    var list = shapes;
    if (format === 'lineart') {
      list = shapes.map(function (s) {
        var c = Object.assign({}, s, { hasOutline: true, outlineColor: '#000000' });
        if (s.type === 'box') { c.topColor = c.leftColor = c.rightColor = '#ffffff'; }
        else if (s.type === 'plane') c.color = '#ffffff';
        else if (s.type === 'rect_2d') c.fillColor = '#ffffff';
        else c.color = '#000000';
        return c;
      });
    }
    // Reuse the on-screen draw routines against the export context. Pixel style exports the
    // same pixel look at the export's 2x size (line art stays smooth: it's a reference drawing).
    if (renderStyle === 'pixel' && format !== 'lineart') {
      offCtx.setTransform(1, 0, 0, 1, 0, 0);
      drawPixelArt(offCtx, offCanvas.width, offCanvas.height, pan.x * 2, pan.y * 2, zoom * 2, pixelSize * 2, list);
    } else {
      var screenCtx = ctx;
      ctx = offCtx;
      try { drawIsoScene(list); } finally { ctx = screenCtx; }
    }

    var link = document.createElement('a');
    link.download = '70015_isometric_' + (format === 'lineart' ? 'lineart_' : '') + Date.now() + '.png';
    link.href = offCanvas.toDataURL('image/png');
    link.click();
  }

  // ==================== 拼豆作品放入场景 / 场景保存 ====================
  // The Bead Pattern page saves its works in this site's localStorage, so they can be read
  // here directly. A placed piece copies its colors and cells, so the scene keeps working even
  // if the work is later deleted.

  var WORKS_KEY = '70015-beads-works', SCENE_KEY = '70015-iso-scene';

  function readStore(key) {
    try { return JSON.parse(localStorage.getItem(key)); } catch (e) { return null; }
  }

  function readWorks() {
    var w = readStore(WORKS_KEY);
    return Array.isArray(w) ? w : [];
  }

  function workToPiece(w, orient, per) {
    var C = window.BeadsCore;
    var pal = w.paletteId === 'custom' && w.custom
      ? C.parsePaletteText(w.custom.text)
      : C.parsePalette(window.BEAD_PALETTES[w.paletteId] || window.BEAD_PALETTES.mard);
    var cells = decodeCells(w.pattern), out = new Int16Array(cells.length), slot = {}, colors = [];
    for (var i = 0; i < cells.length; i++) {
      var v = cells[i];
      if (v < 0 || !pal[v]) { out[i] = -1; continue; }
      if (!(v in slot)) { slot[v] = colors.length; colors.push(pal[v].hex); }
      out[i] = slot[v];
    }
    return { type: 'beads', name: w.name || '', gx: 0, gy: 0, gz: 0, orient: orient, bw: w.w, bh: w.h, per: per, colors: colors, cells: encodeCells(out) };
  }

  // Put a piece in the middle of the view, on a snap step, resting on whatever is below it.
  // When the piece wouldn't fit on any surface there but the scene has one (a floor), use the
  // middle of the largest surface instead, so a new piece never hangs outside the room.
  function placePiece(piece) {
    var f = beadsFrame(piece), c = toWorld(canvas.width / 2, canvas.height / 2);
    var g = viewMode === 'iso' ? screenToGrid(c.x, c.y) : { gx: c.x / 32, gy: c.y / 32 };
    var surfaces = shapes.filter(isSurface);
    var x0 = g.gx - f.ext[0] / 2, y0 = g.gy - f.ext[1] / 2;
    var fits = surfaces.some(function (s) {
      return x0 >= s.gx && y0 >= s.gy && x0 + f.ext[0] <= s.gx + s.gw && y0 + f.ext[1] <= s.gy + s.gd;
    });
    if (!fits && surfaces.length) {
      var big = surfaces.reduce(function (a, s) { return s.gw * s.gd > a.gw * a.gd ? s : a; });
      g = { gx: big.gx + big.gw / 2, gy: big.gy + big.gd / 2 };
    }
    piece.gx = Math.round((g.gx - f.ext[0] / 2) / snapStep) * snapStep;
    piece.gy = Math.round((g.gy - f.ext[1] / 2) / snapStep) * snapStep;
    piece.gz = restHeight(piece, shapes);
    // The first bead work in a scene turns the scene to pixel style, to match the beads;
    // switching back to smooth afterwards is kept.
    var firstBeads = !shapes.some(function (s) { return s.type === 'beads'; });
    selected = piece;
    pushState(shapes.concat([piece]));
    if (firstBeads && renderStyle !== 'pixel') setStyle('pixel');
    setTool('select');
  }

  var beadsDialog, beadsOrient = 'right';

  function openBeadsDialog() {
    var list = document.getElementById('beadsList'), works = readWorks();
    document.getElementById('beadsEmpty').hidden = works.length > 0;
    list.innerHTML = '';
    works.forEach(function (w) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'iso-beads-dialog__work';
      btn.innerHTML = '<img alt=""><span></span><small></small>';
      btn.firstChild.src = w.thumb || '';
      btn.children[1].textContent = w.name && w.name !== 'beads' ? w.name : tr('bd_untitled');
      btn.children[2].textContent = w.w + ' × ' + w.h;
      btn.addEventListener('click', function () {
        var per = parseInt(document.getElementById('beadsPer').value, 10) || 8;
        try { placePiece(workToPiece(w, beadsOrient, per)); } catch (e) { console.error(e); }
        beadsDialog.close();
      });
      list.appendChild(btn);
    });
    if (beadsDialog.showModal) beadsDialog.showModal();
    else beadsDialog.setAttribute('open', '');
  }

  // Scene autosave: shapes as JSON, minus the cached images (keys starting with "_").
  // ponytail: one scene in localStorage; add named scenes if people want several.
  var sceneTimer;
  function scheduleSceneSave() {
    clearTimeout(sceneTimer);
    sceneTimer = setTimeout(function () {
      try {
        localStorage.setItem(SCENE_KEY, JSON.stringify(shapes, function (k, v) { return k.charAt(0) === '_' ? undefined : v; }));
      } catch (e) { /* storage full or blocked: the scene just isn't kept */ }
    }, 500);
  }

  var styleBtns, pixelSizeSelect;
  // Pixel style draws in the 2:1 isometric pixel artists use (2 blocks across, 1 down, so every
  // edge steps evenly); smooth style keeps true 30°. In pixel style the zoom snaps to levels
  // where one grid cell is a whole number of pixel blocks (6 x 3 at 4 px), so steps never vary.
  function zoomStep() { return pixelSize / (tileSize * 0.25); }
  function snapZoom(z) {
    if (renderStyle !== 'pixel') return z;
    var st = zoomStep();
    return Math.max(st, Math.min(Math.floor(4.5 / st) * st, Math.round(z / st) * st));
  }
  // Change zoom keeping the screen point (cx, cy) fixed.
  function zoomAround(newZoom, cx, cy) {
    pan.x = cx - (cx - pan.x) * (newZoom / zoom);
    pan.y = cy - (cy - pan.y) * (newZoom / zoom);
    zoom = newZoom;
  }

  function setStyle(style, size) {
    renderStyle = style === 'pixel' ? 'pixel' : 'smooth';
    if (size) pixelSize = size;
    gridMode = renderStyle === 'pixel' ? 'game_iso_2_1' : 'true_iso_30';
    if (canvas) zoomAround(snapZoom(zoom), canvas.width / 2, canvas.height / 2);
    if (styleBtns) styleBtns.forEach(function (b) { b.classList.toggle('is-active', b.dataset.style === renderStyle); });
    if (pixelSizeSelect) {
      pixelSizeSelect.value = String(pixelSize);
      pixelSizeSelect.disabled = renderStyle !== 'pixel';
    }
    try { localStorage.setItem('70015-iso-style', JSON.stringify({ style: renderStyle, size: pixelSize })); } catch (e) { /* not kept */ }
    render();
  }

  function setTool(tool) {
    currentTool = tool;
    if (tool !== 'select') selected = null;
    if (toolBtns) toolBtns.forEach(function (b) { b.classList.toggle('is-active', b.dataset.tool === tool); });
    render();
  }

  // ==================== 初始化 ====================

  function init() {
    canvas = document.getElementById('isoCanvas');
    if (!canvas) return;
    ctx = canvas.getContext('2d');
    container = document.getElementById('canvasContainer');
    statusText = document.getElementById('statusText');

    function resize() {
      if (container) {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
        if (pan.x === 0 && pan.y === 0) {
          pan = { x: canvas.width / 2, y: canvas.height / 2 };
        }
        render();
      }
    }
    window.addEventListener('resize', resize);
    resize();

    // 绑定画布事件
    // Pointer events so touch/pen work too (canvas has touch-action: none).
    canvas.addEventListener('pointerdown', handleMouseDown);
    canvas.addEventListener('pointermove', handleMouseMove);
    window.addEventListener('pointerup', handleMouseUp);
    canvas.addEventListener('wheel', handleWheel, { passive: false });
    canvas.addEventListener('contextmenu', function (e) { e.preventDefault(); });

    // 工具按钮
    toolBtns = document.querySelectorAll('[data-tool]');
    toolBtns.forEach(function (btn) {
      btn.addEventListener('click', function () { setTool(btn.dataset.tool); });
    });

    // Selection toolbar
    selGroup = document.getElementById('selGroup');
    selTurnBtn = document.getElementById('selTurn');
    document.getElementById('selUp').addEventListener('click', function () { selRaise(1); });
    document.getElementById('selDown').addEventListener('click', function () { selRaise(-1); });
    selTurnBtn.addEventListener('click', selTurn);
    document.getElementById('selDelete').addEventListener('click', selDelete);

    // 画风 (style), remembered between visits
    styleBtns = document.querySelectorAll('[data-style]');
    pixelSizeSelect = document.getElementById('pixelSizeSelect');
    styleBtns.forEach(function (btn) {
      btn.addEventListener('click', function () { setStyle(btn.dataset.style); });
    });
    pixelSizeSelect.addEventListener('change', function () { setStyle(renderStyle, parseInt(pixelSizeSelect.value, 10) || 4); });
    var savedStyle = readStore('70015-iso-style');
    if (savedStyle) {
      renderStyle = savedStyle.style === 'pixel' ? 'pixel' : 'smooth';
      if ([2, 3, 4, 6, 8].indexOf(savedStyle.size) >= 0) pixelSize = savedStyle.size;
    }
    styleBtns.forEach(function (b) { b.classList.toggle('is-active', b.dataset.style === renderStyle); });
    pixelSizeSelect.value = String(pixelSize);
    pixelSizeSelect.disabled = renderStyle !== 'pixel';
    gridMode = renderStyle === 'pixel' ? 'game_iso_2_1' : 'true_iso_30';
    zoom = snapZoom(zoom);

    // Bead works
    beadsDialog = document.getElementById('beadsDialog');
    document.getElementById('addBeadsBtn').addEventListener('click', openBeadsDialog);
    document.getElementById('beadsOrient').addEventListener('click', function (e) {
      var btn = e.target.closest('[data-value]');
      if (!btn) return;
      beadsOrient = btn.dataset.value;
      [].forEach.call(this.querySelectorAll('[data-value]'), function (b) { b.classList.toggle('is-active', b === btn); });
    });

    // 视图切换按钮
    viewModeBtns = document.querySelectorAll('[data-view]');
    viewModeBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        viewMode = btn.dataset.view;
        viewModeBtns.forEach(function (b) { b.classList.toggle('is-active', b === btn); });
        render();
      });
    });

    // 面切换按钮 (Top / Left / Right)
    planeBtns = document.querySelectorAll('[data-plane]');
    planeBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        currentPlane = btn.dataset.plane;
        planeBtns.forEach(function (b) { b.classList.toggle('is-active', b === btn); });
        render();
      });
    });

    // 吸附精度选择器
    snapStepSelect = document.getElementById('snapStepSelect');
    if (snapStepSelect) {
      snapStepSelect.addEventListener('change', function (e) {
        snapStep = parseFloat(e.target.value) || 0.25;
        render();
      });
    }

    // 拾色器
    fillColorInput = document.getElementById('fillColor');
    if (fillColorInput) {
      fillColorInput.addEventListener('input', function (e) {
        currentColor = e.target.value;
        updateShadeBoxes();
        render();
      });
    }

    strokeColorInput = document.getElementById('strokeColor');
    if (strokeColorInput) {
      strokeColorInput.addEventListener('input', function (e) {
        outlineColor = e.target.value;
        render();
      });
    }

    hasOutlineInput = document.getElementById('hasOutline');
    if (hasOutlineInput) {
      hasOutlineInput.addEventListener('change', function (e) {
        hasOutline = e.target.checked;
        render();
      });
    }

    shadeTopBox = document.getElementById('shadeTop');
    shadeLeftBox = document.getElementById('shadeLeft');
    shadeRightBox = document.getElementById('shadeRight');
    if (shadeTopBox) {
      shadeTopBox.addEventListener('click', function () {
        currentColor = compute3Shades(currentColor).topColor;
        if (fillColorInput) fillColorInput.value = currentColor;
        updateShadeBoxes();
      });
    }
    if (shadeLeftBox) {
      shadeLeftBox.addEventListener('click', function () {
        currentColor = compute3Shades(currentColor).leftColor;
        if (fillColorInput) fillColorInput.value = currentColor;
        updateShadeBoxes();
      });
    }
    if (shadeRightBox) {
      shadeRightBox.addEventListener('click', function () {
        currentColor = compute3Shades(currentColor).rightColor;
        if (fillColorInput) fillColorInput.value = currentColor;
        updateShadeBoxes();
      });
    }

    // 动作按钮
    undoBtn = document.getElementById('undoBtn');
    redoBtn = document.getElementById('redoBtn');
    if (undoBtn) undoBtn.addEventListener('click', undo);
    if (redoBtn) redoBtn.addEventListener('click', redo);

    gridBtn = document.getElementById('gridBtn');
    if (gridBtn) {
      gridBtn.addEventListener('click', function () {
        showGrid = !showGrid;
        gridBtn.classList.toggle('is-active', showGrid);
        render();
      });
    }

    snapBtn = document.getElementById('snapBtn');
    if (snapBtn) {
      snapBtn.addEventListener('click', function () {
        snapToGrid = !snapToGrid;
        snapBtn.classList.toggle('is-active', snapToGrid);
        render();
      });
    }

    extrudeBtn = document.getElementById('extrudeBtn');
    if (extrudeBtn) extrudeBtn.addEventListener('click', extrude2DPlan);

    sampleBtn = document.getElementById('sampleBtn');
    if (sampleBtn) sampleBtn.addEventListener('click', loadSampleRoom);

    exportBtn = document.getElementById('exportBtn');
    if (exportBtn) exportBtn.addEventListener('click', function () { exportImage('png'); });

    var lineartBtn = document.getElementById('lineartBtn');
    if (lineartBtn) lineartBtn.addEventListener('click', function () { exportImage('lineart'); });

    clearBtn = document.getElementById('clearBtn');
    if (clearBtn) {
      clearBtn.addEventListener('click', function () {
        if (confirm(tr('iso_confirm_clear'))) {
          pushState([]);
        }
      });
    }

    // 快捷键
    var canvasHovered = false;
    canvas.addEventListener('mouseenter', function () { canvasHovered = true; });
    canvas.addEventListener('mouseleave', function () { canvasHovered = false; });
    // Keyup is lost if the window loses focus mid-press.
    window.addEventListener('blur', function () { isSpacePressed = false; });

    var TOOL_KEYS = { v: 'select', b: 'box', p: 'plane', d: 'brush', l: 'line', e: 'eraser', i: 'eyedropper' };

    window.addEventListener('keydown', function (e) {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
      if (beadsDialog && beadsDialog.open) return;
      // Space pans only over the canvas; elsewhere it must still activate buttons.
      if (e.code === 'Space' && canvasHovered) { isSpacePressed = true; e.preventDefault(); }
      // Selection keys: Delete removes, arrows raise/lower, R turns a bead piece, Esc deselects.
      if (selected && !e.ctrlKey && !e.metaKey) {
        if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); selDelete(); return; }
        if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); selRaise(e.key === 'ArrowUp' ? 1 : -1); return; }
        if (e.key.toLowerCase() === 'r') { selTurn(); return; }
        if (e.key === 'Escape') { selected = null; render(); return; }
      }
      var toolKey = !e.ctrlKey && !e.metaKey && !e.altKey && TOOL_KEYS[e.key.toLowerCase()];
      if (toolKey) setTool(toolKey);
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) redo(); else undo();
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        redo();
      }
      // Only hijack Tab while the pointer is on the canvas, so keyboard navigation still works.
      if (e.key === 'Tab' && canvasHovered && !e.shiftKey) {
        e.preventDefault();
        currentPlane = currentPlane === 'top' ? 'left' : currentPlane === 'left' ? 'right' : 'top';
        if (planeBtns) {
          planeBtns.forEach(function (b) { b.classList.toggle('is-active', b.dataset.plane === currentPlane); });
        }
        render();
      }
    });

    window.addEventListener('keyup', function (e) {
      if (e.code === 'Space') isSpacePressed = false;
    });

    // Theme toggle changes CSS tokens the canvas resolves at render time.
    new MutationObserver(render).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

    // 监听语言切换
    window.onLangChange = function () {
      updateStatusBar();
    };

    updateShadeBoxes();
    updateUndoRedoBtns();

    // The last scene comes back after a reload; the sample room only on the first visit.
    var saved = readStore(SCENE_KEY);
    if (Array.isArray(saved) && saved.length) {
      shapes = saved.filter(function (s) { return s && typeof s.type === 'string'; });
      history = [shapes.slice()];
      historyIndex = 0;
      updateUndoRedoBtns();
      render();
    } else {
      loadSampleRoom();
    }

    // Opened from the Bead Pattern page's "Show in Isometric Studio": place that work.
    var m = /^#beads=([\w-]+)$/.exec(location.hash);
    if (m) {
      window.history.replaceState(null, '', location.pathname + location.search); // `history` here is the undo list
      var work = readWorks().filter(function (w) { return w.id === m[1]; })[0];
      if (work) {
        try { placePiece(workToPiece(work, 'right', 8)); } catch (e) { console.error(e); }
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
